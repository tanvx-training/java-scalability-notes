#!/bin/bash
# mix.sh <jdk> <tag> "<server opts>" "<load A>" ["<load B>"]
J=/usr/lib/jvm/java-$1-openjdk-amd64/bin; TAG=$2; SO=$3
R=/home/claude/lab20/res; C=/home/claude/lab20/classes; L=/usr/lib/jvm/java-25-openjdk-amd64/bin/java
unset JAVA_TOOL_OPTIONS
$J/java -Dstdout.encoding=UTF-8 -Xms1g -Xmx1g -Dsun.net.httpserver.maxIdleConnections=20000 $SO -cp $C lab20.Srv > $R/srv_$TAG.out 2>&1 &
P=$!
until grep -q ready $R/srv_$TAG.out 2>/dev/null; do sleep 0.2; done
head -1 $R/srv_$TAG.out
if [ -n "$5" ]; then
  $L -Dstdout.encoding=UTF-8 -Xmx512m -cp $C lab20.Load $5 2>&1 | sed "s/^/[$TAG] /" &
  B=$!
fi
$L -Dstdout.encoding=UTF-8 -Xmx512m -cp $C lab20.Load $4 2>&1 | sed "s/^/[$TAG] /"
[ -n "$5" ] && wait $B
curl -s 127.0.0.1:8080/stats; echo
kill $P; for i in $(seq 50); do kill -0 $P 2>/dev/null || break; sleep 0.1; done; kill -9 $P 2>/dev/null
