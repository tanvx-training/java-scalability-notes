package lab20;

import java.util.concurrent.locks.*;

/** Một mutex hoàn chỉnh trên AbstractQueuedSynchronizer: chỉ cần định nghĩa "state" nghĩa là gì. */
public class Aqs {
    static final class Mutex {
        private static final class Sync extends AbstractQueuedSynchronizer {
            @Override protected boolean tryAcquire(int ignore) {             // state: 0 = mở, 1 = đã khoá
                if (compareAndSetState(0, 1)) { setExclusiveOwnerThread(Thread.currentThread()); return true; }
                return false;                                                // AQS sẽ xếp hàng + park thread này
            }
            @Override protected boolean tryRelease(int ignore) {
                setExclusiveOwnerThread(null);
                setState(0);                                                 // ghi volatile = release (Bài 16)
                return true;                                                 // AQS sẽ unpark người đứng đầu hàng
            }
            @Override protected boolean isHeldExclusively() { return getState() == 1; }
        }
        private final Sync sync = new Sync();
        void lock()   { sync.acquire(1); }
        void unlock() { sync.release(1); }
        int queued()  { return sync.getQueueLength(); }
    }

    static long counter;

    public static void main(String[] a) throws Exception {
        int threads = Integer.parseInt(a[0]), per = Integer.parseInt(a[1]);
        for (String kind : new String[]{"Mutex (AQS tự viết)", "ReentrantLock", "synchronized"}) {
            for (int round = 0; round < 3; round++) {                     // vòng 0, 1: khởi động JIT
                counter = 0;
                Mutex m = new Mutex(); ReentrantLock rl = new ReentrantLock(); Object mon = new Object();
                int[] maxQ = {0};
                Thread[] ts = new Thread[threads];
                long t0 = System.nanoTime();
                for (int t = 0; t < threads; t++) {
                    ts[t] = new Thread(() -> {
                        for (int i = 0; i < per; i++) {
                            switch (kind) {
                                case "ReentrantLock" -> { rl.lock(); try { counter++; } finally { rl.unlock(); } }
                                case "synchronized" -> { synchronized (mon) { counter++; } }
                                default -> { m.lock(); try { counter++; if ((counter & 0xFFFF) == 0) maxQ[0] = Math.max(maxQ[0], m.queued()); } finally { m.unlock(); } }
                            }
                        }
                    });
                    ts[t].start();
                }
                for (Thread t : ts) t.join();
                double ms = (System.nanoTime() - t0) / 1e6;
                if (round == 2) System.out.printf("%-22s %d thread × %,d: counter = %,d (đúng: %,d)  %,7.0f ms  %s%n",
                        kind, threads, per, counter, (long) threads * per, ms, kind.startsWith("Mutex") ? "hàng đợi dài nhất thấy được: " + maxQ[0] : "");
            }
        }
    }
}
