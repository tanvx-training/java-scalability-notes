package lab20;

import java.util.*;
import java.util.concurrent.*;

/** ConcurrentHashMap bên trong: khoá theo bin, computeIfAbsent chậm, cập nhật đệ quy, so với synchronizedMap. */
public class Chm {
    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { throw new RuntimeException(e); } }

    public static void main(String[] a) throws Exception {
        // 1) computeIfAbsent chậm giữ khoá của cả BIN, không chỉ của key
        ConcurrentHashMap<Integer, String> m = new ConcurrentHashMap<>(16);
        Thread loader = Thread.ofPlatform().start(() -> m.computeIfAbsent(1, k -> { sleep(1000); return "từ DB"; }));
        sleep(100);
        long t0 = System.nanoTime(); String g = m.get(1);
        System.out.printf("get(1) cùng lúc: %.3f ms, trả về %s (đọc không bao giờ bị khoá)%n", (System.nanoTime() - t0) / 1e6, g);
        for (int key : new int[]{17, 2, 33}) {          // new ConcurrentHashMap(16) cấp 32 ô: 33 cùng ô với 1; 17 và 2 thì không
            long t1 = System.nanoTime();
            m.put(key, "v");
            System.out.printf("put(%2d) trong khi computeIfAbsent(1) đang chạy: %6.1f ms  (ô %d / 32)%n",
                    key, (System.nanoTime() - t1) / 1e6, (key ^ (key >>> 16)) & 31);
        }
        loader.join();

        // 2) cập nhật đệ quy: memo hoá bằng computeIfAbsent
        ConcurrentHashMap<Integer, Long> memo = new ConcurrentHashMap<>();
        try { System.out.println("fib(30) = " + fib(30, memo)); }
        catch (IllegalStateException e) { System.out.println("fib bằng computeIfAbsent đệ quy: " + e); }

        // 3) thông lượng: 80% get / 20% put trên 10 000 key
        int threads = Integer.parseInt(a.length > 0 ? a[0] : "4");
        for (String kind : new String[]{"Collections.synchronizedMap", "ConcurrentHashMap"}) {
            for (int round = 0; round < 3; round++) {
                Map<Integer, Integer> map = kind.startsWith("Coll") ? Collections.synchronizedMap(new HashMap<>()) : new ConcurrentHashMap<>();
                for (int i = 0; i < 10_000; i++) map.put(i, i);
                Thread[] ts = new Thread[threads];
                long s0 = System.nanoTime();
                for (int t = 0; t < threads; t++) {
                    final int seed = t;
                    ts[t] = new Thread(() -> {
                        var r = new SplittableRandom(seed); long x = 0;
                        for (int i = 0; i < 5_000_000; i++) {
                            int k = r.nextInt(10_000);
                            if (r.nextInt(10) < 8) { Integer v = map.get(k); if (v != null) x += v; } else map.put(k, i);
                        }
                        if (x == 42) System.out.print("");
                    });
                    ts[t].start();
                }
                for (Thread t : ts) t.join();
                double ms = (System.nanoTime() - s0) / 1e6;
                if (round == 2) System.out.printf("%-28s %d thread × 5 triệu thao tác: %,7.0f ms (%5.1f triệu thao tác/s)%n",
                        kind, threads, ms, threads * 5.0 / (ms / 1000));
            }
        }
    }

    static long fib(int n, ConcurrentHashMap<Integer, Long> memo) {
        if (n < 2) return n;
        return memo.computeIfAbsent(n, k -> fib(k - 1, memo) + fib(k - 2, memo));
    }
}
