package lab20;

import java.lang.management.ManagementFactory;
import java.util.concurrent.*;

/** CompletableFuture.supplyAsync() không truyền executor thì chạy ở đâu? Phụ thuộc số CPU và phiên bản JDK. */
public class CfDefault {
    public static void main(String[] a) throws Exception {
        int n = a.length > 0 ? Integer.parseInt(a[0]) : 100_000;
        var mx = ManagementFactory.getThreadMXBean();
        Executor def = new CompletableFuture<Void>().defaultExecutor();
        String where = CompletableFuture.supplyAsync(() -> Thread.currentThread().getName()).get();
        long started0 = mx.getTotalStartedThreadCount();
        long t0 = System.nanoTime();
        CompletableFuture<?>[] fs = new CompletableFuture<?>[n];
        for (int i = 0; i < n; i++) fs[i] = CompletableFuture.supplyAsync(() -> 1);
        CompletableFuture.allOf(fs).join();
        double ms = (System.nanoTime() - t0) / 1e6;
        System.out.printf("JDK %-2d CPU=%d commonPool.parallelism=%d | executor mặc định: %-38s chạy trên \"%s\" | %,d supplyAsync: %,7.0f ms, tạo %,d thread mới%n",
                Runtime.version().feature(), Runtime.getRuntime().availableProcessors(), ForkJoinPool.getCommonPoolParallelism(),
                def.getClass().getName().replace("java.util.concurrent.", ""), where, n, ms, mx.getTotalStartedThreadCount() - started0);
    }
}
