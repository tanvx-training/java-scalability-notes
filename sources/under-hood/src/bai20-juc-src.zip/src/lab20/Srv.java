package lab20;

import com.sun.net.httpserver.*;
import java.io.*;
import java.lang.management.ManagementFactory;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.*;

/**
 * Service kiểu Tomcat (pool 200 platform thread) với hai endpoint dùng chung ForkJoinPool.commonPool():
 *   /search        parallelStream() lọc + tính điểm trên 400 000 phần tử (CPU)
 *   /enrich        gọi 3 "HTTP downstream" song song bằng CompletableFuture.supplyAsync(...) KHÔNG truyền executor;
 *                  mỗi lời gọi chặn 300 ms (Thread.sleep)
 *   /enrich?own=1  như trên nhưng truyền executor riêng (virtual thread)
 *   /stats
 */
public class Srv {
    static final int[] DATA = IntStream.range(0, 400_000).map(i -> (i * 2654435761L) > 0 ? i : -i).toArray();
    static final ExecutorService OWN = Executors.newVirtualThreadPerTaskExecutor();
    static volatile long sink;

    static String q(HttpExchange ex, String k) {
        String qs = ex.getRequestURI().getQuery();
        if (qs != null) for (String p : qs.split("&")) if (p.startsWith(k + "=")) return p.substring(k.length() + 1);
        return null;
    }
    static void reply(HttpExchange ex, int code, String body) throws IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        ex.sendResponseHeaders(code, b.length);
        try (OutputStream o = ex.getResponseBody()) { o.write(b); }
    }
    static long score(int v) { long x = v; for (int k = 0; k < 200; k++) x = x * 6364136223846793005L + 1442695040888963407L; return x; }
    static String callDownstream(String name) {
        try { Thread.sleep(300); } catch (InterruptedException e) { throw new RuntimeException(e); }
        return name;
    }

    public static void main(String[] a) throws Exception {
        HttpServer s = HttpServer.create(new InetSocketAddress("127.0.0.1", 8080), 4096);
        s.setExecutor(Executors.newFixedThreadPool(200));
        s.createContext("/", h -> {
            try {
                switch (h.getRequestURI().getPath()) {
                    case "/search" -> {
                        var st = q(h, "seq") != null ? Arrays.stream(DATA) : Arrays.stream(DATA).parallel();
                        long r = st.filter(v -> (v & 7) != 0).mapToLong(Srv::score).sum();
                        sink = r; reply(h, 200, "{\"search\":" + (r & 0xff) + "}");
                    }
                    case "/enrich" -> {
                        Executor ex = q(h, "own") != null ? OWN : null;
                        var f1 = ex == null ? CompletableFuture.supplyAsync(() -> callDownstream("user")) : CompletableFuture.supplyAsync(() -> callDownstream("user"), ex);
                        var f2 = ex == null ? CompletableFuture.supplyAsync(() -> callDownstream("price")) : CompletableFuture.supplyAsync(() -> callDownstream("price"), ex);
                        var f3 = ex == null ? CompletableFuture.supplyAsync(() -> callDownstream("stock")) : CompletableFuture.supplyAsync(() -> callDownstream("stock"), ex);
                        reply(h, 200, "{\"enrich\":\"" + f1.join() + f2.join() + f3.join() + "\"}");
                    }
                    case "/stats" -> {
                        ForkJoinPool cp = ForkJoinPool.commonPool();
                        reply(h, 200, String.format("{\"cpu\":%d,\"commonParallelism\":%d,\"poolSize\":%d,\"steals\":%d,\"queued\":%d,\"threadsStarted\":%d}",
                                Runtime.getRuntime().availableProcessors(), ForkJoinPool.getCommonPoolParallelism(), cp.getPoolSize(), cp.getStealCount(),
                                cp.getQueuedSubmissionCount() + cp.getQueuedTaskCount(), ManagementFactory.getThreadMXBean().getTotalStartedThreadCount()));
                    }
                    default -> reply(h, 404, "{}");
                }
            } catch (Exception e) { try { reply(h, 500, "{}"); } catch (IOException ignored) {} }
        });
        s.start();
        System.out.println("ready pid " + ProcessHandle.current().pid() + " commonPool.parallelism=" + ForkJoinPool.getCommonPoolParallelism());
    }
}
