package lab18;

import java.util.*;
import java.util.concurrent.locks.LockSupport;

/**
 * "Pause dài nhưng log GC ngắn". Ba loại thread:
 *  - allocator: tạo rác liên tục -> GC trẻ định kỳ (giống request bình thường)
 *  - probe: ngủ 1 ms rồi đo mình bị trễ bao lâu (độ trễ mà ứng dụng THẤY)
 *  - culprit: tuỳ chế độ: none | loop (vòng for int dài) | copy (System.arraycopy mảng lớn)
 * Chạy: java -Xlog:gc,safepoint:file=... lab18.Ttsp <mode> [giây]
 */
public class Ttsp {
    static volatile boolean stop;
    static volatile long sink;
    static int[] data = new int[1 << 20];

    /** Vòng lặp đếm (counted loop) dài: biến chạy int, cận cố định. */
    static long loop(int n) {
        long s = 0;
        for (int i = 0; i < n; i++) { s += data[i & ((1 << 20) - 1)] ^ i; }
        return s;
    }

    static long loopLong(long n) {
        long s = 0;
        for (long i = 0; i < n; i++) { s += data[(int) (i & ((1 << 20) - 1))] ^ i; }
        return s;
    }

    public static void main(String[] a) throws Exception {
        String mode = a[0];
        double secs = a.length > 1 ? Double.parseDouble(a[1]) : 20;
        for (int i = 0; i < data.length; i++) data[i] = i * 31;

        Thread alloc = new Thread(() -> {
            Object[] keep = new Object[4096]; int k = 0;
            while (!stop) { keep[k++ & 4095] = new byte[256]; }   // khoảng 1 MB sống, phần còn lại là rác
        }, "allocator");

        long[] src = mode.equals("copy") ? new long[32 << 20] : null, dst = mode.equals("copy") ? new long[32 << 20] : null;  // 256 MB mỗi mảng
        byte[] zin = new byte[64 << 20], zout = new byte[1 << 20];
        for (int i = 0; i < zin.length; i++) zin[i] = (byte) ((i * 2654435761L) >>> 13);
        Thread culprit = new Thread(() -> {
            while (!stop) {
                switch (mode) {
                    case "loop" -> sink = loop(1_500_000_000);
                    case "longloop" -> sink = loopLong(1_500_000_000L);
                    case "copy" -> System.arraycopy(src, 0, dst, 0, src.length);
                    case "deflate" -> { var d = new java.util.zip.Deflater(9); d.setInput(zin); d.finish();
                                        while (!d.finished()) d.deflate(zout); d.end(); }
                    case "crc" -> { var c = new java.util.zip.CRC32(); c.update(zin, 0, zin.length); sink = c.getValue(); }
                    default -> LockSupport.parkNanos(10_000_000);
                }
            }
        }, "culprit");

        List<double[]> stalls = new ArrayList<>();               // {thời điểm s, trễ ms}
        long[] hist = new long[6];                                // <1, 1-5, 5-20, 20-100, 100-500, >=500 ms
        Thread probe = new Thread(() -> {
            long start = System.nanoTime();
            while (!stop) {
                long t0 = System.nanoTime();
                LockSupport.parkNanos(1_000_000);
                double late = (System.nanoTime() - t0 - 1_000_000) / 1e6;
                int b = late < 1 ? 0 : late < 5 ? 1 : late < 20 ? 2 : late < 100 ? 3 : late < 500 ? 4 : 5;
                hist[b]++;
                if (late >= 20) stalls.add(new double[]{(t0 - start) / 1e9, late});
            }
        }, "probe");

        alloc.start(); probe.start(); culprit.start();
        Thread.sleep((long) (secs * 1000));
        stop = true;
        alloc.join(); probe.join(); culprit.join();

        double max = stalls.stream().mapToDouble(x -> x[1]).max().orElse(0);
        System.out.printf("mode=%-5s probe: trễ <1ms %d | 1-5 %d | 5-20 %d | 20-100 %d | 100-500 %d | >=500 %d   lớn nhất %.0f ms%n",
                mode, hist[0], hist[1], hist[2], hist[3], hist[4], hist[5], max);
        stalls.sort((x, y) -> Double.compare(y[1], x[1]));
        StringBuilder sb = new StringBuilder("  5 lần trễ lớn nhất (giây thứ: ms):");
        for (int i = 0; i < Math.min(5, stalls.size()); i++) sb.append(String.format(" %.2f:%.0f", stalls.get(i)[0], stalls.get(i)[1]));
        System.out.println(sb);
    }
}
