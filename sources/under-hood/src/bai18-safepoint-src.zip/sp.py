#!/usr/bin/env python3
"""Tóm tắt -Xlog:gc,safepoint: so thời gian pause trong log GC với tổng thời gian safepoint.
Cách dùng: sp.py gc.log"""
import re, sys
from collections import defaultdict

gc = []          # ms
sp = []          # (name, reach_ms, at_ms, total_ms)
for line in open(sys.argv[1], errors='replace'):
    m = re.search(r'Pause .*?(\d+\.\d+)ms$', line.strip())
    if m and '[gc' in line and 'safepoint' not in line:
        gc.append(float(m.group(1)))
    m = re.search(r'Safepoint "([^"]+)"', line)
    if m and 'Reaching safepoint' in line:
        g = lambda k: int(re.search(k + r': (\d+) ns', line).group(1))
        sp.append((m.group(1), g('Reaching safepoint') / 1e6, g('At safepoint') / 1e6, g('Total') / 1e6))

print(f"GC pause theo log GC: {len(gc)} lần, tổng {sum(gc):.1f} ms, lớn nhất {max(gc, default=0):.1f} ms")
print(f"Safepoint: {len(sp)} lần, tổng {sum(x[3] for x in sp):.1f} ms, trong đó chờ vào safepoint {sum(x[1] for x in sp):.1f} ms")
by = defaultdict(lambda: [0, 0.0, 0.0, 0.0])
for n, r, at, t in sp:
    b = by[n]; b[0] += 1; b[1] = max(b[1], r); b[2] = max(b[2], at); b[3] += t
for n, (c, r, at, t) in sorted(by.items(), key=lambda kv: -kv[1][3]):
    print(f"  {n:<28} {c:5d} lần   chờ vào lớn nhất {r:9.1f} ms   ở trong lớn nhất {at:7.1f} ms   tổng {t:9.1f} ms")
worst = sorted(sp, key=lambda x: -x[3])[:3]
for n, r, at, t in worst:
    print(f"  tệ nhất: {n:<24} chờ vào {r:8.1f} ms + ở trong {at:6.1f} ms = {t:8.1f} ms")
