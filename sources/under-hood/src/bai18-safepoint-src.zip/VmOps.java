package lab18;

import java.util.*;
import java.util.concurrent.locks.LockSupport;

/**
 * Một "service" với heap sống lớn và nhiều thread đang chờ; probe đo độ trễ 1 ms.
 * Script bên ngoài bắn các lệnh jcmd vào nó (thread dump, heap dump, histogram...).
 * Trong chương trình: lần lượt gọi Thread.getStackTrace() (handshake) và Thread.getAllStackTraces() (safepoint).
 * Chạy: java lab18.VmOps <liveMB> <idleThreads> <giây>
 */
public class VmOps {
    static volatile boolean stop;
    static final List<byte[]> live = new ArrayList<>();

    static void deep(int d) { if (d > 0) deep(d - 1); else LockSupport.park(); }

    public static void main(String[] a) throws Exception {
        int liveMb = Integer.parseInt(a[0]), idle = Integer.parseInt(a[1]);
        double secs = Double.parseDouble(a[2]);
        for (int i = 0; i < liveMb * 16; i++) { byte[] b = new byte[64 * 1024]; b[0] = 1; live.add(b); }  // heap sống
        List<Thread> idles = new ArrayList<>();
        for (int i = 0; i < idle; i++) { Thread t = new Thread(() -> deep(40), "worker-" + i); t.setDaemon(true); t.start(); idles.add(t); }

        long start = System.nanoTime();
        Thread probe = new Thread(() -> {
            while (!stop) {
                long t0 = System.nanoTime();
                LockSupport.parkNanos(1_000_000);
                double late = (System.nanoTime() - t0 - 1_000_000) / 1e6;
                if (late >= 10) System.out.printf("  probe: t=%6.2fs trễ %7.1f ms%n", (t0 - start) / 1e9, late);
            }
        }, "probe");
        probe.start();
        Thread alloc = new Thread(() -> { Object[] k = new Object[1024]; int i = 0; while (!stop) { k[i++ & 1023] = new byte[512]; LockSupport.parkNanos(20_000); } }, "allocator");
        alloc.setDaemon(true); alloc.start();
        System.out.printf("ready: heap sống %d MB, %d thread chờ, pid %d%n", liveMb, idle, ProcessHandle.current().pid());

        Thread.sleep(2000);
        long t0 = System.nanoTime();
        for (int i = 0; i < 1000; i++) idles.get(i % idles.size()).getStackTrace();
        System.out.printf("[app] 1000 × Thread.getStackTrace() một thread: %.1f ms tổng%n", (System.nanoTime() - t0) / 1e6);
        Thread.sleep(1000);
        t0 = System.nanoTime();
        Map<Thread, StackTraceElement[]> all = Thread.getAllStackTraces();
        System.out.printf("[app] Thread.getAllStackTraces(): %d thread, %.1f ms%n", all.size(), (System.nanoTime() - t0) / 1e6);

        Thread.sleep((long) (secs * 1000) - 3000);
        stop = true; probe.join();
        System.out.println("done");
    }
}
