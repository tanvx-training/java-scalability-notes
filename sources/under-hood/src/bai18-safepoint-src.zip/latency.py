#!/usr/bin/env python3
"""Gom sự kiện jdk.SafepointLatency theo thread.
Dùng: jfr print --events jdk.SafepointLatency r.jfr > lat.txt ; python3 latency.py lat.txt"""
import re, sys
from collections import defaultdict
t = open(sys.argv[1]).read()
rows = []
for e in t.split('jdk.SafepointLatency {')[1:]:
    th = re.search(r'eventThread = "([^"]+)"', e).group(1)
    d = re.search(r'duration = ([\d.]+) (\w+)', e)
    v = float(d.group(1)) * {'s': 1000, 'ms': 1, 'us': 0.001, 'ns': 1e-6}.get(d.group(2), 1)
    top = re.search(r'stackTrace = \[\s*\n\s*(.+?)\n', e)
    rows.append((th, v, top.group(1).strip() if top else ''))
agg = defaultdict(list)
for th, v, _ in rows: agg[th].append(v)
for th, vs in sorted(agg.items(), key=lambda kv: -max(kv[1])):
    print(f"{th:20s} n={len(vs):5d} max={max(vs):10.3f} ms")
for th, v, top in sorted(rows, key=lambda r: -r[1])[:5]:
    print(f"  {th} {v:.1f} ms  {top}")
