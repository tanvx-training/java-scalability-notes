#!/bin/bash
# vmops.sh <jdk> <tag>
J=/usr/lib/jvm/java-$1-openjdk-amd64/bin; T=$2; R=/home/claude/lab18/res
unset JAVA_TOOL_OPTIONS
$J/java -Dstdout.encoding=UTF-8 -Xms3g -Xmx3g -XX:+UseG1GC -Xlog:safepoint,handshake:file=$R/$T.log -cp /home/claude/lab18/classes lab18.VmOps 1500 2000 34 > $R/$T.out 2>&1 &
P=$!
until grep -q ready $R/$T.out 2>/dev/null; do sleep 0.2; done
mark(){ echo "[script] t=$(( $(date +%s%N)/1000000 - S ))ms $1" >> $R/$T.out; }
S=$(( $(date +%s%N)/1000000 ))
sleep 6; mark "jcmd Thread.print"; $J/jcmd $P Thread.print > $R/${T}_td.txt; mark "xong Thread.print ($(wc -l < $R/${T}_td.txt) dòng)"
sleep 3; mark "jcmd GC.class_histogram"; $J/jcmd $P GC.class_histogram > /dev/null; mark "xong histogram"
sleep 3; mark "jcmd GC.heap_dump"; $J/jcmd $P GC.heap_dump /home/claude/lab18/res/h.hprof > /dev/null; mark "xong heap dump $(du -m /home/claude/lab18/res/h.hprof | cut -f1) MB"; rm -f /home/claude/lab18/res/h.hprof
sleep 3; mark "jcmd Thread.print -e"; $J/jcmd $P Thread.print -e > /dev/null; mark "xong"
wait $P
