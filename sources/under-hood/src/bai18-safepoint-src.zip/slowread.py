import sys, time
# đọc stdin chậm: 2 KB mỗi 100 ms (~20 KB/s) — giả lập đĩa mạng / collector log bị nghẽn
n = 0
while True:
    b = sys.stdin.buffer.read1(2048) if hasattr(sys.stdin.buffer, 'read1') else sys.stdin.buffer.read(2048)
    if not b: break
    n += len(b); time.sleep(0.1)
