# Theo dõi một tiến trình mỗi giây: CPU% (của 1 lõi), RSS MB, số thread — như dashboard của pod.
import sys, time, os
pid, out = sys.argv[1], sys.argv[2]
hz = os.sysconf('SC_CLK_TCK'); prev = None; t0 = time.time()
with open(out, 'w') as f:
    while True:
        try:
            st = open(f'/proc/{pid}/stat').read().split(); status = open(f'/proc/{pid}/status').read()
        except FileNotFoundError:
            f.write(f"t={time.time()-t0:5.1f}s  tiến trình đã kết thúc\n"); break
        cpu = int(st[13]) + int(st[14]); now = time.time()
        rss = int([l for l in status.splitlines() if l.startswith('VmRSS')][0].split()[1]) / 1024
        thr = int([l for l in status.splitlines() if l.startswith('Threads')][0].split()[1])
        if prev: f.write(f"t={now-t0:5.1f}s  CPU {100*(cpu-prev[0])/hz/(now-prev[1]):6.1f}%  RSS {rss:7.1f} MB  threads {thr}\n"); f.flush()
        prev = (cpu, now); time.sleep(1)
