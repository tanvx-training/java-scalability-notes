#!/bin/bash
# Kịch bản 1: CPU cao sau deploy. v1 chạy 40 s, "deploy" v2, chạy 80 s; điều tra trong lúc v2 chạy.
source tools/common.sh
D=kb1; rm -rf $D; mkdir -p $D
PAID=$(sed -n 1p tools/rows.txt); REF=$(sed -n 2p tools/rows.txt)
for v in 1 2; do
  start_svc $D v$v -Xmx512m -Dversion=$v
  echo "v$v pid $P" >> $D/notes.txt
  len=$([ $v = 1 ] && echo 40 || echo 80)
  $J/java -Dstdout.encoding=UTF-8 -cp cls lab26.LoadTL 40 $len 200 "$PAID:3,$REF:1" > $D/load_webhook_v$v.txt 2>&1 & L1=$!
  $J/java -Dstdout.encoding=UTF-8 -cp cls lab26.LoadTL 100 $len 300 "/catalog?id=42:1" > $D/load_catalog_v$v.txt 2>&1 & L2=$!
  if [ $v = 1 ]; then
    pause 20; $J/jcmd $P JFR.start name=base settings=profile duration=15s filename=$PWD/$D/v1.jfr > /dev/null
  else
    pause 25
    ( date +%T; echo "-- bước 1: ai đang dùng CPU (top -H theo thread)"; top -b -H -n 1 -p $P | head -14 ) > $D/step1_top.txt 2>&1
    $J/jcmd $P Thread.dump_to_file -format=json $PWD/$D/threads.json > /dev/null
    $J/jcmd $P Thread.print > $D/threads.txt
    $J/jcmd $P JFR.configure stackdepth=256 > $D/jfr_configure.txt 2>&1
    $J/jcmd $P JFR.start name=incident settings=profile duration=20s filename=$PWD/$D/v2.jfr > /dev/null
    pause 22
    $J/jcmd $P JFR.view width=130 hot-methods > $D/step3_hot.txt
  fi
  wait $L1 $L2
  kill $P; pause 1.5
done
echo DONE > $D/done
