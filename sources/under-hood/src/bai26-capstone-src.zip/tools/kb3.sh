#!/bin/bash
# Kịch bản 3: pod bị OOMKilled dù heap không đầy. Giới hạn bộ nhớ cgroup 512 MB (như limits.memory của pod).
source tools/common.sh
D=kb3; rm -rf $D; mkdir -p $D
echo $((512*1024*1024)) > $CG/memory.limit_in_bytes
cat $CG/memory.oom_control > $D/oom_before.txt; echo 0 > $CG/memory.failcnt 2>/dev/null
start_svc $D svc -XX:NativeMemoryTracking=summary "-Xlog:gc:file=$PWD/$D/gc.log:uptime"
echo "pid $P" > $D/notes.txt
$J/jcmd $P VM.native_memory baseline > /dev/null
$J/jcmd $P GC.heap_info > $D/heap_t0.txt
$J/java -Dstdout.encoding=UTF-8 -cp cls lab26.LoadTL 20 150 50 "/export:1" > $D/load_export.txt 2>&1 & L1=$!
$J/java -Dstdout.encoding=UTF-8 -cp cls lab26.LoadTL 50 150 100 "/catalog?id=7:1" > $D/load_catalog.txt 2>&1 & L2=$!
for k in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15; do
  pause 10
  kill -0 $P 2>/dev/null || break
  $J/jcmd $P VM.native_memory summary.diff scale=MB > $D/nmt_$k.txt 2>&1
  $J/jcmd $P GC.heap_info > $D/heap_$k.txt 2>&1
  echo "t=$((k*10))s cgroup usage $(( $(cat $CG/memory.usage_in_bytes)/1048576 )) MB, rss $(( $(grep VmRSS /proc/$P/status | awk '{print $2}')/1024 )) MB, kmem $(( $(cat $CG/memory.kmem.usage_in_bytes)/1048576 )) MB, cache $(( $(grep '^total_cache ' $CG/memory.stat | awk '{print $2}')/1048576 )) MB" >> $D/cgroup.txt
done
$J/jcmd $P Thread.print > $D/threads_last.txt 2>/dev/null
wait $P 2>/dev/null; echo "exit $?" >> $D/notes.txt
wait $L1 $L2
cat $CG/memory.oom_control > $D/oom_after.txt; cat $CG/memory.failcnt > $D/failcnt.txt; cat $CG/memory.max_usage_in_bytes > $D/maxusage.txt
echo DONE > $D/done
