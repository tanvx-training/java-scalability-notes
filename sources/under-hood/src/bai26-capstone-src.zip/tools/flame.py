# Dựng flame graph (SVG) từ jdk.ExecutionSample của một file JFR đã xuất JSON.
import json, sys, html
src, out, title = sys.argv[1], sys.argv[2], sys.argv[3]
COLLAPSE = len(sys.argv) > 4
ev = json.load(open(src))['recording']['events']
root = {'n': 'all', 'c': {}, 'v': 0}
for e in ev:
    st = e['values'].get('stackTrace')
    if not st: continue
    def nm(f):
        parts = f['method']['type']['name'].split('/')
        cls = parts[-2] + '/' + parts[-1] if parts[-1].startswith('0x') and len(parts) > 1 else parts[-1]
        cls = cls.split('/0x')[0]                     # lớp ẩn: bỏ hậu tố địa chỉ
        return f"{cls}.{f['method']['name']}"
    frames = [nm(f) for f in st['frames']][::-1]
    if COLLAPSE:                                   # gộp đệ quy của regex thành một hộp
        acc = []
        for fr in frames:
            if fr.startswith('Pattern$'):
                if not (acc and acc[-1] == 'Pattern$… (regex đệ quy)'): acc.append('Pattern$… (regex đệ quy)')
            else: acc.append(fr)
        frames = acc
    node = root; node['v'] += 1
    for fr in frames:
        node = node['c'].setdefault(fr, {'n': fr, 'c': {}, 'v': 0}); node['v'] += 1
W, RH, X0 = 680, 15, 6
total = root['v']; scale = (W - 2 * X0) / total
rects = []
def walk(node, x, depth):
    rects.append((x, depth, node['v'] * scale, node['n'], node['v']))
    cx = x
    for ch in sorted(node['c'].values(), key=lambda c: -c['v']):
        if ch['v'] * scale >= 4: walk(ch, cx, depth + 1)
        cx += ch['v'] * scale
walk(root, X0, 0)
maxd = max(r[1] for r in rects)
H = 34 + (maxd + 1) * RH + 6
def color(n):
    if n.startswith('Shop.') or 'lab25' in n: return '#f0965a'
    if n.startswith(('Pattern', 'Matcher', 'Formatter', 'String', 'Long', 'ArrayList', 'Arrays', 'Abstract')): return '#c4a7ff'
    if n == 'all': return '#d1d5db'
    return '#9ec5fe'
o = [f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg" font-family="Inter">',
     f'<text x="6" y="14" font-size="10.4" font-weight="700" fill="#18202c">{html.escape(title)} — {total} mẫu</text>']
for x, d, w, n, v in rects:
    y = H - 6 - (d + 1) * RH
    o.append(f'<rect x="{x:.1f}" y="{y}" width="{max(w-0.6,0.6):.1f}" height="{RH-1}" fill="{color(n)}" stroke="#ffffff" stroke-width="0.3"/>')
    label = f'{n} ({100*v/total:.0f}%)' if n != 'all' else f'all ({total})'
    maxch = int(w / 4.6)
    if maxch >= 4:
        t = label if len(label) <= maxch else label[:maxch - 1] + '…'
        o.append(f'<text x="{x+2:.1f}" y="{y+10.5}" font-size="7.8" fill="#18202c">{html.escape(t)}</text>')
o.append('</svg>')
open(out, 'w').write('\n'.join(o))
print('rects', len(rects), 'depth', maxd)
