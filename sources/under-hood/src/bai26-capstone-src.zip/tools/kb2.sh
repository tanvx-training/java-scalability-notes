#!/bin/bash
# Kịch bản 2: latency spike định kỳ. Job dựng lại catalog mỗi 15 s, giữ cùng khoá với đường đọc.
source tools/common.sh
D=kb2; rm -rf $D; mkdir -p $D
T0=$(date +%s.%N)
start_svc $D svc -Xmx512m -Dcatalog.refresh=15 "-Xlog:gc:file=$PWD/$D/gc.log:uptime" "-Xlog:safepoint:file=$PWD/$D/safepoint.log:uptime"
$J/java -Dstdout.encoding=UTF-8 -cp cls lab26.LoadTL 200 62 400 "/catalog?id=42:1" > $D/load_catalog.txt 2>&1 & L1=$!
pause 3
$J/jcmd $P JFR.start name=spike settings=profile jdk.JavaMonitorEnter#threshold=1ms filename=$PWD/$D/spike.jfr > /dev/null
# chụp thread dump dồn dập quanh mốc 30 s (lần refresh thứ hai)
while python3 -c "import sys,time; sys.exit(0 if time.time()-$T0 < 29.3 else 1)"; do pause 0.05; done
for i in 1 2 3 4 5 6 7 8 9 10; do $J/jcmd $P Thread.print > $D/dump_$i.txt; done
pause 20
$J/jcmd $P JFR.stop name=spike > /dev/null
wait $L1
kill $P; pause 1.5
echo DONE > $D/done
