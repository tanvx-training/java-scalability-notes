import re, sys, pathlib
from playwright.sync_api import sync_playwright
import pypdfium2 as pdfium
from pypdf import PdfReader, PdfWriter

D = pathlib.Path("/home/claude/lab26/doc")
OUT = pathlib.Path("/home/claude/lab26/out"); OUT.mkdir(exist_ok=True)

FOOTER = ('<div style="width:100%;font-family:Inter,sans-serif;font-size:7.4pt;color:#6b7280;'
          'padding:0 17.5mm;display:flex;justify-content:space-between;">'
          '<span>Java Under the Hood · Bài 26 — Capstone: điều tra sự cố production</span>'
          '<span class="pageNumber"></span></div>')

# heading text used to locate page of each section
SECTIONS = {
    "p-top": "Câu trả lời ngắn",
    "p-s1": "Ba sự cố, một quy trình",
    "p-s2": "Kịch bản 1: CPU cao sau deploy",
    "p-s3": "Điều tra kịch bản 1",
    "p-s4": "Kịch bản 2: latency spike định kỳ",
    "p-s5": "Điều tra kịch bản 2",
    "p-s6": "Kịch bản 3: OOMKilled khi heap còn trống",
    "p-s7": "Điều tra kịch bản 3",
    "p-s8": "Trả lời câu hỏi: bắt đầu từ đâu lúc 2 giờ sáng",
    "p-s9": "Trong Spring Boot",
    "p-s10": "Cả series trên một trang",
    "p-s11": "Hiểu lầm thường gặp, bài tập, lời kết",
}
import json
FILL = json.load(open("/home/claude/lab26/fill.json"))
def fill(body):
    for k, v in FILL.items(): body = body.replace("{{" + k + "}}", v)
    return body

def assemble(pages=None):
    body = "".join((D / f).read_text() for f in ["p1.html", "p2.html", "p3.html", "p4.html", "p5.html"])
    body = re.sub(r"\{\{file:([\w.]+)\}\}", lambda m: (D / m.group(1)).read_text(), body)
    body = fill(body)
    if pages:
        for k, v in pages.items():
            body = body.replace("{{" + k + "}}", str(v))
    html = ('<!doctype html><html lang="vi"><head><meta charset="utf-8">'
            '<link rel="stylesheet" href="style.css"></head><body>' + body + '</body></html>')
    (D / "body.html").write_text(html)

def render(page, src, dst, footer=True):
    page.goto(src.as_uri()); page.wait_for_load_state("networkidle")
    page.evaluate("document.fonts.ready")
    if footer:
        page.pdf(path=str(dst), format="A4", print_background=True, display_header_footer=True,
                 header_template="<div></div>", footer_template=FOOTER,
                 margin={"top": "17mm", "bottom": "18mm", "left": "17.5mm", "right": "17.5mm"})
    else:
        page.pdf(path=str(dst), format="A4", print_background=True, prefer_css_page_size=True)

def norm(s): return re.sub(r"\s+", " ", s)

def find_pages(pdf):
    doc = pdfium.PdfDocument(str(pdf)); texts = []
    for i in range(len(doc)):
        texts.append(norm(doc[i].get_textpage().get_text_range()))
    res = {}
    for k, needle in SECTIONS.items():
        n = norm(needle)
        hits = [i + 1 for i, t in enumerate(texts) if n in t]
        hits = [h for h in hits if h > 1]           # bỏ trang mục lục
        res[k] = hits[0] if hits else "?"
    return res, len(doc)

with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(); pg.set_default_timeout(180000)
    assemble({k: "00" for k in SECTIONS}); render(pg, D / "body.html", OUT / "body.pdf")
    pages, n = find_pages(OUT / "body.pdf"); print("pass1", pages, n)
    assemble(pages); render(pg, D / "body.html", OUT / "body.pdf")
    pages2, n2 = find_pages(OUT / "body.pdf"); print("pass2", pages2, n2)
    assert pages == pages2, "page numbers shifted"
    render(pg, D / "cover.html", OUT / "cover.pdf", footer=False)
    b.close()

w = PdfWriter()
for f in ("cover.pdf", "body.pdf"):
    for pgx in PdfReader(str(OUT / f)).pages: w.add_page(pgx)
w.add_metadata({"/Title": "Java Under the Hood — Bài 26: Capstone — điều tra sự cố Spring Boot production từ A đến Z",
                "/Author": "Java Under the Hood", "/Subject": "incident response, on-call, CPU, latency spike, OOMKilled, regex backtracking, lock contention, thread leak, JFR, NMT, cgroup"})
final = OUT / "Java-Under-the-Hood-Bai-26.pdf"
with open(final, "wb") as fh: w.write(fh)
print("OK", final, len(PdfReader(str(final)).pages), "pages")
