#!/bin/bash
source tools/common.sh
D=kb3b; rm -rf $D; mkdir -p $D; echo $((512*1024*1024)) > $CG/memory.limit_in_bytes
start_svc $D svc
$J/java -Dstdout.encoding=UTF-8 -cp cls lab26.LoadTL 20 15 50 "/export:1" > $D/load.txt 2>&1
$J/jcmd $P Thread.print > $D/threads.txt
$J/jcmd $P Thread.dump_to_file -format=json $PWD/$D/threads.json > /dev/null
kill $P; pause 1
