unset JAVA_TOOL_OPTIONS
J=/usr/lib/jvm/java-25-openjdk-amd64/bin
pause(){ python3 -c "import time;time.sleep($1)"; }
CG=/sys/fs/cgroup/memory/process_api/01a18526-48e2-7676-8034-cfa3e6235d37/claude-code-bash/lab26
start_svc(){ # start_svc <dir> <tag> <jvm opts...>  → đặt biến P
  local d=$1 tag=$2; shift 2
  sh -c "echo \$\$ > $CG/cgroup.procs; exec $J/java -Dsun.net.httpserver.maxIdleConnections=20000 $* -cp cls lab26.OrderSvc" > $d/svc_$tag.out 2>&1 &
  for i in $(seq 1 200); do grep -q ready $d/svc_$tag.out 2>/dev/null && break; pause 0.1; done
  P=$(grep -o 'pid [0-9]*' $d/svc_$tag.out | cut -d' ' -f2)
  python3 tools/mon.py $P $d/mon_$tag.txt &
}
