import re, math, pathlib
D = pathlib.Path('/home/claude/lab26/doc')
R = pathlib.Path('/home/claude/lab26')

def load_tl(p):
    out = []
    for l in open(p):
        m = re.match(r't=\s*(\d+)s\s+n=\s*(\d+)\s+p50\s+([\d.]+)\s+p99\s+([\d.]+)\s+max\s+([\d.]+) ms\s+lỗi (\d+)', l)
        if m: out.append((int(m.group(1)), int(m.group(2)), float(m.group(4)), int(m.group(6))))
    return out
def load_mon(p):
    out = []
    for l in open(p):
        m = re.match(r't=\s*([\d.]+)s\s+CPU\s+([\d.]+)%\s+RSS\s+([\d.]+) MB\s+threads (\d+)', l)
        if m: out.append((float(m.group(1)), float(m.group(2)), float(m.group(3)), int(m.group(4))))
    return out

def chart(title, series, xmax, ymin, ymax, yticks, ylabel, log=False, W=680, H=200, x0=50, x1=660, y0=30, y1=170, marks=(), hlines=(), legend_x=360):
    def X(v): return x0 + v / xmax * (x1 - x0)
    def Y(v):
        if log: return y1 - (math.log10(max(v, ymin)) - math.log10(ymin)) / (math.log10(ymax) - math.log10(ymin)) * (y1 - y0)
        return y1 - (v - ymin) / (ymax - ymin) * (y1 - y0)
    o = [f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg" font-family="Inter">',
         f'<text x="6" y="14" font-size="10.4" font-weight="700" fill="#18202c">{title}</text>']
    for t in yticks:
        o.append(f'<line x1="{x0}" y1="{Y(t):.1f}" x2="{x1}" y2="{Y(t):.1f}" stroke="#e5e7eb"/><text x="{x0-4}" y="{Y(t)+3:.1f}" font-size="8.4" text-anchor="end" fill="#6b7280">{str(t).replace(".", ",")}</text>')
    o.append(f'<text x="{x0-4}" y="{y0-8}" font-size="8.4" text-anchor="end" fill="#6b7280">{ylabel}</text>')
    step = 10 if xmax <= 130 else 20
    for t in range(0, int(xmax) + 1, step):
        o.append(f'<text x="{X(t):.1f}" y="{y1+13}" font-size="8.4" text-anchor="middle" fill="#6b7280">{t}s</text>')
    for (xv, label, col) in marks:
        o.append(f'<line x1="{X(xv):.1f}" y1="{y0}" x2="{X(xv):.1f}" y2="{y1}" stroke="{col}" stroke-dasharray="3 2"/><text x="{(X(xv)-3 if X(xv)>x1-80 else X(xv)+3):.1f}" y="{y0+8}" font-size="8.2" text-anchor="{'end' if X(xv)>x1-80 else 'start'}" fill="{col}">{label}</text>')
    for (yv, label, col) in hlines:
        o.append(f'<line x1="{x0}" y1="{Y(yv):.1f}" x2="{x1}" y2="{Y(yv):.1f}" stroke="{col}" stroke-dasharray="5 3"/><text x="{x1-2}" y="{Y(yv)-3:.1f}" font-size="8.2" text-anchor="end" fill="{col}">{label}</text>')
    lx = legend_x
    for name, col, pts in series:
        d = ' '.join(f'{"M" if i == 0 else "L"}{X(x):.1f},{Y(y):.1f}' for i, (x, y) in enumerate(pts))
        o.append(f'<path d="{d}" fill="none" stroke="{col}" stroke-width="1.6"/>')
        o.append(f'<rect x="{lx}" y="20" width="10" height="3" fill="{col}"/><text x="{lx+14}" y="24" font-size="8.6" fill="#374151">{name}</text>'); lx += 24 + len(name) * 4.9
    o.append('</svg>')
    return '\n'.join(o)

# ---- KB1: CPU và p99 webhook, v1 (0–40 s) rồi v2 (40–120 s)
m1, m2 = load_mon(R / 'kb1/mon_v1.txt'), load_mon(R / 'kb1/mon_v2.txt')
cpu = [(t, c) for t, c, _, _ in m1 if t <= 40] + [(40 + t, c) for t, c, _, _ in m2 if t <= 80]
w1, w2 = load_tl(R / 'kb1/load_webhook_v1.txt'), load_tl(R / 'kb1/load_webhook_v2.txt')
c1, c2 = load_tl(R / 'kb1/load_catalog_v1.txt'), load_tl(R / 'kb1/load_catalog_v2.txt')
p99w = [(t, p) for t, n, p, e in w1] + [(40 + t, p) for t, n, p, e in w2]
p99c = [(t, p) for t, n, p, e in c1] + [(40 + t, p) for t, n, p, e in c2]
(D / 'fig_kb1_cpu.svg').write_text(chart('Kịch bản 1 — CPU của tiến trình (100% = 1 lõi, pod 2 vCPU)', [('CPU', '#b91c1c', cpu)], 120, 0, 200, [0, 50, 100, 150, 200], '%',
      marks=[(40, 'deploy v2', '#6d28d9')], H=150, y1=120))
(D / 'fig_kb1_p99.svg').write_text(chart('Kịch bản 1 — p99 mỗi giây (ms, thang log)', [('/webhook', '#b91c1c', p99w), ('/catalog', '#1d4ed8', p99c)], 120, 1, 10000,
      [1, 10, 100, 1000, 10000], 'ms', log=True, marks=[(40, 'deploy v2', '#6d28d9')]))
# ---- KB2: p99 catalog mỗi giây, mốc refresh và Full GC
k2 = load_tl(R / 'kb2/load_catalog.txt')
(D / 'fig_kb2.svg').write_text(chart('Kịch bản 2 — /catalog p99 mỗi giây (ms, thang log), 200 rps', [('p99 /catalog', '#b45309', [(t, p) for t, n, p, e in k2])], 62, 1, 1000,
      [1, 10, 100, 1000], 'ms', log=True, marks=[(14, 'refresh', '#6b7280'), (29, 'refresh', '#6b7280'), (44, 'refresh', '#6b7280'), (59, 'refresh + Full GC', '#b91c1c')]))
# ---- KB3: RSS, cgroup, threads
m3 = load_mon(R / 'kb3/mon_svc.txt')
cg = []
for l in open(R / 'kb3/cgroup.txt'):
    m = re.match(r't=(\d+)s cgroup usage (\d+) MB', l); cg.append((int(m.group(1)), int(m.group(2))))
(D / 'fig_kb3.svg').write_text(chart('Kịch bản 3 — bộ nhớ của pod (MB) cho tới khi bị kill', [('RSS tiến trình', '#1d4ed8', [(t, r) for t, c, r, th in m3]), ('memory cgroup (cái kernel tính)', '#b91c1c', cg),
      ('số thread ÷ 20', '#047857', [(t, th / 20) for t, c, r, th in m3])], 100, 0, 600, [0, 100, 200, 300, 400, 500, 600], 'MB',
      hlines=[(512, 'limits.memory = 512 MB', '#b91c1c')], marks=[(91, 'OOMKilled (137)', '#b91c1c')], legend_x=250))
print('ok')
