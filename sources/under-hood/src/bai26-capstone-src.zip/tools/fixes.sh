#!/bin/bash
# Kiểm chứng bản sửa: KB2 với catalog.fix, KB3 với export.fix (cùng tải, cùng giới hạn bộ nhớ).
source tools/common.sh
D=fix; rm -rf $D; mkdir -p $D
echo $((800*1024*1024)) > $CG/memory.limit_in_bytes
start_svc $D kb2 -Xmx512m -Dcatalog.refresh=15 -Dcatalog.fix=true "-Xlog:gc:file=$PWD/$D/gc_kb2.log:uptime"
$J/java -Dstdout.encoding=UTF-8 -cp cls lab26.LoadTL 200 62 400 "/catalog?id=42:1" > $D/load_kb2.txt 2>&1; kill $P; pause 1.5
echo $((512*1024*1024)) > $CG/memory.limit_in_bytes
start_svc $D kb3 -Dexport.fix=true
$J/java -Dstdout.encoding=UTF-8 -cp cls lab26.LoadTL 20 100 50 "/export:1" > $D/load_kb3.txt 2>&1 & L1=$!
$J/java -Dstdout.encoding=UTF-8 -cp cls lab26.LoadTL 50 100 100 "/catalog?id=7:1" > $D/load_kb3c.txt 2>&1
wait $L1; kill $P; pause 1.5
echo DONE > $D/done
