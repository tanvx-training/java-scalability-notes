#!/bin/bash
source tools/common.sh
D=fix; echo $((800*1024*1024)) > $CG/memory.limit_in_bytes
start_svc $D kb2g1 -Xmx512m -XX:+UseG1GC -Dcatalog.refresh=15 -Dcatalog.fix=true "-Xlog:gc:file=$PWD/$D/gc_kb2g1.log:uptime"
$J/java -Dstdout.encoding=UTF-8 -cp cls lab26.LoadTL 200 62 400 "/catalog?id=42:1" > $D/load_kb2g1.txt 2>&1; kill $P; pause 1.5
