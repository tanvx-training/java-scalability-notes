package lab26;
/** Dò thời gian của một regex trên đầu vào hỏng, theo độ dài: java RegexProbe <regex> <ký tự lặp> <hậu tố> */
public class RegexProbe {
    public static void main(String[] a) {
        String rx = a[0], unit = a.length > 1 ? a[1] : "x", suffix = a.length > 2 ? a[2] : "!";
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(rx);
        for (int n = 12; n <= 28; n += 2) {
            String s = unit.repeat(n) + suffix;
            long t = System.nanoTime(); boolean m = p.matcher(s).matches(); long d = System.nanoTime() - t;
            System.out.printf("n=%2d  khớp=%b  %10.2f ms%n", n, m, d / 1e6);
            if (d > 3_000_000_000L) break;
        }
    }
}
