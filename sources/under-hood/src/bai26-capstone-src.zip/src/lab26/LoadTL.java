package lab26;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.concurrent.locks.LockSupport;

/**
 * Tải open-loop như Bài 19–25, thêm DÒNG THỜI GIAN mỗi giây (p50/p99/max/lỗi) — thứ dashboard của bạn vẽ.
 *   java lab26.LoadTL <rps> <giây> <số kết nối> <path1:trọng số,path2:trọng số,...> [port]
 * Độ trễ tính từ thời điểm request lẽ ra được gửi; request được xếp vào giây mà nó lẽ ra được gửi.
 */
public class LoadTL {
    record Sample(int sec, long nanos, int code) {}
    public static void main(String[] a) throws Exception {
        int rate = Integer.parseInt(a[0]), sec = Integer.parseInt(a[1]), conns = Integer.parseInt(a[2]);
        List<String> paths = new ArrayList<>();
        for (String pw : a[3].split(",")) { String[] x = pw.split(":"); for (int i = 0; i < Integer.parseInt(x[1]); i++) paths.add(x[0]); }
        int port = a.length > 4 ? Integer.parseInt(a[4]) : 8080;
        long interval = 1_000_000_000L * conns / rate;
        long start = System.nanoTime() + 300_000_000L, end = start + sec * 1_000_000_000L;
        Queue<Sample> out = new ConcurrentLinkedQueue<>();
        AtomicLong seq = new AtomicLong();
        List<Thread> ts = new ArrayList<>();
        for (int t = 0; t < conns; t++) {
            final int id = t;
            ts.add(Thread.ofVirtual().start(() -> {
                Socket s = null; InputStream in = null; OutputStream os = null;
                long next = start + id * (interval / conns);
                while (next < end) {
                    long now;
                    while ((now = System.nanoTime()) < next) LockSupport.parkNanos(next - now);
                    String path = paths.get((int) (seq.getAndIncrement() % paths.size()));
                    int code = -1;
                    try {
                        if (s == null) { s = new Socket(); s.setTcpNoDelay(true); s.connect(new InetSocketAddress("127.0.0.1", port), 2000); s.setSoTimeout(30000);
                            in = new BufferedInputStream(s.getInputStream(), 8192); os = s.getOutputStream(); }
                        os.write(("GET " + path + " HTTP/1.1\r\nHost: 127.0.0.1\r\n\r\n").getBytes(StandardCharsets.US_ASCII)); os.flush();
                        code = readResponse(in);
                        if (code < 0) { s.close(); s = null; }
                    } catch (IOException e) { try { if (s != null) s.close(); } catch (IOException ignored) {} s = null; }
                    out.add(new Sample((int) ((next - start) / 1_000_000_000L), System.nanoTime() - next, code));
                    next += interval;
                }
                try { if (s != null) s.close(); } catch (IOException ignored) {}
            }));
        }
        for (Thread t : ts) t.join();
        Map<Integer, List<Sample>> bySec = new TreeMap<>();
        for (Sample x : out) bySec.computeIfAbsent(x.sec(), k -> new ArrayList<>()).add(x);
        List<Long> all = new ArrayList<>(); int allErr = 0;
        for (var e : bySec.entrySet()) {
            long[] l = e.getValue().stream().filter(x -> x.code() == 200).mapToLong(Sample::nanos).sorted().toArray();
            int err = (int) e.getValue().stream().filter(x -> x.code() != 200).count(); allErr += err;
            for (long v : l) all.add(v);
            System.out.printf("t=%3ds  n=%4d  p50 %8.1f  p99 %8.1f  max %8.1f ms  lỗi %d%n", e.getKey(), l.length,
                    l.length == 0 ? 0 : l[l.length / 2] / 1e6, l.length == 0 ? 0 : l[Math.min(l.length - 1, (int) (l.length * 0.99))] / 1e6,
                    l.length == 0 ? 0 : l[l.length - 1] / 1e6, err);
        }
        long[] l = all.stream().mapToLong(Long::longValue).sorted().toArray();
        System.out.printf("TỔNG %s: %d ok, %d lỗi | p50 %.1f  p99 %.1f  max %.1f ms%n", a[3], l.length, allErr,
                l.length == 0 ? 0 : l[l.length / 2] / 1e6, l.length == 0 ? 0 : l[Math.min(l.length - 1, (int) (l.length * 0.99))] / 1e6, l.length == 0 ? 0 : l[l.length - 1] / 1e6);
    }

    static int readResponse(InputStream in) throws IOException {
        StringBuilder line = new StringBuilder(); int c, len = 0, code = -1; boolean first = true;
        while (true) {
            line.setLength(0);
            while ((c = in.read()) != -1 && c != '\n') if (c != '\r') line.append((char) c);
            if (c == -1) return -1;
            if (line.length() == 0) break;
            String ln = line.toString();
            if (first) { code = Integer.parseInt(ln.split(" ")[1]); first = false; }
            else if (ln.regionMatches(true, 0, "content-length:", 0, 15)) len = Integer.parseInt(ln.substring(15).trim());
        }
        for (int i = 0; i < len; i++) if (in.read() == -1) return -1;
        return code;
    }
}
