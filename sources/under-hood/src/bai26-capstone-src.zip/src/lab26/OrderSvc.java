package lab26;

import com.sun.net.httpserver.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.Pattern;

/**
 * Service "đơn hàng" cho ba kịch bản sự cố. Mọi lỗi đều là lỗi thường gặp, viết như code thật:
 *   /webhook?row=…  nhận một dòng CSV từ đối tác; v1 tách cột bằng split, v2 ("refactor" của bản deploy mới) dùng regex
 *   /catalog?id=…   đọc catalog trong bộ nhớ; một job định kỳ dựng lại catalog trong khi giữ cùng khoá
 *   /export         xuất báo cáo, "song song cho nhanh" bằng một thread pool mới mỗi request — và quên shutdown
 */
public class OrderSvc {
    static final int VERSION = Integer.getInteger("version", 1);
    static final Pattern PAID_V2 = Pattern.compile("^(.*?,){11}PAID.*");             // cột thứ 12 là PAID?

    static boolean isPaid(String row) {
        if (VERSION == 1) { String[] c = row.split(","); return c.length > 11 && c[11].startsWith("PAID"); }
        return PAID_V2.matcher(row).matches();
    }

    // ---- catalog: Map lớn, đọc và dựng lại dưới cùng một khoá
    static final boolean CATALOG_FIX = Boolean.getBoolean("catalog.fix");
    static volatile Map<Integer, String> catalog = new HashMap<>();
    static String product(int id) {
        if (CATALOG_FIX) return catalog.getOrDefault(id, "?");                           // bản sửa: đọc tham chiếu volatile, không khoá
        synchronized (OrderSvc.class) { return catalog.getOrDefault(id, "?"); }
    }
    static void rebuildCatalog() {                                                       // @Scheduled(fixedRate = 15 s)
        if (CATALOG_FIX) { catalog = build(); return; }                                  // bản sửa: dựng ngoài khoá, rồi thay một phát
        synchronized (OrderSvc.class) { catalog = build(); }
    }
    static Map<Integer, String> build() {
        Map<Integer, String> m = new HashMap<>();
        for (int i = 0; i < 600_000; i++) m.put(i, "product-" + i + "-" + Integer.toHexString(i * 31));
        return Collections.unmodifiableMap(m);
    }

    // ---- export: thread pool mới cho mỗi request
    static final boolean EXPORT_FIX = Boolean.getBoolean("export.fix");
    static final ExecutorService SHARED = Executors.newFixedThreadPool(4);             // bản sửa: một pool dùng chung
    static String export() throws Exception {
        ExecutorService pool = EXPORT_FIX ? SHARED : Executors.newFixedThreadPool(4);      // bản lỗi: pool mới mỗi request, không shutdown
        List<Future<Integer>> parts = new ArrayList<>();
        for (int p = 0; p < 4; p++) { final int k = p; parts.add(pool.submit(() -> k * 1000 + 7)); }
        int sum = 0; for (Future<Integer> f : parts) sum += f.get();
        return "{\"rows\":" + sum + "}";
    }

    static void reply(HttpExchange ex, int code, String body) throws IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        ex.sendResponseHeaders(code, b.length);
        try (OutputStream o = ex.getResponseBody()) { o.write(b); }
    }
    static String q(HttpExchange ex, String k) {
        String qs = ex.getRequestURI().getRawQuery();
        if (qs != null) for (String p : qs.split("&")) if (p.startsWith(k + "=")) return URLDecoder.decode(p.substring(k.length() + 1), StandardCharsets.UTF_8);
        return "";
    }

    public static void main(String[] a) throws Exception {
        rebuildCatalog();
        int every = Integer.getInteger("catalog.refresh", 0);
        if (every > 0) Executors.newSingleThreadScheduledExecutor(r -> { Thread t = new Thread(r, "catalog-refresh"); t.setDaemon(true); return t; })
                .scheduleAtFixedRate(OrderSvc::rebuildCatalog, every, every, TimeUnit.SECONDS);
        HttpServer s = HttpServer.create(new InetSocketAddress("127.0.0.1", 8080), 4096);
        s.setExecutor(Executors.newFixedThreadPool(100, r -> { Thread t = new Thread(r); t.setName("http-nio-exec-" + t.threadId()); return t; }));
        s.createContext("/", h -> {
            try {
                switch (h.getRequestURI().getPath()) {
                    case "/webhook" -> reply(h, 200, isPaid(q(h, "row")) ? "{\"paid\":true}" : "{\"paid\":false}");
                    case "/catalog" -> reply(h, 200, product(Integer.parseInt(q(h, "id"))));
                    case "/export"  -> reply(h, 200, export());
                    case "/health"  -> reply(h, 200, "{\"status\":\"UP\"}");
                    default -> reply(h, 404, "{}");
                }
            } catch (Exception e) { try { reply(h, 500, "{}"); } catch (IOException ignored) {} }
        });
        s.start();
        System.out.println("ready version=" + VERSION + " pid " + ProcessHandle.current().pid());
    }
}
