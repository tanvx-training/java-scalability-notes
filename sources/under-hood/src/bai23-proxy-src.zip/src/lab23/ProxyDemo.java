package lab23;

import java.lang.reflect.*;
import java.nio.file.Path;
import java.util.*;
import lab23.app.*;
import lab23.proxy.*;

/** Self-invocation, final method, @Configuration — dựng lại cơ chế của Spring AOP bằng JDK thuần. */
public class ProxyDemo {
    public static void main(String[] a) throws Throwable {
        String mode = a.length > 0 ? a[0] : "all";

        // ---- 1) JDK dynamic proxy (khi bean chỉ được proxy qua interface)
        if (mode.equals("all") || mode.equals("jdk")) {
            OrderService target = new OrderService();
            OrderApi proxy = (OrderApi) Proxy.newProxyInstance(OrderApi.class.getClassLoader(), new Class<?>[]{OrderApi.class},
                (p, m, args) -> {
                    Method impl = target.getClass().getMethod(m.getName(), m.getParameterTypes());   // đọc @Tx trên class thật
                    return TxInterceptor.around(impl, () -> m.invoke(target, args));                   // như AopUtils.invokeJoinpointUsingReflection
                });
            System.out.println("[JDK proxy] class = " + proxy.getClass().getName() + ", module = " + proxy.getClass().getModule().getName()
                    + ", là OrderService? " + (proxy instanceof OrderService));
            System.out.println("  proxy.placeOrder(\"A-1\"):");
            proxy.placeOrder("A-1");
        }

        // ---- 2) proxy kiểu CGLIB, ủy quyền cho target riêng (Spring AOP, mặc định của Spring Boot)
        if (mode.equals("all") || mode.equals("cglib")) {
            OrderService target = new OrderService();
            MiniCglib.Generated g = MiniCglib.subclass(OrderService.class, false);
            MiniCglib.dump(g, Path.of("gen"));
            OrderService proxy = (OrderService) MiniCglib.instantiateWithoutConstructor(g.type());   // như Objenesis
            g.type().getField("$cb").set(proxy, (Interceptor) (p, m, idx, args) -> {
                return TxInterceptor.around(m, () -> {
                    try { return m.invoke(target, args); } catch (InvocationTargetException e) { throw e.getCause(); }
                });
            });
            System.out.println("\n[proxy lớp con] class = " + proxy.getClass().getName() + ", superclass = " + proxy.getClass().getSuperclass().getSimpleName());
            System.out.println("  proxy.placeOrder(\"B-2\"):");
            proxy.placeOrder("B-2");
            System.out.println("  proxy.audit(\"B-2\") gọi từ bên ngoài:");
            proxy.audit("B-2");
            target.self = proxy;
            System.out.println("  proxy.placeOrderViaSelf(\"B-3\")   // target.self = proxy:");
            proxy.placeOrderViaSelf("B-3");
            System.out.println("  target.eventCount() = " + target.eventCount());
            try { System.out.println("  proxy.eventCount() = " + proxy.eventCount()); }
            catch (NullPointerException e) { System.out.println("  proxy.eventCount() → NullPointerException: " + e.getMessage()); }
        }

        // ---- 3) @Configuration: lớp con gọi super + "bean factory" nhớ singleton
        if (mode.equals("all") || mode.equals("config")) {
            AppConfig plain = new AppConfig();
            System.out.println("\n[@Configuration(proxyBeanMethods = false)] cùng một Repo? " + (plain.orderSvc().repo == plain.paymentSvc().repo));
            MiniCglib.Generated g = MiniCglib.subclass(AppConfig.class, true);
            AppConfig cfg = (AppConfig) g.type().getConstructor().newInstance();
            Map<String, Object> singletons = new HashMap<>();
            g.type().getField("$cb").set(cfg, (Interceptor) (p, m, idx, args) -> {
                Object bean = singletons.get(m.getName());
                if (bean != null) return bean;                                     // như resolveBeanReference → beanFactory.getBean
                bean = p.getClass().getMethod(m.getName() + "$super", m.getParameterTypes()).invoke(p, args);   // như invokeSuper
                singletons.put(m.getName(), bean);
                return bean;
            });
            System.out.println("[@Configuration (mặc định, lớp con gọi super)] cùng một Repo? " + (cfg.orderSvc().repo == cfg.paymentSvc().repo));
        }
    }
}
