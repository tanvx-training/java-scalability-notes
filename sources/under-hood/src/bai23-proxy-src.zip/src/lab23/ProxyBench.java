package lab23;

import java.lang.management.ManagementFactory;
import java.lang.reflect.*;
import lab23.proxy.*;

/** Giá của một lần gọi qua proxy (chưa có advice nào): trực tiếp vs JDK proxy vs proxy lớp con. */
public class ProxyBench {
    public interface Echo { String echo(String s); }
    public static class EchoImpl implements Echo { public String echo(String s) { return s; } }

    static final com.sun.management.ThreadMXBean MX = (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
    static volatile Object sink;

    public static void main(String[] a) throws Throwable {
        EchoImpl target = new EchoImpl();
        long t0 = System.nanoTime();
        Echo jdk = (Echo) Proxy.newProxyInstance(Echo.class.getClassLoader(), new Class<?>[]{Echo.class},
                (p, m, args) -> m.invoke(target, args));
        long t1 = System.nanoTime();
        MiniCglib.Generated g = MiniCglib.subclass(EchoImpl.class, false);
        EchoImpl sub = (EchoImpl) MiniCglib.instantiateWithoutConstructor(g.type());
        g.type().getField("$cb").set(sub, (Interceptor) (p, m, idx, args) -> m.invoke(target, args));
        long t2 = System.nanoTime();
        System.out.printf("tạo class + instance lần đầu: JDK proxy %.1f ms, proxy lớp con %.1f ms%n", (t1 - t0) / 1e6, (t2 - t1) / 1e6);

        String[] in = new String[16]; for (int i = 0; i < 16; i++) in[i] = "x".repeat(i + 1);
        String[] names = {"gọi trực tiếp", "JDK proxy → Method.invoke", "proxy lớp con → Method.invoke"};
        int n = 5_000_000;
        for (int k = 0; k < 3; k++) {
            double[] ns = new double[7]; double bytes = 0;
            for (int w = 0; w < 8; w++) sink = run(k, target, jdk, sub, in, n);
            for (int r = 0; r < 7; r++) {
                long b0 = MX.getThreadAllocatedBytes(Thread.currentThread().getId()), s = System.nanoTime();
                sink = run(k, target, jdk, sub, in, n);
                long d = System.nanoTime() - s;
                bytes = (MX.getThreadAllocatedBytes(Thread.currentThread().getId()) - b0) / (double) n; ns[r] = d / (double) n;
            }
            java.util.Arrays.sort(ns);
            System.out.printf("  %-32s %6.2f ns/lần   %5.1f byte/lần%n", names[k], ns[3], bytes);
        }
    }
    static long run(int k, EchoImpl t, Echo j, EchoImpl s, String[] in, int n) {
        return k == 0 ? direct(t, in, n) : k == 1 ? viaJdk(j, in, n) : viaSub(s, in, n);
    }
    static long direct(EchoImpl e, String[] in, int n) { long s = 0; for (int i = 0; i < n; i++) s += e.echo(in[i & 15]).length(); return s; }
    static long viaJdk(Echo e, String[] in, int n)     { long s = 0; for (int i = 0; i < n; i++) s += e.echo(in[i & 15]).length(); return s; }
    static long viaSub(EchoImpl e, String[] in, int n) { long s = 0; for (int i = 0; i < n; i++) s += e.echo(in[i & 15]).length(); return s; }
}
