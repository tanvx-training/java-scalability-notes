package lab23;

import java.lang.reflect.Method;

/** Method.invoke bên trong: JDK 17 "inflation" sinh class sau 15 lần gọi; JDK 18+ dùng MethodHandle. */
public class Reflect {
    public int add(int a, int b) {
        if (a == 99) {                                   // in stack trace một lần để thấy các frame của reflection
            StackTraceElement[] st = new Throwable().getStackTrace();
            for (int i = 0; i < Math.min(st.length, 6); i++) System.out.println("    at " + st[i]);
        }
        return a + b;
    }

    public static void main(String[] args) throws Exception {
        Method m = Reflect.class.getMethod("add", int.class, int.class);
        Reflect r = new Reflect();
        for (int i = 1; i <= 20; i++) {
            if (i >= 14 && i <= 18) System.out.println("-- lần gọi Method.invoke thứ " + i);
            m.invoke(r, i, i);
        }
        System.out.println("-- stack trace bên trong method được gọi qua reflection (lần thứ 21):");
        m.invoke(r, 99, 1);
    }

}
