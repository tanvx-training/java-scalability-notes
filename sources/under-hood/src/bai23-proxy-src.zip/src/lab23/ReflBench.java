package lab23;

import java.lang.invoke.*;
import java.lang.management.ManagementFactory;
import java.lang.reflect.Method;
import java.util.function.IntBinaryOperator;

/** Đo tay (chạy được cả JDK 17): gọi trực tiếp, Method.invoke, MethodHandle, lambda sinh từ LambdaMetafactory. */
public class ReflBench {
    public int add(int a, int b) { return a + b; }

    static final ReflBench T = new ReflBench();
    static final Method M_CONST;
    static Method mField;                                     // không final: JIT không coi là hằng
    static final MethodHandle MH_CONST;
    static MethodHandle mhField;
    static final IntBinaryOperator LMF;
    static {
        try {
            M_CONST = ReflBench.class.getMethod("add", int.class, int.class); mField = M_CONST;
            MethodHandles.Lookup l = MethodHandles.lookup();
            MH_CONST = l.findVirtual(ReflBench.class, "add", MethodType.methodType(int.class, int.class, int.class)).bindTo(T);
            mhField = MH_CONST;
            CallSite cs = LambdaMetafactory.metafactory(l, "applyAsInt", MethodType.methodType(IntBinaryOperator.class, ReflBench.class),
                    MethodType.methodType(int.class, int.class, int.class),
                    l.findVirtual(ReflBench.class, "add", MethodType.methodType(int.class, int.class, int.class)),
                    MethodType.methodType(int.class, int.class, int.class));
            LMF = (IntBinaryOperator) cs.getTarget().invoke(T);
        } catch (Throwable e) { throw new ExceptionInInitializerError(e); }
    }
    static final com.sun.management.ThreadMXBean MX = (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
    static volatile int sink;

    interface Op { int run(int n) throws Throwable; }

    public static void main(String[] a) throws Throwable {
        String[] names = {"gọi trực tiếp", "Method.invoke (static final)", "Method.invoke (field thường)",
                          "MethodHandle (static final)", "MethodHandle (field thường)", "LambdaMetafactory"};
        Op[] ops = {
            n -> { int s = 0; for (int i = 0; i < n; i++) s += T.add(i, 1); return s; },
            n -> { int s = 0; for (int i = 0; i < n; i++) s += (Integer) M_CONST.invoke(T, i, 1); return s; },
            n -> { int s = 0; for (int i = 0; i < n; i++) s += (Integer) mField.invoke(T, i, 1); return s; },
            n -> { int s = 0; for (int i = 0; i < n; i++) s += (int) MH_CONST.invokeExact(i, 1); return s; },
            n -> { int s = 0; for (int i = 0; i < n; i++) s += (int) mhField.invokeExact(i, 1); return s; },
            n -> { int s = 0; for (int i = 0; i < n; i++) s += LMF.applyAsInt(i, 1); return s; },
        };
        int n = 5_000_000;
        System.out.printf("JDK %s%n", Runtime.version().feature());
        for (int k = 0; k < ops.length; k++) {
            for (int w = 0; w < 8; w++) sink = ops[k].run(n);           // khởi động
            double[] ns = new double[7]; double bytes = 0;
            for (int r = 0; r < 7; r++) {
                long b0 = MX.getThreadAllocatedBytes(Thread.currentThread().getId());
                long t0 = System.nanoTime(); sink = ops[k].run(n); long t1 = System.nanoTime();
                bytes = (MX.getThreadAllocatedBytes(Thread.currentThread().getId()) - b0) / (double) n;
                ns[r] = (t1 - t0) / (double) n;
            }
            java.util.Arrays.sort(ns);
            System.out.printf("  %-30s %6.2f ns/lần   %5.1f byte/lần%n", names[k], ns[3], bytes);
        }
    }
}
