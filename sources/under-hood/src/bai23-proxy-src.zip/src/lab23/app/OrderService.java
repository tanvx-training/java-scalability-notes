package lab23.app;

import java.util.*;

public class OrderService implements OrderApi {
    private final List<String> events = new ArrayList<>();   // khởi tạo trong constructor
    public OrderService self;                                 // vai trò của "@Autowired @Lazy OrderService self"

    @Tx
    public String placeOrder(String sku) {
        System.out.println("      placeOrder chạy trên: " + getClass().getSimpleName());
        events.add("order " + sku);
        audit(sku);                                           // this.audit(sku) — tự gọi
        return "ok:" + sku;
    }

    @Tx("REQUIRES_NEW")
    public void audit(String sku) {
        System.out.println("      audit chạy, tx hiện tại = " + lab23.proxy.TxInterceptor.current());
        events.add("audit " + sku);
    }

    @Tx
    public String placeOrderViaSelf(String sku) {
        events.add("order " + sku);
        self.audit(sku);                                      // gọi qua proxy
        return "ok:" + sku;
    }

    public final int eventCount() { return events.size(); }   // final: proxy kiểu lớp con không ghi đè được
}
