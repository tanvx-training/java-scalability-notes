package lab23.app;

/** Đóng vai một class @Configuration với hai @Bean dùng chung repo(). */
public class AppConfig {
    public static class Repo {}
    public static class Svc { public final Repo repo; public Svc(Repo r) { repo = r; } }
    public Repo repo() { return new Repo(); }
    public Svc orderSvc()   { return new Svc(repo()); }      // this.repo()
    public Svc paymentSvc() { return new Svc(repo()); }      // this.repo()
}
