package lab23.app;
public interface OrderApi {
    String placeOrder(String sku);
    void audit(String sku);
}
