package lab23.app;

import java.lang.annotation.*;

/** Đóng vai @Transactional: value = propagation. */
@Retention(RetentionPolicy.RUNTIME) @Target(ElementType.METHOD)
public @interface Tx { String value() default "REQUIRED"; }
