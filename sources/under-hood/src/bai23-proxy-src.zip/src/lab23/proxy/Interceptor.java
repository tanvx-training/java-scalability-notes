package lab23.proxy;

import java.lang.reflect.Method;

/** Callback mà class proxy sinh ra gọi tới — tương tự MethodInterceptor của CGLIB (method lấy từ field static final). */
public interface Interceptor { Object intercept(Object proxy, Method method, int methodIndex, Object[] args) throws Throwable; }
