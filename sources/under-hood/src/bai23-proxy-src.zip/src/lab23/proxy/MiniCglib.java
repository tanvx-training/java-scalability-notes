package lab23.proxy;

import java.lang.classfile.*;
import java.lang.constant.*;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import static java.lang.constant.ConstantDescs.*;

/**
 * Bộ sinh proxy "kiểu CGLIB" tối giản bằng ClassFile API (JDK 24+): sinh LỚP CON của class gốc,
 * ghi đè mọi method public không final, chuyển lời gọi tới Interceptor. Nếu withSuper = true,
 * sinh thêm method name$super(...) gọi invokespecial lên class cha (như invokeSuper của CGLIB).
 */
public final class MiniCglib {
    public record Generated(Class<?> type, List<Method> methods, byte[] bytes) {}
    private static int counter;
    static final ClassDesc CD_ICPT = ClassDesc.of(Interceptor.class.getName());

    public static Generated subclass(Class<?> base, boolean withSuper) throws Exception {
        List<Method> ms = new ArrayList<>();
        for (Method m : base.getMethods()) {
            int mod = m.getModifiers();
            if (m.getDeclaringClass() == Object.class || Modifier.isFinal(mod) || Modifier.isStatic(mod)) continue;
            ms.add(m);
        }
        ms.sort(Comparator.comparing(Method::getName));
        ClassDesc self = ClassDesc.of(base.getName() + "$$MiniCGLIB$$" + (counter++));
        ClassDesc sup = base.describeConstable().orElseThrow();
        byte[] bytes = ClassFile.of().build(self, cb -> {
            cb.withFlags(ClassFile.ACC_PUBLIC | ClassFile.ACC_SUPER);
            cb.withSuperclass(sup);
            cb.withField("$cb", CD_ICPT, ClassFile.ACC_PUBLIC);
            ClassDesc CD_Method = ClassDesc.of("java.lang.reflect.Method");
            for (int idx = 0; idx < ms.size(); idx++)
                cb.withField("$m" + idx, CD_Method, ClassFile.ACC_PRIVATE | ClassFile.ACC_STATIC | ClassFile.ACC_FINAL);
            cb.withMethodBody(CLASS_INIT_NAME, MTD_void, ClassFile.ACC_STATIC, c -> {        // như CGLIB$STATICHOOK: tra Method một lần
                for (int idx = 0; idx < ms.size(); idx++) {
                    Method m = ms.get(idx);
                    c.ldc(sup).ldc(m.getName());
                    Class<?>[] ps = m.getParameterTypes();
                    c.loadConstant(ps.length).anewarray(CD_Class);
                    for (int i = 0; i < ps.length; i++) {
                        c.dup().loadConstant(i);
                        if (ps[i].isPrimitive()) { ClassDesc w = desc(MethodType_wrap(ps[i])); c.getstatic(w, "TYPE", CD_Class); }
                        else c.ldc(desc(ps[i]));
                        c.aastore();
                    }
                    c.invokevirtual(CD_Class, "getMethod", MethodTypeDesc.of(CD_Method, CD_String, CD_Class.arrayType()));
                    c.putstatic(self, "$m" + idx, CD_Method);
                }
                c.return_();
            });
            cb.withMethodBody(INIT_NAME, MTD_void, ClassFile.ACC_PUBLIC, c -> c.aload(0).invokespecial(sup, INIT_NAME, MTD_void).return_());
            for (int idx = 0; idx < ms.size(); idx++) {
                Method m = ms.get(idx); final int k = idx;
                MethodTypeDesc mtd = desc(m);
                cb.withMethodBody(m.getName(), mtd, ClassFile.ACC_PUBLIC, c -> {
                    c.aload(0).getfield(self, "$cb", CD_ICPT).aload(0)
                     .getstatic(self, "$m" + k, ClassDesc.of("java.lang.reflect.Method")).loadConstant(k);
                    Class<?>[] ps = m.getParameterTypes();
                    c.loadConstant(ps.length).anewarray(CD_Object);
                    for (int i = 0; i < ps.length; i++) {
                        c.dup().loadConstant(i);
                        TypeKind tk = TypeKind.from(desc(ps[i]));
                        c.loadLocal(tk, c.parameterSlot(i));
                        box(c, ps[i]);
                        c.aastore();
                    }
                    c.invokeinterface(CD_ICPT, "intercept", MethodTypeDesc.of(CD_Object, CD_Object, ClassDesc.of("java.lang.reflect.Method"), CD_int, CD_Object.arrayType()));
                    ret(c, m.getReturnType());
                });
                if (withSuper) cb.withMethodBody(m.getName() + "$super", mtd, ClassFile.ACC_PUBLIC, c -> {
                    c.aload(0);
                    for (int i = 0; i < m.getParameterCount(); i++) c.loadLocal(TypeKind.from(desc(m.getParameterTypes()[i])), c.parameterSlot(i));
                    c.invokespecial(sup, m.getName(), mtd);
                    c.return_(TypeKind.from(desc(m.getReturnType())));
                });
            }
        });
        Class<?> type = MethodHandles.privateLookupIn(base, MethodHandles.lookup()).defineClass(bytes);
        return new Generated(type, ms, bytes);
    }

    static ClassDesc desc(Class<?> c) { return c.describeConstable().orElseThrow(); }
    static MethodTypeDesc desc(Method m) {
        return MethodTypeDesc.of(desc(m.getReturnType()), Arrays.stream(m.getParameterTypes()).map(MiniCglib::desc).toArray(ClassDesc[]::new));
    }
    static void box(CodeBuilder c, Class<?> p) {
        if (!p.isPrimitive()) return;
        ClassDesc w = desc(MethodType_wrap(p));
        c.invokestatic(w, "valueOf", MethodTypeDesc.of(w, desc(p)));
    }
    static void ret(CodeBuilder c, Class<?> r) {
        if (r == void.class) { c.pop().return_(); return; }
        if (r.isPrimitive()) {
            ClassDesc w = desc(MethodType_wrap(r));
            c.checkcast(w).invokevirtual(w, r.getName() + "Value", MethodTypeDesc.of(desc(r)));
            c.return_(TypeKind.from(desc(r)));
        } else { c.checkcast(desc(r)).areturn(); }
    }
    static Class<?> MethodType_wrap(Class<?> p) { return java.lang.invoke.MethodType.methodType(p).wrap().returnType(); }

    /** Giống Objenesis: tạo instance KHÔNG chạy constructor nào của class (field = null). */
    public static Object instantiateWithoutConstructor(Class<?> c) throws Exception {
        var rf = sun.reflect.ReflectionFactory.getReflectionFactory();
        return rf.newConstructorForSerialization(c, Object.class.getDeclaredConstructor()).newInstance();
    }

    public static void dump(Generated g, Path dir) throws Exception {
        Path p = dir.resolve(g.type().getName().replace('.', '/') + ".class");
        Files.createDirectories(p.getParent()); Files.write(p, g.bytes());
    }
}
