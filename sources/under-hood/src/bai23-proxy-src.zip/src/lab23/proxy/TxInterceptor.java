package lab23.proxy;

import java.lang.reflect.Method;
import lab23.app.Tx;

/** "TransactionInterceptor" tối giản: in BEGIN/COMMIT, hỗ trợ REQUIRED và REQUIRES_NEW. */
public final class TxInterceptor {
    private static final ThreadLocal<String> CURRENT = new ThreadLocal<>();
    private static int seq;
    public static String current() { return CURRENT.get(); }

    /** invoker: cách gọi tới code thật (reflection trên target, hoặc super). */
    public interface Invoker { Object call() throws Throwable; }

    public static Object around(Method m, Invoker invoker) throws Throwable {
        Tx tx = m.getAnnotation(Tx.class);
        if (tx == null || (tx.value().equals("REQUIRED") && CURRENT.get() != null)) return invoker.call();
        String outer = CURRENT.get(), id = "tx#" + (++seq);
        System.out.println("    BEGIN " + id + " (" + tx.value() + ") cho " + m.getName());
        CURRENT.set(id);
        try { Object r = invoker.call(); System.out.println("    COMMIT " + id); return r; }
        finally { CURRENT.set(outer); }
    }
}
