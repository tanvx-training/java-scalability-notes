package lab16;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.util.concurrent.atomic.AtomicInteger;

public class Asm {
    int p; volatile int v;
    static final VarHandle P;
    static { try { P = MethodHandles.lookup().findVarHandle(Asm.class, "p", int.class); } catch (Exception e) { throw new Error(e); } }

    void storePlain(int x)    { p = x; }
    void storeOpaque(int x)   { P.setOpaque(this, x); }
    void storeRelease(int x)  { P.setRelease(this, x); }
    void storeVolatile(int x) { v = x; }
    int  loadPlain()          { return p; }
    int  loadVolatile()       { return v; }
    int  loadAcquire()        { return (int) P.getAcquire(this); }
    void fence(int x)         { p = x; VarHandle.fullFence(); }
    int  incAtomic(AtomicInteger a) { return a.incrementAndGet(); }

    public static void main(String[] a) {
        Asm o = new Asm(); AtomicInteger ai = new AtomicInteger(); long s = 0;
        for (int i = 0; i < 200_000; i++) {
            o.storePlain(i); o.storeOpaque(i); o.storeRelease(i); o.storeVolatile(i);
            s += o.loadPlain() + o.loadVolatile() + o.loadAcquire(); o.fence(i); s += o.incAtomic(ai);
        }
        System.out.println(s);
    }
}
