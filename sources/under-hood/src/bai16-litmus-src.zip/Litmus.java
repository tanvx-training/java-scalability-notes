package lab16;

import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Bộ chạy litmus test tối giản theo cách của jcstress:
 * tạo một mảng N "state" mới, hai thread cùng chạy qua mảng (thread A gọi actor1,
 * thread B gọi actor2 trên CÙNG state thứ i gần như cùng lúc), rồi đếm kết quả.
 * Mỗi test chạy trong một JVM riêng để call site là monomorphic (JIT inline được).
 */
public final class Litmus {
    public interface Test<S> {
        S newState();
        void actor1(S s);
        void actor2(S s);
        int outcome(S s);            // mã hoá kết quả thành số nhỏ
        String label(int code);      // ví dụ "r1=0, r2=0"
        String verdict(int code);    // ACCEPTABLE / INTERESTING / FORBIDDEN
    }

    static volatile int epoch;       // HB giữa các lô (không phải giữa hai actor)
    static volatile int doneB;

    @SuppressWarnings("unchecked")
    public static <S> void run(Test<S> t, String name, int batch, double seconds) throws Exception {
        final Object[][] cur = new Object[1][];
        Thread b = new Thread(() -> {
            int seen = 0;
            while (true) {
                int e;
                while ((e = epoch) == seen) Thread.onSpinWait();
                if (e < 0) return;
                seen = e;
                Object[] arr = cur[0];
                for (Object o : arr) t.actor2((S) o);
                doneB = e;
            }
        }, "actor2");
        b.start();

        Map<Integer, Long> counts = new TreeMap<>();
        long t0 = System.nanoTime(), deadline = t0 + (long) (seconds * 1e9);
        long total = 0; int e = 0;
        while (System.nanoTime() < deadline) {
            Object[] arr = new Object[batch];
            for (int i = 0; i < batch; i++) arr[i] = t.newState();
            cur[0] = arr;
            epoch = ++e;                                 // thả thread B
            for (Object o : arr) t.actor1((S) o);         // thread A = main
            while (doneB != e) Thread.onSpinWait();
            for (Object o : arr) {
                int c = t.outcome((S) o);
                counts.merge(c, 1L, Long::sum);
            }
            total += batch;
        }
        epoch = -1; b.join();
        double secs = (System.nanoTime() - t0) / 1e9;
        System.out.printf("== %s  (%,d lần thử, %.1f s, JDK %s)%n", name, total, secs, Runtime.version());
        for (var en : counts.entrySet()) {
            System.out.printf("  %-22s %,15d  %s%n", t.label(en.getKey()), en.getValue(), t.verdict(en.getKey()));
        }
    }
}
