package lab16b;

import org.openjdk.jmh.annotations.*;
import java.lang.invoke.*;
import java.util.concurrent.TimeUnit;

@State(Scope.Thread)
@BenchmarkMode(Mode.AverageTime) @OutputTimeUnit(TimeUnit.NANOSECONDS)
@Warmup(iterations = 3, time = 1) @Measurement(iterations = 5, time = 1) @Fork(1)
@OperationsPerInvocation(1000)
public class VolCost {
    int p; volatile int v; volatile int w;
    static final VarHandle P;
    static { try { P = MethodHandles.lookup().findVarHandle(VolCost.class, "p", int.class); } catch (Exception e) { throw new Error(e); } }

    @Benchmark public void storePlain()    { for (int i = 0; i < 1000; i++) p = i; }
    @Benchmark public void storeOpaque()   { for (int i = 0; i < 1000; i++) P.setOpaque(this, i); }
    @Benchmark public void storeRelease()  { for (int i = 0; i < 1000; i++) P.setRelease(this, i); }
    @Benchmark public void storeVolatile() { for (int i = 0; i < 1000; i++) v = i; }
    @Benchmark public int storeLoadVolatile() { int s = 0; for (int i = 0; i < 1000; i++) { v = i; s += w; } return s; }
    @Benchmark public int storeLoadPlain()    { int s = 0; for (int i = 0; i < 1000; i++) { p = i; s += i; } return s; }
    @Benchmark public int loadPlain()      { int s = 0; for (int i = 0; i < 1000; i++) s += p; return s; }
    @Benchmark public int loadVolatile()   { int s = 0; for (int i = 0; i < 1000; i++) s += v; return s; }
}
