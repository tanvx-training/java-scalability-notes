package lab16;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;

/** Thread A quay vòng chờ cờ "running" thành false; main đặt cờ sau 1 giây. Có dừng không? */
public class Loop {
    static boolean running = true;              // plain
    static volatile boolean vrunning = true;    // volatile
    static boolean orunning = true;             // đọc bằng VarHandle opaque
    static final VarHandle OR;
    static { try { OR = MethodHandles.lookup().findStaticVarHandle(Loop.class, "orunning", boolean.class); } catch (Exception e) { throw new Error(e); } }
    static long sink;

    public static void main(String[] a) throws Exception {
        String mode = a[0];
        Runnable body = switch (mode) {
            case "plain" -> () -> { long i = 0; while (running) { i++; } sink = i; };
            case "plain-empty" -> () -> { while (running) { } };
            case "volatile" -> () -> { long i = 0; while (vrunning) { i++; } sink = i; };
            case "opaque" -> () -> { long i = 0; while ((boolean) OR.getOpaque()) { i++; } sink = i; };
            case "plain-sleep" -> () -> { long i = 0; while (running) { i++; try { Thread.sleep(0); } catch (InterruptedException e) {} } sink = i; };
            case "plain-println" -> () -> { long i = 0; while (running) { i++; if ((i & 0xFFFFF) == 0) System.out.print(""); } sink = i; };
            case "plain-onspin" -> () -> { long i = 0; while (running) { i++; Thread.onSpinWait(); } sink = i; };
            case "plain-sync" -> () -> { long i = 0; while (running) { i++; synchronized (Loop.class) { } } sink = i; };
            default -> throw new IllegalArgumentException(mode);
        };
        Thread t = new Thread(body, "spinner");
        t.setDaemon(true);
        t.start();
        Thread.sleep(1000);
        long t0 = System.nanoTime();
        running = false; vrunning = false; OR.setOpaque(false);
        t.join(5000);
        double ms = (System.nanoTime() - t0) / 1e6;
        System.out.printf("%-14s %s%n", mode, t.isAlive() ? "KHÔNG DỪNG (vẫn chạy sau 5 s)" : String.format("dừng sau %.2f ms", ms));
        System.exit(0);
    }
}
