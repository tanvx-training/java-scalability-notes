package lab16;

import java.util.concurrent.atomic.*;

/** Hai thread, mỗi thread tăng 50 triệu lần. Kết quả đúng: 100 000 000. */
public class Counter {
    static int plain; static volatile int vol; static int locked;
    static final AtomicInteger atomic = new AtomicInteger(); static final LongAdder adder = new LongAdder();
    static final int N = 50_000_000;

    public static void main(String[] a) throws Exception {
        String m = a[0];
        Runnable r = switch (m) {
            case "plain" -> () -> { for (int i = 0; i < N; i++) plain++; };
            case "volatile" -> () -> { for (int i = 0; i < N; i++) vol++; };
            case "synchronized" -> () -> { for (int i = 0; i < N; i++) synchronized (Counter.class) { locked++; } };
            case "AtomicInteger" -> () -> { for (int i = 0; i < N; i++) atomic.incrementAndGet(); };
            case "LongAdder" -> () -> { for (int i = 0; i < N; i++) adder.increment(); };
            default -> throw new IllegalArgumentException(m);
        };
        long t0 = System.nanoTime();
        Thread x = new Thread(r), y = new Thread(r); x.start(); y.start(); x.join(); y.join();
        double ms = (System.nanoTime() - t0) / 1e6;
        long v = switch (m) { case "plain" -> plain; case "volatile" -> vol; case "synchronized" -> locked;
            case "AtomicInteger" -> atomic.get(); default -> adder.sum(); };
        System.out.printf("%-14s kết quả %,13d  (mất %,11d)  %,8.0f ms%n", m, v, 2L * N - v, ms);
    }
}
