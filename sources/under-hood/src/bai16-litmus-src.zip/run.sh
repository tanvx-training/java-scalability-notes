#!/bin/bash
# run.sh <jdk> <test> <secs> [extra jvm flags...]
J=$1; T=$2; S=$3; shift 3
unset JAVA_TOOL_OPTIONS
/usr/lib/jvm/java-$J-openjdk-amd64/bin/java -Dstdout.encoding=UTF-8 -Xmx1g -XX:CompileCommand=quiet -XX:CompileCommand=dontinline,lab16.Tests\$Init::prepare "$@" -cp /home/claude/lab16/classes lab16.Tests $T $S
