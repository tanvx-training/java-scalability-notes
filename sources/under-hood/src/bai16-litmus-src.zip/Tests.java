package lab16;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;

/** Các litmus test của Bài 16. Chạy: java lab16.Tests <tên> [giây] [lô] */
public final class Tests {
    static final String OK = "ACCEPTABLE", INT = "INTERESTING (JMM cho phép)", BAD = "FORBIDDEN (JMM cấm!)";

    // ---------------- SB: store buffering / Dekker ----------------
    static final class SB { int x, y; int r1, r2; }
    static final class SBV { volatile int x, y; int r1, r2; }
    static final class SBA { int x, y; int r1, r2;
        static final VarHandle X, Y;
        static { try { var l = MethodHandles.lookup();
            X = l.findVarHandle(SBA.class, "x", int.class); Y = l.findVarHandle(SBA.class, "y", int.class);
        } catch (Exception e) { throw new Error(e); } } }

    static abstract class SBBase<S> implements Litmus.Test<S> {
        boolean forbid00;
        SBBase(boolean f) { forbid00 = f; }
        public String label(int c) { return "r1=" + (c >> 1) + ", r2=" + (c & 1); }
        public String verdict(int c) { return c == 0 ? (forbid00 ? BAD : INT) : OK; }
    }
    static final class SBPlain extends SBBase<SB> {
        SBPlain() { super(false); }
        public SB newState() { return new SB(); }
        public void actor1(SB s) { s.x = 1; s.r1 = s.y; }
        public void actor2(SB s) { s.y = 1; s.r2 = s.x; }
        public int outcome(SB s) { return s.r1 * 2 + s.r2; }
    }
    static final class SBVolatile extends SBBase<SBV> {
        SBVolatile() { super(true); }
        public SBV newState() { return new SBV(); }
        public void actor1(SBV s) { s.x = 1; s.r1 = s.y; }
        public void actor2(SBV s) { s.y = 1; s.r2 = s.x; }
        public int outcome(SBV s) { return s.r1 * 2 + s.r2; }
    }
    static final class SBAcqRel extends SBBase<SBA> {
        SBAcqRel() { super(false); }
        public SBA newState() { return new SBA(); }
        public void actor1(SBA s) { SBA.X.setRelease(s, 1); s.r1 = (int) SBA.Y.getAcquire(s); }
        public void actor2(SBA s) { SBA.Y.setRelease(s, 1); s.r2 = (int) SBA.X.getAcquire(s); }
        public int outcome(SBA s) { return s.r1 * 2 + s.r2; }
    }
    static final class SBFence extends SBBase<SB> {
        SBFence() { super(true); }
        public SB newState() { return new SB(); }
        public void actor1(SB s) { s.x = 1; VarHandle.fullFence(); s.r1 = s.y; }
        public void actor2(SB s) { s.y = 1; VarHandle.fullFence(); s.r2 = s.x; }
        public int outcome(SB s) { return s.r1 * 2 + s.r2; }
    }

    // ---------------- MP: message passing ----------------
    static final class MP { int data; int flag; int r0, r1, r2; }
    static final class MPV { int data; volatile int flag; int r0, r1, r2; }
    static abstract class MPBase<S> implements Litmus.Test<S> {
        boolean forbid;
        MPBase(boolean f) { forbid = f; }
        public String label(int c) { return "flag=" + (c >> 1) + ", data=" + (c & 1); }
        public String verdict(int c) { return c == 2 ? (forbid ? BAD : INT) : OK; }
    }
    static final class MPPlain extends MPBase<MP> {
        MPPlain() { super(false); }
        public MP newState() { return new MP(); }
        public void actor1(MP s) { s.data = 1; s.flag = 1; }
        public void actor2(MP s) { s.r1 = s.flag; s.r2 = s.data; }
        public int outcome(MP s) { return s.r1 * 2 + s.r2; }
    }
    static final class MPVolatile extends MPBase<MPV> {
        MPVolatile() { super(true); }
        public MPV newState() { return new MPV(); }
        public void actor1(MPV s) { s.data = 1; s.flag = 1; }
        public void actor2(MPV s) { s.r1 = s.flag; s.r2 = s.data; }
        public int outcome(MPV s) { return s.r1 * 2 + s.r2; }
    }
    /** Người đọc đã đọc data MỘT lần trước khi xem flag — compiler được phép dùng lại giá trị cũ. */
    static final class MPReread extends MPBase<MP> {
        MPReread() { super(false); }
        public MP newState() { return new MP(); }
        public void actor1(MP s) { s.data = 1; s.flag = 1; }
        public void actor2(MP s) { s.r0 = s.data; s.r1 = s.flag; s.r2 = s.data; }
        public int outcome(MP s) { return s.r1 * 2 + s.r2; }
    }
    static final class MPRereadV extends MPBase<MPV> {
        MPRereadV() { super(true); }
        public MPV newState() { return new MPV(); }
        public void actor1(MPV s) { s.data = 1; s.flag = 1; }
        public void actor2(MPV s) { s.r0 = s.data; s.r1 = s.flag; s.r2 = s.data; }
        public int outcome(MPV s) { return s.r1 * 2 + s.r2; }
    }

    // ---------------- Publication / DCL ----------------
    /** Object kiểu "cấu hình": constructor gọi một method rồi mới gán field. */
    static final class Conf { int port; Conf() { Init.prepare(); port = 8080; } }
    static final class ConfFinal { final int port; ConfFinal() { Init.prepare(); port = 8080; } }
    static final class Init { static int n; static void prepare() { n++; } }   // CompileCommand dontinline

    static final class Pub { Conf c; int r; }
    static final class PubF { ConfFinal c; int r; }
    static final class PubV { volatile Conf c; int r; }
    static String pubLabel(int c) { return c == 0 ? "thấy null" : c == 1 ? "thấy object, port=0" : "thấy object, port=8080"; }
    static String pubVerdict(int c, boolean forbid) { return c == 1 ? (forbid ? BAD : INT) : OK; }

    static final class PubPlain implements Litmus.Test<Pub> {
        public Pub newState() { return new Pub(); }
        public void actor1(Pub s) { s.c = new Conf(); }
        public void actor2(Pub s) { Conf c = s.c; s.r = c == null ? 0 : c.port == 0 ? 1 : 2; }
        public int outcome(Pub s) { return s.r; }
        public String label(int c) { return pubLabel(c); }
        public String verdict(int c) { return pubVerdict(c, false); }
    }
    static final class PubFinal implements Litmus.Test<PubF> {
        public PubF newState() { return new PubF(); }
        public void actor1(PubF s) { s.c = new ConfFinal(); }
        public void actor2(PubF s) { ConfFinal c = s.c; s.r = c == null ? 0 : c.port == 0 ? 1 : 2; }
        public int outcome(PubF s) { return s.r; }
        public String label(int c) { return pubLabel(c); }
        public String verdict(int c) { return pubVerdict(c, true); }
    }
    static final class PubVolatile implements Litmus.Test<PubV> {
        public PubV newState() { return new PubV(); }
        public void actor1(PubV s) { s.c = new Conf(); }
        public void actor2(PubV s) { Conf c = s.c; s.r = c == null ? 0 : c.port == 0 ? 1 : 2; }
        public int outcome(PubV s) { return s.r; }
        public String label(int c) { return pubLabel(c); }
        public String verdict(int c) { return pubVerdict(c, true); }
    }

    /** Double-checked locking thật: cả hai thread cùng gọi get(). */
    static final class Dcl { Conf instance; int r1, r2;
        Conf get() {
            Conf c = instance;
            if (c == null) { synchronized (this) { c = instance; if (c == null) { c = new Conf(); instance = c; } } }
            return c;
        } }
    static final class DclV { volatile Conf instance; int r1, r2;
        Conf get() {
            Conf c = instance;
            if (c == null) { synchronized (this) { c = instance; if (c == null) { c = new Conf(); instance = c; } } }
            return c;
        } }
    static String dclLabel(int c) { return "A thấy port=" + (c >> 1 == 1 ? "8080" : "0") + ", B thấy port=" + ((c & 1) == 1 ? "8080" : "0"); }
    static final class DclPlain implements Litmus.Test<Dcl> {
        public Dcl newState() { return new Dcl(); }
        public void actor1(Dcl s) { s.r1 = s.get().port == 8080 ? 1 : 0; }
        public void actor2(Dcl s) { s.r2 = s.get().port == 8080 ? 1 : 0; }
        public int outcome(Dcl s) { return s.r1 * 2 + s.r2; }
        public String label(int c) { return dclLabel(c); }
        public String verdict(int c) { return c == 3 ? OK : INT; }
    }
    static final class DclVolatile implements Litmus.Test<DclV> {
        public DclV newState() { return new DclV(); }
        public void actor1(DclV s) { s.r1 = s.get().port == 8080 ? 1 : 0; }
        public void actor2(DclV s) { s.r2 = s.get().port == 8080 ? 1 : 0; }
        public int outcome(DclV s) { return s.r1 * 2 + s.r2; }
        public String label(int c) { return dclLabel(c); }
        public String verdict(int c) { return c == 3 ? OK : BAD; }
    }

    // ---------------- Publication 4 trường (dạng của jcstress BasicJMM_08_Finals) ----------------
    static final class Obj  { int x1, x2, x3, x4;  Obj(int v)  { x1 = v; x2 = x1 + v; x3 = x2 + v; x4 = x3 + v; } }
    static final class ObjF { final int x1, x2, x3, x4; ObjF(int v) { x1 = v; x2 = x1 + v; x3 = x2 + v; x4 = x3 + v; } }
    static final class P4  { int v = 1; Obj o;  int r; }
    static final class P4F { int v = 1; ObjF o; int r; }
    static final class P4V { int v = 1; volatile Obj o; int r; }
    static final class D4  { int v = 1; Obj o;  int r1, r2;
        Obj get() { Obj c = o; if (c == null) { synchronized (this) { c = o; if (c == null) { c = new Obj(v); o = c; } } } return c; } }
    static final class D4V { int v = 1; volatile Obj o; int r1, r2;
        Obj get() { Obj c = o; if (c == null) { synchronized (this) { c = o; if (c == null) { c = new Obj(v); o = c; } } } return c; } }
    // mã hoá: 0 = null; 1 = đủ (1,2,3,4); 2 = thiếu (ít nhất một trường = 0)
    static int enc(int a, int b, int c, int d) { return (a == 1 && b == 2 && c == 3 && d == 4) ? 1 : 2; }
    static String l4(int c) { return c == 0 ? "thấy null" : c == 1 ? "thấy object đủ 1,2,3,4" : "thấy object THIẾU trường"; }
    static final class Pub4 implements Litmus.Test<P4> {
        public P4 newState() { return new P4(); }
        public void actor1(P4 s) { s.o = new Obj(s.v); }
        public void actor2(P4 s) { Obj o = s.o; s.r = o == null ? 0 : enc(o.x1, o.x2, o.x3, o.x4); }
        public int outcome(P4 s) { return s.r; }
        public String label(int c) { return l4(c); }
        public String verdict(int c) { return c == 2 ? INT : OK; }
    }
    static final class Pub4F implements Litmus.Test<P4F> {
        public P4F newState() { return new P4F(); }
        public void actor1(P4F s) { s.o = new ObjF(s.v); }
        public void actor2(P4F s) { ObjF o = s.o; s.r = o == null ? 0 : enc(o.x1, o.x2, o.x3, o.x4); }
        public int outcome(P4F s) { return s.r; }
        public String label(int c) { return l4(c); }
        public String verdict(int c) { return c == 2 ? BAD : OK; }
    }
    static final class Pub4V implements Litmus.Test<P4V> {
        public P4V newState() { return new P4V(); }
        public void actor1(P4V s) { s.o = new Obj(s.v); }
        public void actor2(P4V s) { Obj o = s.o; s.r = o == null ? 0 : enc(o.x1, o.x2, o.x3, o.x4); }
        public int outcome(P4V s) { return s.r; }
        public String label(int c) { return l4(c); }
        public String verdict(int c) { return c == 2 ? BAD : OK; }
    }
    static String ld(int c) { return "A: " + ((c >> 1) == 1 ? "đủ" : "THIẾU") + ", B: " + ((c & 1) == 1 ? "đủ" : "THIẾU"); }
    static int ok4(Obj o) { return enc(o.x1, o.x2, o.x3, o.x4) == 1 ? 1 : 0; }
    static final class Dcl4 implements Litmus.Test<D4> {
        public D4 newState() { return new D4(); }
        public void actor1(D4 s) { s.r1 = ok4(s.get()); }
        public void actor2(D4 s) { s.r2 = ok4(s.get()); }
        public int outcome(D4 s) { return s.r1 * 2 + s.r2; }
        public String label(int c) { return ld(c); }
        public String verdict(int c) { return c == 3 ? OK : INT; }
    }
    static final class Dcl4V implements Litmus.Test<D4V> {
        public D4V newState() { return new D4V(); }
        public void actor1(D4V s) { s.r1 = ok4(s.get()); }
        public void actor2(D4V s) { s.r2 = ok4(s.get()); }
        public int outcome(D4V s) { return s.r1 * 2 + s.r2; }
        public String label(int c) { return ld(c); }
        public String verdict(int c) { return c == 3 ? OK : BAD; }
    }

    // ---------------- DCL "khởi tạo hai bước": gán instance rồi mới load() ----------------
    static final class Cfg { int port; void load() { port = 8080; } }
    static final class D2  { Cfg o; int r1, r2;
        Cfg get() { Cfg c = o; if (c == null) { synchronized (this) { c = o; if (c == null) { c = new Cfg(); o = c; c.load(); } } } return c; } }
    static final class D2V { volatile Cfg o; int r1, r2;
        Cfg get() { Cfg c = o; if (c == null) { synchronized (this) { c = o; if (c == null) { c = new Cfg(); o = c; c.load(); } } } return c; } }
    static final class Dcl2 implements Litmus.Test<D2> {
        public D2 newState() { return new D2(); }
        public void actor1(D2 s) { s.r1 = s.get().port == 8080 ? 1 : 0; }
        public void actor2(D2 s) { s.r2 = s.get().port == 8080 ? 1 : 0; }
        public int outcome(D2 s) { return s.r1 * 2 + s.r2; }
        public String label(int c) { return dclLabel(c); }
        public String verdict(int c) { return c == 3 ? OK : "LỖI LOGIC (đúng cả theo JMM)"; }
    }
    static final class Dcl2V implements Litmus.Test<D2V> {
        public D2V newState() { return new D2V(); }
        public void actor1(D2V s) { s.r1 = s.get().port == 8080 ? 1 : 0; }
        public void actor2(D2V s) { s.r2 = s.get().port == 8080 ? 1 : 0; }
        public int outcome(D2V s) { return s.r1 * 2 + s.r2; }
        public String label(int c) { return dclLabel(c); }
        public String verdict(int c) { return c == 3 ? OK : "LỖI LOGIC (volatile không cứu)"; }
    }

    static final class MPA { int data; int flag; int r0, r1, r2;
        static final VarHandle F;
        static { try { F = MethodHandles.lookup().findVarHandle(MPA.class, "flag", int.class); } catch (Exception e) { throw new Error(e); } } }
    static final class MPAcqRel extends MPBase<MPA> {
        MPAcqRel() { super(true); }
        public MPA newState() { return new MPA(); }
        public void actor1(MPA s) { s.data = 1; MPA.F.setRelease(s, 1); }
        public void actor2(MPA s) { s.r1 = (int) MPA.F.getAcquire(s); s.r2 = s.data; }
        public int outcome(MPA s) { return s.r1 * 2 + s.r2; }
    }

    public static void main(String[] a) throws Exception {
        double secs = a.length > 1 ? Double.parseDouble(a[1]) : 10;
        int batch = a.length > 2 ? Integer.parseInt(a[2]) : 1 << 14;
        Litmus.Test<?> t = switch (a[0]) {
            case "sb" -> new SBPlain(); case "sb-volatile" -> new SBVolatile();
            case "sb-acqrel" -> new SBAcqRel(); case "sb-fence" -> new SBFence();
            case "mp" -> new MPPlain(); case "mp-volatile" -> new MPVolatile();
            case "mp-acqrel" -> new MPAcqRel(); case "mp-reread" -> new MPReread(); case "mp-reread-volatile" -> new MPRereadV();
            case "pub" -> new PubPlain(); case "pub-final" -> new PubFinal(); case "pub-volatile" -> new PubVolatile();
            case "dcl" -> new DclPlain(); case "dcl-volatile" -> new DclVolatile();
            case "pub4" -> new Pub4(); case "pub4-final" -> new Pub4F(); case "pub4-volatile" -> new Pub4V();
            case "dcl2" -> new Dcl2(); case "dcl2-volatile" -> new Dcl2V();
            case "dcl4" -> new Dcl4(); case "dcl4-volatile" -> new Dcl4V();
            default -> throw new IllegalArgumentException(a[0]);
        };
        Litmus.run(t, a[0], batch, secs);
    }
}
