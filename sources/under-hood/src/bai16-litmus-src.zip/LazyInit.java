package lab16b;

import org.openjdk.jmh.annotations.*;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

@State(Scope.Benchmark)
@BenchmarkMode(Mode.AverageTime) @OutputTimeUnit(TimeUnit.NANOSECONDS)
@Warmup(iterations = 3, time = 1) @Measurement(iterations = 5, time = 1) @Fork(value = 1, jvmArgsAppend = "--enable-preview")
public class LazyInit {
    public static final class Conf { final int port; Conf() { port = 8080; } }

    static final Conf EAGER = new Conf();

    static Conf syncInst;
    static synchronized Conf sync() { if (syncInst == null) syncInst = new Conf(); return syncInst; }

    static volatile Conf dclInst;
    static Conf dcl() { Conf c = dclInst; if (c == null) { synchronized (LazyInit.class) { c = dclInst; if (c == null) dclInst = c = new Conf(); } } return c; }

    static final class Holder { static final Conf INST = new Conf(); }

    static final Supplier<Conf> STABLE = StableValue.supplier(Conf::new);

    @Benchmark public int eager()        { return EAGER.port; }
    @Benchmark public int synchronizedGetter() { return sync().port; }
    @Benchmark public int dclVolatile()  { return dcl().port; }
    @Benchmark public int holderIdiom()  { return Holder.INST.port; }
    @Benchmark public int stableValue()  { return STABLE.get().port; }
}
