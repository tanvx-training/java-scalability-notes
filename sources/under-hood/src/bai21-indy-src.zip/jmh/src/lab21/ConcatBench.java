package lab21;

import java.util.Objects;
import java.util.concurrent.TimeUnit;
import org.openjdk.jmh.annotations.*;

@State(Scope.Thread)
@BenchmarkMode(Mode.AverageTime) @OutputTimeUnit(TimeUnit.NANOSECONDS)
@Warmup(iterations = 4, time = 1) @Measurement(iterations = 5, time = 1) @Fork(2)
public class ConcatBench {
    int i = 42; long l = 1_700_000_000_000L; String s = "Nguyễn An"; double d = 3.25; char c = 'x';
    record RPoint(int x, int y, String name) {}
    static final class HPoint {
        final int x, y; final String name;
        HPoint(int x, int y, String name) { this.x = x; this.y = y; this.name = name; }
        @Override public boolean equals(Object o) {
            return o instanceof HPoint p && x == p.x && y == p.y && Objects.equals(name, p.name);
        }
        @Override public int hashCode() { return (31 * Integer.hashCode(x) + Integer.hashCode(y)) * 31 + Objects.hashCode(name); }
    }
    RPoint r1 = new RPoint(1, 2, "a"), r2 = new RPoint(1, 2, "a");
    HPoint h1 = new HPoint(1, 2, "a"), h2 = new HPoint(1, 2, "a");

    @Benchmark public String concat3() { return "id=" + i + " name=" + s + " ts=" + l; }
    @Benchmark public String concat6() { return "i=" + i + " l=" + l + " s=" + s + " d=" + d + " c=" + c + " o=" + i; }
    @Benchmark public int recordHash()      { return r1.hashCode(); }
    @Benchmark public boolean recordEquals(){ return r1.equals(r2); }
    @Benchmark public int handHash()        { return h1.hashCode(); }
    @Benchmark public boolean handEquals()  { return h1.equals(h2); }
}
