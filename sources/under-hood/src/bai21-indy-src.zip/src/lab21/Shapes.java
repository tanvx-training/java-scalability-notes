package lab21;

import java.util.function.*;

/** Bốn thứ javac biên dịch thành invokedynamic: lambda, method reference, nối chuỗi, record. */
public class Shapes {
    record Point(int x, int y) {}

    static String demo(int id, String name) {
        Runnable hello = () -> System.out.println("hi");        // lambda không bắt biến
        IntSupplier twice = () -> id * 2;                         // lambda bắt biến id
        Function<String, Integer> len = String::length;           // method reference
        String msg = "user " + id + ": " + name;                  // nối chuỗi
        hello.run();
        return msg + twice.getAsInt() + len.apply(name) + new Point(id, 2);
    }

    public static void main(String[] a) { System.out.println(demo(7, "An")); }
}
