package lab21;

import java.lang.management.ManagementFactory;
import java.util.function.IntUnaryOperator;

/** Lambda bắt biến tạo một object mỗi lần được "đánh giá" — trừ khi JIT xoá nó (escape analysis). */
public class Alloc {
    static final com.sun.management.ThreadMXBean MX = (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
    static int apply(IntUnaryOperator f, int v) { return f.applyAsInt(v); }

    static long work(int n, int k) {
        long sum = 0;
        for (int i = 0; i < n; i++) sum += apply(x -> x + k, i);      // lambda bắt k: object mới mỗi vòng
        return sum;
    }

    public static void main(String[] a) {
        int n = 1_000_000; long sink = 0;
        if (a.length > 0 && a[0].equals("mega")) {     // làm call site trong apply() thành megamorphic
            IntUnaryOperator[] others = { x -> x * 2, x -> x - 1, x -> x ^ 3 };
            for (int i = 0; i < 3_000_000; i++) sink += apply(others[i % 3], i);
            System.out.println("(apply() đã thấy 3 class lambda khác — call site megamorphic)");
        }
        for (int round = 1; round <= 12; round++) {
            long b0 = MX.getThreadAllocatedBytes(Thread.currentThread().getId());
            long t0 = System.nanoTime();
            sink += work(n, round);
            long t1 = System.nanoTime();
            long b1 = MX.getThreadAllocatedBytes(Thread.currentThread().getId());
            if (round <= 3 || round % 3 == 0)
                System.out.printf("vòng %2d: %6.2f byte/lần lặp   %6.1f ms%n", round, (b1 - b0) / (double) n, (t1 - t0) / 1e6);
        }
        if (sink == 42) System.out.println();
    }
}
