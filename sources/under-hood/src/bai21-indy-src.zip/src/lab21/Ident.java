package lab21;

import java.util.*;
import java.util.function.*;

/** Lambda có tạo class mới mỗi lần gọi không? Đếm class, so sánh object. */
public class Ident {
    static Runnable noCapture()        { return () -> {}; }                 // một call site
    static IntSupplier capture(int k)  { return () -> k; }                  // một call site
    static Runnable anon()             { return new Runnable() { public void run() {} }; }
    static Runnable twinA()            { return () -> {}; }                 // cùng văn bản,
    static Runnable twinB()            { return () -> {}; }                 // khác call site

    public static void main(String[] a) throws Exception {
        Set<Class<?>> classes = new HashSet<>();
        Set<Object> objs = Collections.newSetFromMap(new IdentityHashMap<>());
        for (int i = 0; i < 1_000_000; i++) { Runnable r = noCapture(); classes.add(r.getClass()); objs.add(r); }
        System.out.printf("không bắt biến, gọi 1 000 000 lần: %d class, %,d object khác nhau%n", classes.size(), objs.size());
        classes.clear(); objs.clear();
        for (int i = 0; i < 1_000_000; i++) { IntSupplier s = capture(i); classes.add(s.getClass()); objs.add(s); }
        System.out.printf("bắt biến k,      gọi 1 000 000 lần: %d class, %,d object khác nhau%n", classes.size(), objs.size());
        classes.clear(); objs.clear();
        for (int i = 0; i < 1_000_000; i++) { Runnable r = anon(); classes.add(r.getClass()); objs.add(r); }
        System.out.printf("anonymous class, gọi 1 000 000 lần: %d class, %,d object khác nhau%n", classes.size(), objs.size());
        System.out.printf("hai lambda giống hệt nhau ở hai chỗ: cùng class? %b%n", twinA().getClass() == twinB().getClass());

        Class<?> c = capture(1).getClass();
        System.out.println();
        System.out.println("getName()      = " + c.getName());
        System.out.println("isHidden()     = " + c.isHidden() + "   isSynthetic() = " + c.isSynthetic());
        System.out.println("nest host      = " + c.getNestHost().getName());
        System.out.println("field          = " + Arrays.toString(c.getDeclaredFields()));
        System.out.println("anonymous      = " + anon().getClass().getName() + "  isHidden() = " + anon().getClass().isHidden());
        try { Class.forName(c.getName()); } catch (ClassNotFoundException e) { System.out.println("Class.forName  → ClassNotFoundException: " + e.getMessage()); }

        System.out.println();
        IntSupplier boom = () -> 1 / (a.length - a.length);
        try { boom.getAsInt(); } catch (ArithmeticException e) {
            for (StackTraceElement f : e.getStackTrace()) System.out.println("  at " + f);
        }
    }
}
