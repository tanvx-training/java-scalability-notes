#!/bin/bash
unset JAVA_TOOL_OPTIONS
J=/usr/lib/jvm/java-$1-openjdk-amd64/bin/java; M=$2; shift 2
ins=(); for r in 1 2 3 4 5 6 7 8 9; do ins+=($($J "$@" -cp genrec/rec.jar rec.Main $M 2>/dev/null | grep first | sed -E 's/.*first ([0-9.]+) ms.*/\1/')); done
med=$(printf '%s\n' "${ins[@]}" | sort -n | sed -n 5p)
gen=$($J "$@" -Xlog:class+load -cp genrec/rec.jar rec.Main $M 2>/dev/null | grep 'class,load' | grep -c -E 'LookupDefineClass')
echo "JDK $J_V $M: lần đầu $med ms, class sinh lúc chạy $gen  $*"
