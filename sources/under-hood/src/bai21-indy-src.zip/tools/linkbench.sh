#!/bin/bash
# linkbench.sh <jdk> <classdir> <mode> [extra JVM opts...]  -> median in-program ms, median wall ms, class counts
unset JAVA_TOOL_OPTIONS
J=/usr/lib/jvm/java-$1-openjdk-amd64/bin/java; CP=$2; M=$3; shift 3
ins=(); wall=()
for r in 1 2 3 4 5 6 7 8 9; do
  s=$(date +%s%N)
  o=$($J -Dstdout.encoding=UTF-8 "$@" -cp $CP gen.Main $M)
  e=$(date +%s%N)
  ins+=($(echo "$o" | grep "first" | sed -E 's/.*first ([0-9.]+) ms.*/\1/')); wall+=($(( (e-s)/1000000 )))
done
med(){ printf '%s\n' "$@" | sort -n | sed -n 5p; }
log=$($J "$@" -Xlog:class+load -cp $CP gen.Main $M)
tot=$(echo "$log" | grep -c 'class,load')
lam=$(echo "$log" | grep 'class,load' | grep -c 'gen\.L[0-9]\$\$Lambda')
anon=$(echo "$log" | grep 'class,load' | grep -c 'gen\.A[0-9]\$')
sc=$(echo "$log" | grep 'class,load' | grep -c 'StringConcat')
lf=$(echo "$log" | grep 'class,load' | grep -c 'LambdaForm\$')
shared=$(echo "$log" | grep 'class,load' | grep -c 'shared')
printf "JDK %-3s %-7s %-14s chạy-đầu %7s ms | wall %5s ms | class nạp %5d (shared %4d) lambda %4d anon %4d StringConcat %3d LambdaForm %3d  %s\n" $J_V "$M" "$(basename $CP)" "$(med "${ins[@]}")" "$(med "${wall[@]}")" $tot $shared $lam $anon $sc $lf "$*"
