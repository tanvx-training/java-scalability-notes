import os
D='/home/claude/lab21/genrec/src/rec'; os.makedirs(D, exist_ok=True)
rec=[]; hand=[]
for j in range(100):
    rec.append(f'    record R{j}(int a, long b, String c) {{}}')
    hand.append(f'''    static final class H{j} {{ final int a; final long b; final String c; H{j}(int a, long b, String c) {{ this.a=a; this.b=b; this.c=c; }}
        public boolean equals(Object o) {{ return o instanceof H{j} h && a==h.a && b==h.b && java.util.Objects.equals(c,h.c); }}
        public int hashCode() {{ return (31*Integer.hashCode(a)+Long.hashCode(b))*31+java.util.Objects.hashCode(c); }}
        public String toString() {{ return "H{j}[a=" + a + ", b=" + b + ", c=" + c + "]"; }} }}''')
useR='\n'.join(f'            {{ var x = new R{j}({j}, 2L, "c"); n += x.hashCode() + (x.equals(new R{j}({j}, 2L, "c")) ? 1 : 0) + x.toString().length(); }}' for j in range(100))
useH='\n'.join(f'            {{ var x = new H{j}({j}, 2L, "c"); n += x.hashCode() + (x.equals(new H{j}({j}, 2L, "c")) ? 1 : 0) + x.toString().length(); }}' for j in range(100))
open(f'{D}/Main.java','w').write('package rec;\npublic class Main {\n' + '\n'.join(rec) + '\n' + '\n'.join(hand) + f'''
    public static void main(String[] a) {{
        long t0 = System.nanoTime(); long n = 0;
        if (a[0].equals("record")) {{
{useR}
        }} else {{
{useH}
        }}
        System.out.printf("%s: first %.2f ms (n=%d)%n", a[0], (System.nanoTime() - t0) / 1e6, n);
    }}
}}
''')
