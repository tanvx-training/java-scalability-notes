# Sinh mã cho thí nghiệm chi phí liên kết: 10 class × 100 lambda / anonymous class / chỗ nối chuỗi
import os, random
D = '/home/claude/lab21/gen/src/gen'
os.makedirs(D, exist_ok=True)
random.seed(21)
types = [('int', 'i'), ('long', 'l'), ('String', 's'), ('Object', 'o'), ('double', 'd'), ('char', 'c')]
for k in range(10):
    lam = [f'        a[{j}] = () -> {k*100+j} + x;' for j in range(100)]
    open(f'{D}/L{k}.java', 'w').write(f'package gen;\nimport java.util.function.IntSupplier;\npublic class L{k} {{\n    public static int run(int x) {{\n        IntSupplier[] a = new IntSupplier[100];\n' + '\n'.join(lam) + '\n        int s = 0; for (IntSupplier f : a) s += f.getAsInt(); return s;\n    }\n}\n')
    an = [f'        a[{j}] = new IntSupplier() {{ public int getAsInt() {{ return {k*100+j} + x; }} }};' for j in range(100)]
    open(f'{D}/A{k}.java', 'w').write(f'package gen;\nimport java.util.function.IntSupplier;\npublic class A{k} {{\n    public static int run(final int x) {{\n        IntSupplier[] a = new IntSupplier[100];\n' + '\n'.join(an) + '\n        int s = 0; for (IntSupplier f : a) s += f.getAsInt(); return s;\n    }\n}\n')
    cs = []
    for j in range(100):
        n = random.randint(3, 6)
        parts = [random.choice(types)[1] for _ in range(n)]
        expr = ' + '.join(f'"k{j}_{p}=" + {p}' for p in parts)
        cs.append(f'        n += ({expr}).length();')
    open(f'{D}/C{k}.java', 'w').write(f'package gen;\npublic class C{k} {{\n    public static int run(int i, long l, String s, Object o, double d, char c) {{\n        int n = 0;\n' + '\n'.join(cs) + '\n        return n;\n    }\n}\n')
open(f'{D}/Main.java', 'w').write('''package gen;
public class Main {
    public static void main(String[] a) {
        long t0 = System.nanoTime(); long s = 0;
        switch (a[0]) {
            case "lambda" -> { s += L0.run(1); s += L1.run(1); s += L2.run(1); s += L3.run(1); s += L4.run(1); s += L5.run(1); s += L6.run(1); s += L7.run(1); s += L8.run(1); s += L9.run(1); }
            case "anon"   -> { s += A0.run(1); s += A1.run(1); s += A2.run(1); s += A3.run(1); s += A4.run(1); s += A5.run(1); s += A6.run(1); s += A7.run(1); s += A8.run(1); s += A9.run(1); }
            case "concat" -> { Object o = "x"; s += C0.run(1, 2L, "s", o, 1.5, 'c'); s += C1.run(1, 2L, "s", o, 1.5, 'c'); s += C2.run(1, 2L, "s", o, 1.5, 'c'); s += C3.run(1, 2L, "s", o, 1.5, 'c'); s += C4.run(1, 2L, "s", o, 1.5, 'c'); s += C5.run(1, 2L, "s", o, 1.5, 'c'); s += C6.run(1, 2L, "s", o, 1.5, 'c'); s += C7.run(1, 2L, "s", o, 1.5, 'c'); s += C8.run(1, 2L, "s", o, 1.5, 'c'); s += C9.run(1, 2L, "s", o, 1.5, 'c'); }
            case "none"   -> { s = 1; }
        }
        long t1 = System.nanoTime();
        System.out.printf("%s: first %.2f ms (s=%d)%n", a[0], (t1 - t0) / 1e6, s);
    }
}
''')
# đếm số "hình dạng" (kiểu tham số sau khi xoá kiểu) của 1000 chỗ nối chuỗi

# biến thể: 1000 chỗ nối chuỗi cùng MỘT hình dạng (int, String, long), chỉ khác hằng chuỗi
for k in range(10):
    cs = [f'        n += ("order {k}-{j} user=" + i + " name=" + s + " ts=" + l).length();' for j in range(100)]
    open(f'{D}/S{k}.java', 'w').write(f'package gen;\npublic class S{k} {{\n    public static int run(int i, String s, long l) {{\n        int n = 0;\n' + '\n'.join(cs) + '\n        return n;\n    }\n}\n')
m = open(f'{D}/Main.java').read()
m = m.replace('            case "none"', '''            case "same"   -> { s += S0.run(1, "s", 2L); s += S1.run(1, "s", 2L); s += S2.run(1, "s", 2L); s += S3.run(1, "s", 2L); s += S4.run(1, "s", 2L); s += S5.run(1, "s", 2L); s += S6.run(1, "s", 2L); s += S7.run(1, "s", 2L); s += S8.run(1, "s", 2L); s += S9.run(1, "s", 2L); }
            case "lambda100" -> { s += L0.run(1); }
            case "lambda1"   -> { java.util.function.IntSupplier f = () -> 7; s += f.getAsInt(); }
            case "none"''')
m = m.replace('"first %.1f ms', '"first %.2f ms')
open(f'{D}/Main.java', 'w').write(m)
