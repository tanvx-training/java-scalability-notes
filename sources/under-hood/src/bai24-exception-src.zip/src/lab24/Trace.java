package lab24;

/** Đọc stack trace: "Caused by", "... N more", giới hạn 1024 frame của StackOverflowError. */
public class Trace {
    static int rec(int n) { return rec(n + 1) + 1; }
    static void repo(String id) { throw new IllegalStateException("không tìm thấy order " + id); }
    static void service(String id) {
        try { repo(id); } catch (IllegalStateException e) { throw new RuntimeException("xử lý order thất bại", e); }
    }
    public static void main(String[] a) {
        try { rec(0); } catch (StackOverflowError e) { System.out.println("StackOverflowError: getStackTrace().length = " + e.getStackTrace().length); }
        try { service("A-1"); } catch (RuntimeException e) { e.printStackTrace(System.out); }
    }
}
