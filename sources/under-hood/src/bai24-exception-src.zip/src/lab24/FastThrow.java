package lab24;

/** Một exception "ngầm" (JVM tự ném) lặp lại trong code nóng: theo dõi stack trace và message từng lần. */
public class FastThrow {
    static Object sink;
    static int npe(Object o, int i)   { return ((String) o).length(); }              // NullPointerException
    static int div(Object o, int i)   { return 10 / (i & 0); }                        // ArithmeticException
    static int aioobe(Object o, int i){ int[] arr = new int[2]; return arr[i & 0 | 5]; } // ArrayIndexOutOfBoundsException
    static int cce(Object o, int i)   { return ((String) (Object) Integer.valueOf(i)).length(); } // ClassCastException
    static int ase(Object o, int i)   { Object[] arr = new String[1]; arr[0] = Integer.valueOf(i); return 0; } // ArrayStoreException
    static int expl(Object o, int i)  { if (o == null) throw new NullPointerException("ném tường minh"); return 0; } // throw new

    static RuntimeException last;
    static int work(String kind, int i) {
        try {
            return switch (kind) {
                case "npe" -> npe(null, i); case "div" -> div(null, i); case "aioobe" -> aioobe(null, i);
                case "cce" -> cce(null, i); case "ase" -> ase(null, i); default -> expl(null, i);
            };
        } catch (RuntimeException e) { last = e; return -1; }
    }

    public static void main(String[] a) {
        String kind = a.length > 0 ? a[0] : "npe";
        boolean verbose = a.length > 1;
        int n = 100_000, full = 0, empty = 0, firstEmpty = -1; Object firstObj = null; boolean same = true;
        for (int i = 1; i <= n; i++) {
            work(kind, i);
            int depth = last.getStackTrace().length;
            if (verbose && i == 1) { System.out.println("lần ném #1:"); last.printStackTrace(System.out); }
            if (depth == 0) {
                if (firstEmpty < 0) {
                    firstEmpty = i; firstObj = last;
                    if (verbose) { System.out.println("lần ném #" + i + " (identityHashCode=" + System.identityHashCode(last) + "):"); last.printStackTrace(System.out); }
                } else if (last != firstObj) same = false;
                empty++;
            } else full++;
        }
        System.out.printf("%-6s %-38s lần đầu mất stack trace: #%-6s  đủ: %6d  rỗng: %6d  cùng một object: %b%n",
                kind, last.getClass().getName(), firstEmpty < 0 ? "—" : String.valueOf(firstEmpty), full, empty, firstEmpty >= 0 && same);
    }
}
