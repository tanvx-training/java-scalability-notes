package lab24;

import java.io.*;
import java.util.function.IntSupplier;

/** Chi phí exception theo độ sâu stack. Đo tay (chạy cả JDK 17), trung vị 5 vòng. */
public class ExcCost {
    static volatile Object sink;
    /** Exception không có stack trace — cách làm đúng khi dùng exception cho luồng điều khiển. */
    static final class NoTrace extends RuntimeException {
        NoTrace(String m) { super(m, null, false, false); }          // enableSuppression=false, writableStackTrace=false
    }
    static final RuntimeException PREALLOCATED = new NoTrace("dựng sẵn");
    static final StackWalker SW = StackWalker.getInstance();

    // chạy op ở đáy một stack sâu d frame
    static double atDepth(int d, IntSupplier op, int n) { return d == 0 ? loop(op, n) : atDepth(d - 1, op, n); }
    static double loop(IntSupplier op, int n) {
        long t0 = System.nanoTime(); int s = 0;
        for (int i = 0; i < n; i++) s += op.getAsInt();
        sink = s; return (System.nanoTime() - t0) / (double) n;
    }
    // ném ở đáy, bắt ở đỉnh: chi phí gồm cả unwind d frame
    static int throwFrom(int d, boolean pre) {
        if (d == 0) { if (pre) throw PREALLOCATED; throw new RuntimeException("x"); }
        return throwFrom(d - 1, pre) + 1;
    }
    static int noThrow(int d) { return d == 0 ? 0 : noThrow(d - 1) + 1; }

    static double med(double[] v) { java.util.Arrays.sort(v); return v[v.length / 2]; }
    static double bench(int d, IntSupplier op, int n) {
        for (int w = 0; w < 4; w++) atDepth(d, op, n);
        double[] r = new double[5]; for (int i = 0; i < 5; i++) r[i] = atDepth(d, op, n); return med(r);
    }
    static double benchThrow(int d, boolean pre, int n) {
        IntSupplier op = () -> { try { return throwFrom(d, pre); } catch (RuntimeException e) { return 1; } };
        IntSupplier base = () -> noThrow(d);
        return bench(0, op, n) - bench(0, base, n);
    }

    public static void main(String[] a) {
        int[] depths = {10, 150, 1000};
        System.out.printf("JDK %d — ns mỗi thao tác%n%-46s", Runtime.version().feature(), "");
        for (int d : depths) System.out.printf("%12s", "sâu " + d);
        System.out.println();
        String[] names = {"new RuntimeException()", "  + getStackTrace()", "  + printStackTrace → String",
                          "new NoTrace(msg) — writableStackTrace=false", "StackWalker: tìm frame gọi", "Thread.currentThread().getStackTrace()",
                          "ném + bắt qua d frame (new)", "ném + bắt qua d frame (dựng sẵn)"};
        for (int k = 0; k < names.length; k++) {
            System.out.printf("%-46s", names[k]);
            for (int d : depths) {
                int n = d >= 1000 ? 2_000 : d >= 150 ? 10_000 : 50_000;
                double v = switch (k) {
                    case 0 -> bench(d, () -> { sink = new RuntimeException(); return 1; }, n);
                    case 1 -> bench(d, () -> new RuntimeException().getStackTrace().length, n);
                    case 2 -> bench(d, () -> { StringWriter w = new StringWriter(); new RuntimeException().printStackTrace(new PrintWriter(w)); return w.getBuffer().length(); }, n / 5);
                    case 3 -> bench(d, () -> { sink = new NoTrace("m"); return 1; }, n);
                    case 4 -> bench(d, () -> SW.walk(s -> s.skip(1).findFirst()).map(f -> f.getLineNumber()).orElse(0), n);
                    case 5 -> bench(d, () -> Thread.currentThread().getStackTrace().length, n / 5);
                    case 6 -> benchThrow(d, false, n);
                    default -> benchThrow(d, true, n);
                };
                System.out.printf("%12s", v >= 1000 ? String.format("%,.1f µs", v / 1000) : String.format("%.0f ns", v));
            }
            System.out.println();
        }
    }
}
