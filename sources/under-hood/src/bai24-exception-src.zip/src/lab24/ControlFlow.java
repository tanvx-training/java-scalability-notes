package lab24;

/** Exception làm luồng điều khiển: parse 1 triệu chuỗi, một nửa không hợp lệ, ở hai độ sâu stack. */
public class ControlFlow {
    static final String[] IN = new String[1024];
    static {
        for (int i = 0; i < IN.length; i++) IN[i] = (i % 2 == 0) ? String.valueOf(i * 7919) : "SKU-" + i;
    }
    static int viaException(String s) { try { return Integer.parseInt(s); } catch (NumberFormatException e) { return -1; } }
    static int viaCheck(String s) {
        if (s.isEmpty() || s.length() > 9) return -1;
        for (int i = 0; i < s.length(); i++) { char c = s.charAt(i); if (c < '0' || c > '9') return -1; }
        return Integer.parseInt(s);
    }
    static long run(boolean exc, int n) {
        long sum = 0;
        for (int i = 0; i < n; i++) { String s = IN[i & 1023]; sum += exc ? viaException(s) : viaCheck(s); }
        return sum;
    }
    static double atDepth(int d, boolean exc, int n) {
        if (d > 0) return atDepth(d - 1, exc, n);
        long t0 = System.nanoTime(); long s = run(exc, n); long t = System.nanoTime() - t0;
        if (s == 42) System.out.print("");
        return t / 1e6;
    }
    public static void main(String[] a) {
        int n = 1_000_000;
        System.out.printf("JDK %d — 1 000 000 chuỗi, 50%% không hợp lệ (ms, trung vị 5 lần)%n", Runtime.version().feature());
        for (int d : new int[]{10, 150}) for (boolean exc : new boolean[]{false, true}) {
            for (int w = 0; w < 3; w++) atDepth(d, exc, n);
            double[] r = new double[5]; for (int i = 0; i < 5; i++) r[i] = atDepth(d, exc, n);
            java.util.Arrays.sort(r);
            System.out.printf("  sâu %4d  %-36s %8.1f ms%n", d, exc ? "Integer.parseInt + catch NumberFormatException" : "kiểm tra ký tự trước", r[2]);
        }
    }
}
