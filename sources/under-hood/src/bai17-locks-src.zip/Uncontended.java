package lab17b;

import org.openjdk.jmh.annotations.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;

/** Một thread, không tranh chấp: một lần khoá + tăng biến đếm + mở khoá tốn bao nhiêu? */
@State(Scope.Thread)
@BenchmarkMode(Mode.AverageTime) @OutputTimeUnit(TimeUnit.NANOSECONDS)
@Warmup(iterations = 3, time = 1) @Measurement(iterations = 5, time = 1) @Fork(1)
public class Uncontended {
    int counter;
    final Object lock = new Object();
    final Object inflated = new Object();
    final ReentrantLock rl = new ReentrantLock();
    final AtomicInteger ai = new AtomicInteger();
    final StringBuffer sbuf = new StringBuffer();
    final StringBuilder sbld = new StringBuilder();

    @Setup public void inflate() throws InterruptedException {
        synchronized (inflated) { inflated.wait(1); }      // wait() buộc phình thành ObjectMonitor
    }

    @Benchmark public int plain()          { return ++counter; }
    @Benchmark public int sync()           { synchronized (lock) { return ++counter; } }
    @Benchmark public int syncNested()     { synchronized (lock) { synchronized (lock) { return ++counter; } } }
    @Benchmark public int syncInflated()   { synchronized (inflated) { return ++counter; } }
    @Benchmark public int syncLocalObject(){ Object l = new Object(); synchronized (l) { return ++counter; } }
    @Benchmark public int reentrantLock()  { rl.lock(); try { return ++counter; } finally { rl.unlock(); } }
    @Benchmark public int atomic()         { return ai.incrementAndGet(); }
    @Benchmark public int stringBuffer()   { sbuf.setLength(0); sbuf.append("id=").append(counter).append(';').append("ok"); return sbuf.length(); }
    @Benchmark public int stringBuilder()  { sbld.setLength(0); sbld.append("id=").append(counter).append(';').append("ok"); return sbld.length(); }
}
