package lab17;

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadInfo;
import java.util.*;
import java.util.concurrent.atomic.LongAdder;
import java.util.concurrent.locks.LockSupport;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Mô phỏng một service: 200 thread (như Tomcat), mỗi request "chờ I/O" 2 ms rồi chạy một đoạn
 * tính toán ~50 µs trong vùng găng. Đổi kiểu khoá, đo thông lượng và trạng thái thread.
 * Chạy: java lab17.ServiceSim <none|sync|rl|rlfair|striped> [giây] [csMicros]
 */
public class ServiceSim {
    static final int THREADS = 200;
    static final Object LOCK = new Object();
    static final ReentrantLock RL = new ReentrantLock();
    static final ReentrantLock RLF = new ReentrantLock(true);
    static final Object[] STRIPES = new Object[16];
    static { for (int i = 0; i < STRIPES.length; i++) STRIPES[i] = new Object(); }
    static volatile long sink;
    static volatile boolean stop;

    static long work(long nanos) {                       // CPU thật, không ngủ
        long end = System.nanoTime() + nanos, x = 0;
        while (System.nanoTime() < end) x += x * 31 + 7;
        return x;
    }

    public static void main(String[] a) throws Exception {
        String mode = a[0];
        double secs = a.length > 1 ? Double.parseDouble(a[1]) : 8;
        long csNanos = (a.length > 2 ? Long.parseLong(a[2]) : 50) * 1000;
        LongAdder ops = new LongAdder();
        LongAdder latencyNs = new LongAdder();
        List<Thread> ts = new ArrayList<>();
        for (int i = 0; i < THREADS; i++) {
            final int id = i;
            Thread t = new Thread(() -> {
                long k = id;
                while (!stop) {
                    LockSupport.parkNanos(2_000_000);          // "chờ DB/HTTP" 2 ms
                    long t0 = System.nanoTime();
                    switch (mode) {
                        case "none" -> sink = work(csNanos);
                        case "sync" -> { synchronized (LOCK) { sink = work(csNanos); } }
                        case "rl" -> { RL.lock(); try { sink = work(csNanos); } finally { RL.unlock(); } }
                        case "rlfair" -> { RLF.lock(); try { sink = work(csNanos); } finally { RLF.unlock(); } }
                        case "striped" -> { synchronized (STRIPES[(int) (k++ & 15)]) { sink = work(csNanos); } }
                        default -> throw new IllegalArgumentException(mode);
                    }
                    latencyNs.add(System.nanoTime() - t0);
                    ops.increment();
                }
            }, "http-nio-exec-" + i);
            ts.add(t);
        }
        long start = System.nanoTime();
        ts.forEach(Thread::start);
        Thread.sleep((long) (secs * 500));                  // giữa chừng: chụp trạng thái thread
        Map<String, Integer> states = new TreeMap<>();
        String blockedOn = "";
        for (ThreadInfo ti : ManagementFactory.getThreadMXBean().getThreadInfo(ts.stream().mapToLong(Thread::threadId).toArray(), 1)) {
            if (ti == null) continue;
            String st = ti.getThreadState().toString();
            if (ti.getLockName() != null && st.equals("WAITING")) st = "WAITING (park, " + ti.getLockName().replaceAll("@.*", "") + ")";
            if (st.equals("TIMED_WAITING")) st = "TIMED_WAITING (I/O giả lập)";
            if (st.equals("BLOCKED")) blockedOn = ti.getLockName();
            states.merge(st, 1, Integer::sum);
        }
        long before = ops.sum(); long tb = System.nanoTime();
        Thread.sleep((long) (secs * 500));
        long n = ops.sum() - before; double el = (System.nanoTime() - tb) / 1e9;
        stop = true;
        for (Thread t : ts) t.join();
        System.out.printf("%-8s cs=%dµs  %,8.0f req/s   vùng găng TB %,7.0f µs (gồm chờ khoá)   trạng thái: %s %s%n",
                mode, csNanos / 1000, n / el, latencyNs.sum() / 1e3 / ops.sum(), states, blockedOn.isEmpty() ? "" : "chờ " + blockedOn);
    }
}
