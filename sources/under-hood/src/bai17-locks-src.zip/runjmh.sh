#!/bin/bash
unset JAVA_TOOL_OPTIONS
JMH=/home/claude/lab08/jmhbuild/jmh-all-1.37.jar
R=/home/claude/lab17/res
j(){ /usr/lib/jvm/java-$1-openjdk-amd64/bin/java -cp classes:$JMH org.openjdk.jmh.Main -foe true "${@:2}"; }
j 25 Uncontended > $R/jmh_unc_25.txt 2>&1
j 21 Uncontended > $R/jmh_unc_21.txt 2>&1
j 17 Uncontended > $R/jmh_unc_17.txt 2>&1
j 17 Uncontended -jvmArgsAppend "-XX:+UseBiasedLocking -XX:BiasedLockingStartupDelay=0" > $R/jmh_unc_17b.txt 2>&1
j 25 Uncontended.syncLocalObject Uncontended.sync -jvmArgsAppend "-XX:-EliminateLocks" > $R/jmh_unc_25_noelim.txt 2>&1
for t in 2 8; do j 25 Contended -t $t > $R/jmh_con_25_t$t.txt 2>&1; done
j 21 Contended -t 8 > $R/jmh_con_21_t8.txt 2>&1
echo ALLDONE > $R/jmh_done
