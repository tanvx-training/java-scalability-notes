package lab17;

import jdk.internal.misc.Unsafe;

/** Lồng 10 khoá trên 10 object khác nhau; lock-stack của JDK 25 chỉ chứa 8. */
public class LockStackFull {
    static final Unsafe U = Unsafe.getUnsafe();
    static final Object[] objs = new Object[10];
    static void nest(int i) {
        if (i == objs.length) {
            StringBuilder sb = new StringBuilder("  bit khoá của 10 object (thứ tự khoá):");
            for (Object o : objs) { long m = U.getLongVolatile(o, 0L) & 3; sb.append(m == 0 ? " fast" : m == 2 ? " MON" : " free"); }
            System.out.println(sb);
            return;
        }
        synchronized (objs[i]) { nest(i + 1); }
    }
    public static void main(String[] a) {
        for (int i = 0; i < objs.length; i++) objs[i] = new Object();
        System.out.println("JDK " + Runtime.version().feature());
        nest(0);
    }
}
