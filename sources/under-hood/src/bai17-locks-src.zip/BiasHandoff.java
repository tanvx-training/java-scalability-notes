package lab17;

/**
 * Mẫu "giao việc giữa hai thread" — kẻ thù của biased locking:
 * thread A tạo và dùng N object có khoá (StringBuffer), thread B dùng lại chúng.
 * Mỗi object bị thiên vị cho A phải bị "thu hồi" (revoke) khi B chạm vào.
 */
public class BiasHandoff {
    public static void main(String[] a) throws Exception {
        int rounds = a.length > 0 ? Integer.parseInt(a[0]) : 20;
        int n = 200_000;
        long tA = 0, tB = 0;
        for (int r = 0; r < rounds; r++) {
            StringBuffer[] arr = new StringBuffer[n];
            long t0 = System.nanoTime();
            Thread A = new Thread(() -> { for (int i = 0; i < n; i++) { arr[i] = new StringBuffer(); arr[i].append(i); } });
            A.start(); A.join();
            long t1 = System.nanoTime();
            Thread B = new Thread(() -> { for (int i = 0; i < n; i++) arr[i].append('x'); });
            B.start(); B.join();
            long t2 = System.nanoTime();
            if (r >= rounds / 2) { tA += t1 - t0; tB += t2 - t1; }
        }
        int m = rounds - rounds / 2;
        System.out.printf("JDK %s  thread A (tạo + khoá lần đầu): %6.1f ms   thread B (khoá lại object của A): %6.1f ms   / %d object, TB %d vòng cuối%n",
                Runtime.version().feature(), tA / 1e6 / m, tB / 1e6 / m, n, m);
    }
}
