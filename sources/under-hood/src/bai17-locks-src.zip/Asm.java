package lab17;

import java.util.concurrent.locks.ReentrantLock;

/** Để in mã máy C2 của fast path: java -XX:CompileCommand=print,lab17.Asm::* ... */
public class Asm {
    int counter;
    final Object lock = new Object();
    final ReentrantLock rl = new ReentrantLock();

    int syncInc()  { synchronized (lock) { return ++counter; } }
    int rlInc()    { rl.lock(); try { return ++counter; } finally { rl.unlock(); } }

    public static void main(String[] a) {
        Asm o = new Asm(); long s = 0;
        for (int i = 0; i < 300_000; i++) { s += o.syncInc(); s += o.rlInc(); }
        System.out.println(s);
    }
}
