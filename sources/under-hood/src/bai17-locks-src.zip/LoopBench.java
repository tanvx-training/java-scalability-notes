package lab17;

/** Benchmark tay (chạy được trên JDK 17): khoá/mở cùng một object 50 triệu lần, một thread. */
public class LoopBench {
    int counter;
    final Object lock = new Object();
    static volatile int sink;

    int sync(int n) { for (int i = 0; i < n; i++) { synchronized (lock) { counter++; } } return counter; }
    int plain(int n) { for (int i = 0; i < n; i++) { counter++; sink = counter; } return counter; }

    public static void main(String[] a) {
        LoopBench b = new LoopBench();
        int n = 50_000_000;
        double best = Double.MAX_VALUE, sum = 0; int m = 0;
        for (int r = 0; r < 12; r++) {
            long t0 = System.nanoTime();
            sink = b.sync(n);
            double ns = (System.nanoTime() - t0) / (double) n;
            if (r >= 4) { best = Math.min(best, ns); sum += ns; m++; }
        }
        System.out.printf("JDK %-3s %-40s synchronized: TB %.2f ns/lần, tốt nhất %.2f ns%n",
                Runtime.version().feature(), String.join(" ", java.lang.management.ManagementFactory.getRuntimeMXBean().getInputArguments()).replaceAll("-D\\S+", "").trim(), sum / m, best);
    }
}
