package lab17;

import java.util.concurrent.Executors;
import java.util.concurrent.locks.ReentrantLock;

/**
 * 1 000 virtual thread, mỗi thread có KHOÁ RIÊNG (không tranh chấp) và ngủ 20 ms khi đang giữ khoá
 * — giống một lời gọi JDBC bên trong method synchronized của driver.
 * Chạy: java lab17.VtPin <sync|rl> [số task]
 */
public class VtPin {
    public static void main(String[] a) throws Exception {
        String mode = a[0];
        int n = a.length > 1 ? Integer.parseInt(a[1]) : 1000;
        long t0 = System.nanoTime();
        try (var ex = Executors.newVirtualThreadPerTaskExecutor()) {
            for (int i = 0; i < n; i++) {
                ex.submit(() -> {
                    Object lock = new Object();
                    ReentrantLock rl = new ReentrantLock();
                    if (mode.equals("sync")) {
                        synchronized (lock) { sleep(20); }
                    } else {
                        rl.lock(); try { sleep(20); } finally { rl.unlock(); }
                    }
                });
            }
        }
        System.out.printf("JDK %-6s %-5s %d task × 20 ms: %,6.0f ms  (song song hiệu dụng ≈ %.0f)%n",
                Runtime.version().feature(), mode, n, (System.nanoTime() - t0) / 1e6, n * 20.0 / ((System.nanoTime() - t0) / 1e6));
    }
    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { throw new RuntimeException(e); } }
}
