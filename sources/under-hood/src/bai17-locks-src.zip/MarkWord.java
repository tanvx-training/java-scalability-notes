package lab17;

import jdk.internal.misc.Unsafe;

/**
 * In mark word (8 byte đầu của object) qua từng trạng thái khoá.
 * Biên dịch --release 17 để chạy được trên JDK 17, 21, 25.
 * Chạy: java --add-exports java.base/jdk.internal.misc=ALL-UNNAMED lab17.MarkWord
 */
public class MarkWord {
    static final Unsafe U = Unsafe.getUnsafe();
    static final int FEATURE = Runtime.version().feature();

    static long mw(Object o) { return U.getLongVolatile(o, 0L); }

    static String decode(long m, Object o) {
        int lock = (int) (m & 3);
        String s;
        if (FEATURE <= 17 && (m & 7) == 5) {
            long thr = m & ~0x3FFL;
            s = thr == 0 ? "biasable (chưa thiên vị ai)" : String.format("BIASED → thread 0x%x", thr);
        } else switch (lock) {
            case 1 -> s = "unlocked";
            case 0 -> s = "LOCKED (stack-lock/fast-lock)";
            case 2 -> s = "INFLATED → ObjectMonitor";
            default -> s = "marked (GC)";
        }
        int age = (int) ((m >> 3) & 0xF);
        return s + (lock == 1 && age > 0 ? ", age=" + age : "");
    }

    static void p(String what, Object o) {
        long m = mw(o);
        System.out.printf("  %-44s 0x%016x  %s%n", what, m, decode(m, o));
    }

    static void hashInfo(Object o) {
        int h = System.identityHashCode(o);
        long m = mw(o);
        String where = "không thấy trong mark word";
        for (int sh : new int[]{8, 11}) if (((m >>> sh) & 0x7FFFFFFFL) == h) where = "nằm trong mark word từ bit " + sh;
        System.out.printf("  %-44s 0x%016x  hash=0x%08x %s%n", "identityHashCode() → ", m, h, where);
    }

    public static void main(String[] a) throws Exception {
        System.out.println("JDK " + Runtime.version());
        Thread.sleep(a.length > 0 ? Long.parseLong(a[0]) : 0);   // JDK 17: chờ qua BiasedLockingStartupDelay nếu cần

        System.out.println("[1] object mới, khoá rồi mở");
        Object o = new Object();
        p("new Object()", o);
        synchronized (o) { p("trong synchronized(o)", o); }
        p("sau khi ra khỏi synchronized", o);

        System.out.println("[2] hashCode rồi mới khoá");
        Object h = new Object();
        hashInfo(h);
        synchronized (h) { p("trong synchronized(h)", h); }
        p("sau khi ra", h);

        System.out.println("[3] khoá rồi gọi hashCode bên trong");
        Object k = new Object();
        synchronized (k) {
            p("trong synchronized(k)", k);
            System.identityHashCode(k);
            p("  … sau identityHashCode(k)", k);
        }
        p("sau khi ra", k);

        System.out.println("[4] khoá lồng nhau (re-entrant)");
        Object r = new Object();
        synchronized (r) { synchronized (r) { p("trong synchronized(r){ synchronized(r) }", r); } }

        System.out.println("[5] wait() bên trong synchronized");
        Object w = new Object();
        synchronized (w) { w.wait(1); p("sau w.wait(1), vẫn giữ khoá", w); }
        p("sau khi ra", w);

        System.out.println("[6] thread thứ hai tranh khoá");
        Object c = new Object();
        Thread t;
        synchronized (c) {
            p("main đang giữ c", c);
            t = new Thread(() -> { synchronized (c) { p("thread T đã lấy được c", c); } }, "T");
            t.start();
            Thread.sleep(200);
            p("T đang chờ (BLOCKED)", c);
        }
        t.join();
        p("cả hai đã ra", c);
        Thread.sleep(a.length > 1 ? Long.parseLong(a[1]) : 0);
        p("sau một lúc (deflation?)", c);

        System.out.println("[7] JDK 17 + biased: thread khác khoá object đã thiên vị");
        Object b = new Object();
        synchronized (b) { }
        p("main khoá rồi mở", b);
        Thread t2 = new Thread(() -> { synchronized (b) { p("thread T2 khoá b", b); } }, "T2");
        t2.start(); t2.join();
        p("sau T2", b);
    }
}
