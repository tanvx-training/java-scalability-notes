package lab17b;

import org.openjdk.jmh.annotations.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.LongAdder;
import java.util.concurrent.locks.ReentrantLock;

/** Nhiều thread cùng tăng MỘT biến đếm chung. Chạy với -t 2 và -t 8 (máy có 2 vCPU). */
@State(Scope.Benchmark)
@BenchmarkMode(Mode.Throughput) @OutputTimeUnit(TimeUnit.MICROSECONDS)
@Warmup(iterations = 3, time = 1) @Measurement(iterations = 5, time = 1) @Fork(1)
public class Contended {
    long counter;
    final Object lock = new Object();
    final ReentrantLock unfair = new ReentrantLock();
    final ReentrantLock fair = new ReentrantLock(true);
    final AtomicLong al = new AtomicLong();
    final LongAdder adder = new LongAdder();

    @Benchmark public long sync()       { synchronized (lock) { return ++counter; } }
    @Benchmark public long rlUnfair()   { unfair.lock(); try { return ++counter; } finally { unfair.unlock(); } }
    @Benchmark public long rlFair()     { fair.lock(); try { return ++counter; } finally { fair.unlock(); } }
    @Benchmark public long atomic()     { return al.incrementAndGet(); }
    @Benchmark public void longAdder()  { adder.increment(); }
}
