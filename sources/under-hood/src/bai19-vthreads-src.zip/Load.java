package lab19;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.atomic.*;
import java.util.concurrent.locks.LockSupport;

/**
 * Tải nhịp cố định (open-loop), mỗi kết nối keep-alive chạy trên một virtual thread của BỘ TẢI.
 * Độ trễ tính từ thời điểm request LẼ RA được gửi (tránh coordinated omission).
 *   java lab19.Load <rps> <giây> <số kết nối> <path> [warmup giây] [port]
 * In: thông lượng, lỗi, p50/p90/p99/max.
 */
public class Load {
    public static void main(String[] a) throws Exception {
        int rate = Integer.parseInt(a[0]), sec = Integer.parseInt(a[1]), conns = Integer.parseInt(a[2]);
        String path = a[3];
        int warm = a.length > 4 ? Integer.parseInt(a[4]) : 3, port = a.length > 5 ? Integer.parseInt(a[5]) : 8080;
        long interval = 1_000_000_000L * conns / rate;
        long start = System.nanoTime() + 300_000_000L, warmEnd = start + warm * 1_000_000_000L, end = warmEnd + sec * 1_000_000_000L;
        long[] lat = new long[(int) ((long) rate * sec + conns * 10L)];
        AtomicInteger n = new AtomicInteger(), err = new AtomicInteger(), non200 = new AtomicInteger(), closed = new AtomicInteger();
        byte[] req = ("GET " + path + " HTTP/1.1\r\nHost: 127.0.0.1\r\n\r\n").getBytes(StandardCharsets.US_ASCII);
        List<Thread> ts = new ArrayList<>();
        for (int t = 0; t < conns; t++) {
            final int id = t;
            ts.add(Thread.ofVirtual().start(() -> {
                Socket s = null; InputStream in = null; OutputStream out = null;
                long next = start + id * (interval / conns);
                while (next < end) {
                    long now;
                    while ((now = System.nanoTime()) < next) LockSupport.parkNanos(next - now);
                    int code = -1;
                    try {
                        if (s == null) { s = new Socket(); s.setTcpNoDelay(true); s.connect(new InetSocketAddress("127.0.0.1", port)); s.setSoTimeout(30000);
                            in = new BufferedInputStream(s.getInputStream(), 8192); out = s.getOutputStream(); }
                        out.write(req); out.flush();
                        code = readResponse(in);
                        if (code < 0) { s.close(); s = null; }
                    } catch (IOException e) { err.incrementAndGet(); try { if (s != null) s.close(); } catch (IOException ignored) {} s = null; }
                    long done = System.nanoTime();
                    if (next >= warmEnd) {
                        if (code == -1) closed.incrementAndGet(); else if (code != 200) non200.incrementAndGet();
                        int i = n.getAndIncrement(); if (i < lat.length) lat[i] = done - next;
                    }
                    next += interval;
                }
                try { if (s != null) s.close(); } catch (IOException ignored) {}
            }));
        }
        for (Thread t : ts) t.join();
        int m = Math.min(n.get(), lat.length);
        long[] l = Arrays.copyOf(lat, m); Arrays.sort(l);
        double el = sec;
        java.util.function.IntFunction<Double> pct = p -> m == 0 ? 0 : l[Math.min(m - 1, (int) ((long) m * p / 1000))] / 1e6;
        System.out.printf("%-22s mục tiêu %5d rps, đạt %6.0f rps, lỗi %d, khác 200: %d, bị đóng: %d | p50 %7.1f  p90 %7.1f  p99 %8.1f  max %8.1f ms%n",
                path, rate, m / el, err.get(), non200.get(), closed.get(), pct.apply(500), pct.apply(900), pct.apply(990), m == 0 ? 0 : l[m - 1] / 1e6);
    }

    static int readResponse(InputStream in) throws IOException {
        StringBuilder line = new StringBuilder(); int c, len = 0, code = -1; boolean first = true;
        while (true) {
            line.setLength(0);
            while ((c = in.read()) != -1 && c != '\n') if (c != '\r') line.append((char) c);
            if (c == -1) return -1;
            if (line.length() == 0) break;
            String ln = line.toString();
            if (first) { code = Integer.parseInt(ln.split(" ")[1]); first = false; }
            else if (ln.regionMatches(true, 0, "content-length:", 0, 15)) len = Integer.parseInt(ln.substring(15).trim());
        }
        for (int i = 0; i < len; i++) if (in.read() == -1) return -1;
        return code;
    }
}
