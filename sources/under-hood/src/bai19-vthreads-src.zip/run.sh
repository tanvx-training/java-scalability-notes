#!/bin/bash
# run.sh <jdk> <mode> <tag> "<load args>" ... (mỗi tham số sau tag là một lượt tải)
J=/usr/lib/jvm/java-$1-openjdk-amd64/bin; MODE=$2; TAG=$3; shift 3
R=/home/claude/lab19/res; C=/home/claude/lab19/classes
unset JAVA_TOOL_OPTIONS
$J/java -Dstdout.encoding=UTF-8 -Xms1g -Xmx1g -XX:+UseG1GC ${SRVOPTS} -cp $C lab19.Srv $MODE > $R/srv_$TAG.out 2>&1 &
P=$!
until grep -q ready $R/srv_$TAG.out 2>/dev/null; do sleep 0.2; done
for L in "$@"; do
  /usr/lib/jvm/java-25-openjdk-amd64/bin/java -Dstdout.encoding=UTF-8 -Xmx1g -cp $C lab19.Load $L 2>&1 | sed "s/^/[$MODE] /"
done
curl -s 127.0.0.1:8080/stats; echo
kill $P; for i in $(seq 50); do kill -0 $P 2>/dev/null || break; sleep 0.1; done; kill -9 $P 2>/dev/null
