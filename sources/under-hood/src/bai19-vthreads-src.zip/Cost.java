package lab19;

import java.lang.management.ManagementFactory;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.locks.LockSupport;

/**
 * Chi phí tạo thread và bộ nhớ khi chúng đang chờ.
 *   java lab19.Cost <platform|virtual> <N> <độ sâu stack>
 */
public class Cost {
    static volatile boolean stop;
    static void deep(int d, CountDownLatch ready) {
        if (d > 0) { deep(d - 1, ready); return; }
        ready.countDown();
        while (!stop) LockSupport.park();
    }
    static long rssKb() throws Exception {
        for (String l : Files.readAllLines(Path.of("/proc/self/status"))) if (l.startsWith("VmRSS")) return Long.parseLong(l.replaceAll("\\D", ""));
        return -1;
    }
    static long heapUsed() { System.gc(); System.gc(); return ManagementFactory.getMemoryMXBean().getHeapMemoryUsage().getUsed(); }

    public static void main(String[] a) throws Exception {
        boolean virt = a[0].equals("virtual"); int n = Integer.parseInt(a[1]), depth = Integer.parseInt(a[2]);
        long h0 = heapUsed(), r0 = rssKb();
        CountDownLatch ready = new CountDownLatch(n);
        List<Thread> ts = new ArrayList<>(n);
        long t0 = System.nanoTime();
        for (int i = 0; i < n; i++) {
            Runnable r = () -> deep(depth, ready);
            ts.add(virt ? Thread.ofVirtual().start(r) : Thread.ofPlatform().start(r));
        }
        ready.await();
        double ms = (System.nanoTime() - t0) / 1e6;
        long h1 = heapUsed(), r1 = rssKb();
        System.out.printf("JDK %d %-8s N=%,9d sâu=%3d: tạo + chạy tới park %8.0f ms (%5.2f µs/thread) | heap +%6d MB (%5.2f KB/thread) | RSS +%6d MB (%5.2f KB/thread) | OS thread %d%n",
                Runtime.version().feature(), a[0], n, depth, ms, ms * 1000 / n, (h1 - h0) >> 20, (h1 - h0) / 1024.0 / n,
                (r1 - r0) >> 10, (r1 - r0) / (double) n, ManagementFactory.getThreadMXBean().getThreadCount());
        stop = true;
        for (Thread t : ts) LockSupport.unpark(t);
        System.exit(0);
    }
}
