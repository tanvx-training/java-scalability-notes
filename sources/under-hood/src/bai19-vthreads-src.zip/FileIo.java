package lab19;

import java.io.*;
import java.net.*;
import java.lang.management.ManagementFactory;
import java.util.*;

/**
 * N virtual thread cùng chặn trên I/O: (a) đọc file — named pipe chưa có ai ghi; (b) đọc socket chưa có dữ liệu.
 * Đếm số platform thread của JVM trong lúc chặn: carrier có bị "ghim" và JVM phải bù carrier không?
 *   java lab19.FileIo <file|socket> <N> <thư mục fifo>
 */
public class FileIo {
    public static void main(String[] a) throws Exception {
        String mode = a[0]; int n = Integer.parseInt(a[1]); String dir = a.length > 2 ? a[2] : "/tmp";
        var mx = ManagementFactory.getThreadMXBean();
        System.out.printf("JDK %d %-6s trước: %d platform thread%n", Runtime.version().feature(), mode, mx.getThreadCount());
        List<Thread> vts = new ArrayList<>();
        var reached = new java.util.concurrent.atomic.AtomicInteger();
        ServerSocket ss = mode.equals("socket") ? new ServerSocket(0, 4096) : null;
        List<Socket> accepted = Collections.synchronizedList(new ArrayList<>());
        if (ss != null) Thread.ofPlatform().daemon().start(() -> { try { while (true) accepted.add(ss.accept()); } catch (IOException e) {} });
        long t0 = System.nanoTime();
        for (int i = 0; i < n; i++) {
            final int id = i;
            vts.add(Thread.ofVirtual().start(() -> {
                reached.incrementAndGet();
                try {
                    if (mode.equals("file")) {
                        try (var in = new FileInputStream(dir + "/f" + id)) { in.read(); }     // chặn: chưa có ai ghi vào FIFO
                    } else {
                        try (var s = new Socket("127.0.0.1", ss.getLocalPort())) { s.getInputStream().read(); }  // chặn: server không gửi gì
                    }
                } catch (IOException e) { }
            }));
        }
        Thread.sleep(3000);
        long tp = System.nanoTime();
        Thread probe = Thread.ofVirtual().start(() -> {});
        boolean ran = probe.join(java.time.Duration.ofSeconds(2));
        System.out.printf("  đã tới lệnh chặn: %d/%d; một virtual thread mới %s%n", reached.get(), n,
                ran ? String.format("chạy được sau %.1f ms", (System.nanoTime() - tp) / 1e6) : "KHÔNG chạy được trong 2 s");
        int peak = mx.getThreadCount();
        long carriers = Thread.getAllStackTraces().keySet().stream().filter(t -> t.getName().startsWith("ForkJoinPool")).count();
        System.out.printf("JDK %d %-6s %d virtual thread đang chặn: %d platform thread (%d carrier ForkJoinPool), sau %.1f s%n",
                Runtime.version().feature(), mode, n, peak, carriers, (System.nanoTime() - t0) / 1e9);
        System.exit(0);
    }
}
