package lab19;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

/** N virtual thread mỗi cái chạy `sleep 3` và đọc stdout của nó (pipe). Một VT mới có chạy được không? */
public class ProcIo {
    public static void main(String[] a) throws Exception {
        int n = Integer.parseInt(a[0]);
        AtomicInteger started = new AtomicInteger();
        long t0 = System.nanoTime();
        List<Thread> ts = new ArrayList<>();
        for (int i = 0; i < n; i++) ts.add(Thread.ofVirtual().start(() -> {
            try {
                Process p = new ProcessBuilder("sleep", "3").start();
                started.incrementAndGet();
                p.getInputStream().read();                      // đọc pipe: chặn tới khi tiến trình con kết thúc
                p.waitFor();
            } catch (Exception e) { }
        }));
        Thread.sleep(500);
        long tp = System.nanoTime();
        Thread probe = Thread.ofVirtual().start(() -> {});
        probe.join();
        double probeMs = (System.nanoTime() - tp) / 1e6;
        for (Thread t : ts) t.join();
        System.out.printf("JDK %d: %d VT × (sleep 3 + đọc pipe): xong sau %.1f s; sau 0,5 s mới có %d tiến trình được khởi động; một VT rỗng phải chờ %.0f ms%n",
                Runtime.version().feature(), n, (System.nanoTime() - t0) / 1e9, started.get(), probeMs);
    }
}
