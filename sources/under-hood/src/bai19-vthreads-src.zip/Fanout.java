package lab19;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Một request gọi song song 3 downstream (200 ms, 1000 ms, và một cái LỖI sau 50 ms).
 * So sánh ExecutorService + Future với StructuredTaskScope (JDK 25, preview) và ScopedValue.
 *   java --enable-preview lab19.Fanout
 */
public class Fanout {
    static final AtomicInteger stillRunning = new AtomicInteger();
    static final ScopedValue<String> REQUEST_ID = ScopedValue.newInstance();

    static String call(String name, long ms, boolean fail) throws Exception {
        stillRunning.incrementAndGet();
        try {
            Thread.sleep(ms);
            if (fail) throw new IllegalStateException(name + " lỗi");
            return name + "@" + REQUEST_ID.orElse("?");
        } finally { stillRunning.decrementAndGet(); }
    }

    public static void main(String[] a) throws Exception {
        // 1) ExecutorService + Future: lỗi ở task 3 không dừng task 2
        long t0 = System.nanoTime();
        try (var ex = Executors.newVirtualThreadPerTaskExecutor()) {
            Future<String> f1 = ex.submit(() -> call("user", 200, false));
            Future<String> f2 = ex.submit(() -> call("orders", 1000, false));
            Future<String> f3 = ex.submit(() -> call("pricing", 50, true));
            try { f1.get(); f2.get(); f3.get(); }
            catch (ExecutionException e) {
                System.out.printf("Executor+Future : thấy lỗi sau %4.0f ms, lúc đó còn %d downstream đang chạy%n", (System.nanoTime() - t0) / 1e6, stillRunning.get());
            }
        }   // close() chờ mọi task xong
        System.out.printf("Executor+Future : request kết thúc sau %4.0f ms%n", (System.nanoTime() - t0) / 1e6);

        // 2) StructuredTaskScope: lỗi đầu tiên huỷ (interrupt) các nhánh còn lại
        long t1 = System.nanoTime();
        ScopedValue.where(REQUEST_ID, "req-42").call(() -> {
            try (var scope = StructuredTaskScope.open()) {
                var s1 = scope.fork(() -> call("user", 200, false));
                var s2 = scope.fork(() -> call("orders", 1000, false));
                var s3 = scope.fork(() -> call("pricing", 50, true));
                scope.join();
                return s1.get() + s2.get() + s3.get();
            } catch (StructuredTaskScope.FailedException e) {
                System.out.printf("StructuredScope : thấy lỗi sau %4.0f ms (%s), còn %d downstream đang chạy%n",
                        (System.nanoTime() - t1) / 1e6, e.getCause().getMessage(), stillRunning.get());
                return null;
            }
        });
        System.out.printf("StructuredScope : request kết thúc sau %4.0f ms%n", (System.nanoTime() - t1) / 1e6);

        // 3) ScopedValue được nhìn thấy trong các nhánh con của scope
        String r = ScopedValue.where(REQUEST_ID, "req-77").call(() -> {
            try (var scope = StructuredTaskScope.open()) {
                var s = scope.fork(() -> call("audit", 10, false));
                scope.join();
                return s.get();
            }
        });
        System.out.println("ScopedValue trong nhánh con: " + r);
    }
}
