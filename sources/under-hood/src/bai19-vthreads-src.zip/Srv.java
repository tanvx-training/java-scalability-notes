package lab19;

import com.sun.net.httpserver.*;
import java.io.*;
import java.lang.management.ManagementFactory;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/**
 * Service mô phỏng, đổi được mô hình thread:
 *   java lab19.Srv <pool200|vt> [port]
 * Endpoint:
 *   /io?ms=50     gọi "downstream" chờ ms (Thread.sleep) — I/O-bound
 *   /cpu?ms=300   tính toán ms CPU thật — CPU-bound
 *   /fast         trả về ngay
 *   /db?ms=20     lấy 1 trong 10 "kết nối" (Semaphore, chờ tối đa 1 s), giữ ms
 *   /tl           dùng một buffer 64 KB "cache theo thread" (ThreadLocal)
 *   /stats        số liệu phía server
 */
public class Srv {
    static final ExecutorService CPU_POOL = Executors.newFixedThreadPool(2, r -> { Thread t = new Thread(r, "cpu-pool"); t.setDaemon(true); return t; });
    static final Semaphore POOL = new Semaphore(10, true);              // giống HikariCP maximumPoolSize=10
    static final AtomicLong tlCreated = new AtomicLong(), dbTimeouts = new AtomicLong(), inflight = new AtomicLong(), maxInflight = new AtomicLong();
    static final ThreadLocal<byte[]> BUF = ThreadLocal.withInitial(() -> { tlCreated.incrementAndGet(); return new byte[64 * 1024]; });
    static volatile long sink;
    static final AtomicLong tlxCreated = new AtomicLong();
    /** "Đối tượng đắt" cache theo thread: khởi tạo tốn ~1 ms CPU (như ObjectMapper/Cipher). */
    static final ThreadLocal<long[]> EXPENSIVE = ThreadLocal.withInitial(() -> { tlxCreated.incrementAndGet(); return new long[]{work(Srv.ITER_PER_MS)}; });
    static final AtomicInteger ERR = new AtomicInteger();

    static int q(HttpExchange ex, String k, int def) {
        String qs = ex.getRequestURI().getQuery();
        if (qs != null) for (String p : qs.split("&")) if (p.startsWith(k + "=")) return Integer.parseInt(p.substring(k.length() + 1));
        return def;
    }
    static void reply(HttpExchange ex, int code, String body) throws IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        ex.sendResponseHeaders(code, b.length);
        try (OutputStream o = ex.getResponseBody()) { o.write(b); }
    }
    static long burn(long nanos) { long end = System.nanoTime() + nanos, x = 0; while (System.nanoTime() < end) x += x * 31 + 7; return x; }
    static long ITER_PER_MS;                                    // hiệu chỉnh lúc khởi động
    static long work(long iters) { long x = 7; for (long i = 0; i < iters; i++) { x = x * 6364136223846793005L + 1442695040888963407L; x ^= x >>> 29; } return x; }
    static void calibrate() {
        for (int r = 0; r < 5; r++) work(20_000_000);           // khởi động JIT
        long t0 = System.nanoTime(); sink = work(200_000_000); long ns = System.nanoTime() - t0;
        ITER_PER_MS = 200_000_000L * 1_000_000 / ns;
        System.out.println("calibrated " + ITER_PER_MS + " iter/ms");
    }

    public static void main(String[] a) throws Exception {
        String mode = a[0];
        int port = a.length > 1 ? Integer.parseInt(a[1]) : 8080;
        calibrate();
        HttpServer s = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 4096);
        ExecutorService ex = mode.equals("vt") ? Executors.newVirtualThreadPerTaskExecutor() : Executors.newFixedThreadPool(200);
        s.setExecutor(ex);
        s.createContext("/", h -> {
            long n = inflight.incrementAndGet(); maxInflight.accumulateAndGet(n, Math::max);
            try {
                String p = h.getRequestURI().getPath();
                switch (p) {
                    case "/io" -> { Thread.sleep(q(h, "ms", 50)); reply(h, 200, "{\"ok\":true}"); }
                    case "/cpu" -> { sink = work(q(h, "ms", 300) * ITER_PER_MS); reply(h, 200, "{\"cpu\":true}"); }
                    case "/cpuoff" -> { long it = q(h, "ms", 300) * ITER_PER_MS; sink = CPU_POOL.submit(() -> work(it)).get(); reply(h, 200, "{\"cpu\":true}"); }
                    case "/tlx" -> { sink += EXPENSIVE.get()[0]; reply(h, 200, "{\"tlx\":true}"); }
                    case "/fast" -> reply(h, 200, "{\"fast\":true}");
                    case "/db" -> {
                        if (POOL.tryAcquire(1, TimeUnit.SECONDS)) {
                            try { Thread.sleep(q(h, "ms", 20)); } finally { POOL.release(); }
                            reply(h, 200, "{\"db\":true}");
                        } else { dbTimeouts.incrementAndGet(); reply(h, 503, "{\"err\":\"pool timeout\"}"); }
                    }
                    case "/tl" -> { byte[] b = BUF.get(); for (int i = 0; i < b.length; i += 64) b[i]++; sink += b[0]; reply(h, 200, "{\"tl\":true}"); }
                    case "/stats" -> {
                        var mem = ManagementFactory.getMemoryMXBean().getHeapMemoryUsage();
                        long gcCount = 0, gcMs = 0;
                        for (var g : ManagementFactory.getGarbageCollectorMXBeans()) { gcCount += g.getCollectionCount(); gcMs += g.getCollectionTime(); }
                        reply(h, 200, String.format("{\"mode\":\"%s\",\"tlxCreated\":%d,\"tlCreated\":%d,\"dbTimeouts\":%d,\"maxInflight\":%d,\"heapUsedMB\":%d,\"gcCount\":%d,\"gcMs\":%d,\"threads\":%d}",
                                mode, tlxCreated.get(), tlCreated.get(), dbTimeouts.get(), maxInflight.get(), mem.getUsed() >> 20, gcCount, gcMs,
                                ManagementFactory.getThreadMXBean().getThreadCount()));
                    }
                    default -> reply(h, 404, "{}");
                }
            } catch (Exception e) { if (ERR.getAndIncrement() < 3) e.printStackTrace(); try { reply(h, 500, "{}"); } catch (IOException ignored) {} }
            finally { inflight.decrementAndGet(); }
        });
        s.start();
        System.out.println("ready " + mode + " pid " + ProcessHandle.current().pid());
    }
}
