#!/bin/bash
# mix.sh <jdk> <mode> <tag> "<load A>" "<load B>" — chạy hai luồng tải song song
J=/usr/lib/jvm/java-$1-openjdk-amd64/bin; MODE=$2; TAG=$3
R=/home/claude/lab19/res; C=/home/claude/lab19/classes; L=/usr/lib/jvm/java-25-openjdk-amd64/bin/java
unset JAVA_TOOL_OPTIONS
$J/java -Dstdout.encoding=UTF-8 -Xms1g -Xmx1g -XX:+UseG1GC -Dsun.net.httpserver.maxIdleConnections=20000 ${SRVOPTS} -cp $C lab19.Srv $MODE > $R/srv_$TAG.out 2>&1 &
P=$!
until grep -q ready $R/srv_$TAG.out 2>/dev/null; do sleep 0.2; done
$L -Dstdout.encoding=UTF-8 -Xmx512m -cp $C lab19.Load $4 2>&1 | sed "s/^/[$MODE] /" &
A=$!
$L -Dstdout.encoding=UTF-8 -Xmx512m -cp $C lab19.Load $5 2>&1 | sed "s/^/[$MODE] /"
wait $A
curl -s 127.0.0.1:8080/stats; echo
kill $P; for i in $(seq 50); do kill -0 $P 2>/dev/null || break; sleep 0.1; done; kill -9 $P 2>/dev/null
