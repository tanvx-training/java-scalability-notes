#!/bin/bash
# Chạy Shop dưới tải 70 s; trong lúc chạy, chẩn đoán bằng jcmd/JFR mà không restart.
unset JAVA_TOOL_OPTIONS
J=/usr/lib/jvm/java-25-openjdk-amd64/bin
R=run; rm -rf $R; mkdir -p $R
pause(){ python3 -c "import time;time.sleep($1)"; }
t0=$(date +%s.%N)
stamp(){ python3 -c "print(f'{$(date +%s.%N)-$t0:6.1f}s')"; }
jc(){ # jc <tên file> <lệnh jcmd...> : ghi output, đo thời gian
  local f=$1; shift; local s=$(date +%s%N)
  $J/jcmd $P "$@" > $R/$f 2>&1; local e=$(date +%s%N)
  echo "$(stamp) jcmd $* → $(( (e-s)/1000000 )) ms, $(wc -l < $R/$f) dòng" | tee -a $R/timeline.txt
}
$J/java -Xmx512m -Dsun.net.httpserver.maxIdleConnections=20000 -Xlog:safepoint:file=$R/safepoint.log:uptime,level,tags \
   -cp cls lab25.Shop > $R/shop.out 2>&1 &
for i in $(seq 1 100); do grep -q ready $R/shop.out 2>/dev/null && break; pause 0.1; done
P=$(grep -o 'pid [0-9]*' $R/shop.out | cut -d' ' -f2); echo "Shop pid $P" | tee $R/timeline.txt
$J/java -cp cls lab25.Load 40 70 200 /price 3 > $R/load_price.txt 2>&1 &
$J/java -cp cls lab25.Load 30 70 200 /report 3 > $R/load_report.txt 2>&1 &
$J/java -cp cls lab25.Load 150 70 400 /stock 3 > $R/load_stock.txt 2>&1 &
pause 8
jc jcmd_l.txt -l 2>/dev/null; $J/jcmd -l > $R/jcmd_l.txt
jc version.txt VM.version
jc flags.txt VM.flags
jc cmdline.txt VM.command_line
jc uptime.txt VM.uptime
jc help.txt help
jc threads.txt Thread.print
jc threads_json.txt Thread.dump_to_file -format=json $PWD/$R/threads.json
jc heapinfo1.txt GC.heap_info
jc histo1.txt GC.class_histogram
jc jfr_diag.txt JFR.start name=diag settings=profile filename=$PWD/$R/diag.jfr
jc jfr_cpu.txt JFR.start name=cpu jdk.CPUTimeSample#enabled=true jdk.CPUTimeSample#throttle=10ms filename=$PWD/$R/cputime.jfr
jc jfr_mt.txt JFR.start name=mt 'method-timing=lab25.Shop::validSku;lab25.Shop::stock' filename=$PWD/$R/mt.jfr
pause 30
jc jfr_check.txt JFR.check
jc jfr_dump.txt JFR.dump name=diag
jc jfr_stop_cpu.txt JFR.stop name=cpu
jc jfr_stop_mt.txt JFR.stop name=mt
jc jfr_stop_diag.txt JFR.stop name=diag
jc histo2.txt GC.class_histogram
jc heapinfo2.txt GC.heap_info
jc nmt.txt VM.native_memory summary
jc metaspace.txt VM.metaspace
jc codecache.txt Compiler.codecache
jc sysprops.txt VM.system_properties
jc heapdump.txt GC.heap_dump $PWD/$R/heap.hprof
ls -la $R/heap.hprof | tee -a $R/timeline.txt
wait %2 %3 %4
kill $P; wait 2>/dev/null
echo done
