#!/bin/bash
unset JAVA_TOOL_OPTIONS
J=/usr/lib/jvm/java-25-openjdk-amd64/bin; R=run2; rm -rf $R; mkdir -p $R
pause(){ python3 -c "import time;time.sleep($1)"; }
$J/java -Xmx512m -Dsun.net.httpserver.maxIdleConnections=20000 -cp cls lab25.Shop > $R/shop.out 2>&1 &
for i in $(seq 1 100); do grep -q ready $R/shop.out 2>/dev/null && break; pause 0.1; done
P=$(grep -o 'pid [0-9]*' $R/shop.out | cut -d' ' -f2)
$J/java -Dstdout.encoding=UTF-8 -cp cls lab25.Load 400 30 800 /stock 3 > $R/load_stock.txt 2>&1 &
pause 8
$J/jcmd $P JFR.start name=lock jdk.JavaMonitorEnter#threshold=1ms filename=$PWD/$R/lock.jfr > /dev/null
pause 1
$J/jcmd $P Thread.print > $R/threads.txt
pause 10
$J/jcmd $P JFR.stop name=lock > /dev/null
wait %2; kill $P; wait 2>/dev/null
