#!/bin/bash
unset JAVA_TOOL_OPTIONS
J=/usr/lib/jvm/java-25-openjdk-amd64/bin; R=run4; rm -rf $R; mkdir -p $R
pause(){ python3 -c "import time;time.sleep($1)"; }
$J/java -Xmx512m -XX:NativeMemoryTracking=summary -Dsun.net.httpserver.maxIdleConnections=20000 -cp cls lab25.Shop > $R/shop.out 2>&1 &
for i in $(seq 1 100); do grep -q ready $R/shop.out 2>/dev/null && break; pause 0.1; done
P=$(grep -o 'pid [0-9]*' $R/shop.out | cut -d' ' -f2)
$J/java -cp cls lab25.Load 30 25 200 /report 3 > $R/lr.txt 2>&1 &
$J/java -cp cls lab25.Load 60 25 200 /price 3 > $R/lp.txt 2>&1 &
pause 5
$J/jcmd $P VM.native_memory baseline > /dev/null
pause 18
$J/jcmd $P VM.native_memory summary scale=MB > $R/nmt_summary.txt
$J/jcmd $P VM.native_memory summary.diff scale=MB > $R/nmt_diff.txt
grep -E "VmRSS|VmSize" /proc/$P/status > $R/rss.txt
wait %2 %3; kill $P; wait 2>/dev/null
