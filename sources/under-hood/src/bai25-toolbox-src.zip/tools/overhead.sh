#!/bin/bash
# CPU của tiến trình Shop dưới cùng tải, có/không JFR. Đo CPU (utime+stime) trong cửa sổ 20 s.
unset JAVA_TOOL_OPTIONS
J=/usr/lib/jvm/java-25-openjdk-amd64/bin; R=run3; mkdir -p $R
pause(){ python3 -c "import time;time.sleep($1)"; }
cpu(){ awk '{print $14+$15}' /proc/$1/stat; }
run(){ local tag=$1; shift
  $J/java -Xmx512m -Dsun.net.httpserver.maxIdleConnections=20000 "$@" -cp cls lab25.Shop > $R/shop_$tag.out 2>&1 &
  for i in $(seq 1 100); do grep -q ready $R/shop_$tag.out 2>/dev/null && break; pause 0.1; done
  P=$(grep -o 'pid [0-9]*' $R/shop_$tag.out | cut -d' ' -f2)
  $J/java -Dstdout.encoding=UTF-8 -cp cls lab25.Load 100 35 300 /price 3 > $R/lp_$tag.txt 2>&1 &
  $J/java -Dstdout.encoding=UTF-8 -cp cls lab25.Load 30 35 200 /report 3 > $R/lr_$tag.txt 2>&1 &
  pause 12; c0=$(cpu $P); pause 20; c1=$(cpu $P)
  wait %2 %3; kill $P; wait 2>/dev/null
  echo "$tag: CPU Shop = $(( (c1-c0) )) tick/20 s (100 tick = 1 CPU-giây) | $(tail -1 $R/lp_$tag.txt | sed 's/.*| //')"
}
for r in 1 2; do
run none
run jfr_default -XX:StartFlightRecording=filename=$R/d.jfr
run jfr_profile -XX:StartFlightRecording=settings=profile,filename=$R/p.jfr
run jfr_profile_cpu "-XX:StartFlightRecording=settings=profile,jdk.CPUTimeSample#enabled=true,jdk.CPUTimeSample#throttle=10ms,filename=$R/c.jfr"
done
