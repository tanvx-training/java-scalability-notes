package lab25;

import java.time.Duration;
import jdk.jfr.consumer.RecordingStream;

/** JFR streaming trong chính tiến trình (JEP 349): tự cảnh báo khi có pause GC dài hoặc chờ khoá lâu. */
public class Watchdog {
    public static void start() {
        Thread t = new Thread(() -> {
            try (RecordingStream rs = new RecordingStream()) {
                rs.enable("jdk.GarbageCollection");
                rs.enable("jdk.JavaMonitorEnter").withThreshold(Duration.ofMillis(20)).withStackTrace();
                rs.enable("jdk.CPULoad").withPeriod(Duration.ofSeconds(2));
                rs.onEvent("jdk.GarbageCollection", e -> {
                    if (e.getDuration("sumOfPauses").toMillis() >= 5)
                        System.out.printf("[watchdog] GC %s: pause %d ms%n", e.getString("name"), e.getDuration("sumOfPauses").toMillis());
                });
                rs.onEvent("jdk.JavaMonitorEnter", e -> System.out.printf("[watchdog] chờ khoá %d ms tại %s%n",
                        e.getDuration().toMillis(), e.getStackTrace().getFrames().get(0).getMethod().getName()));
                rs.onEvent("jdk.CPULoad", e -> System.out.printf("[watchdog] CPU tiến trình %.0f%%, máy %.0f%%%n",
                        100 * e.getFloat("jvmUser"), 100 * e.getFloat("machineTotal")));
                rs.start();
            }
        }, "jfr-watchdog");
        t.setDaemon(true); t.start();
    }
    public static void main(String[] a) throws Exception {
        start();
        Shop.main(a);
    }
}
