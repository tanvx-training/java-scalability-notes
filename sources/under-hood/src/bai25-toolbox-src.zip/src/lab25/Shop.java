package lab25;

import com.sun.net.httpserver.*;
import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

/**
 * Một "service đang có vấn đề" để chẩn đoán mà không restart:
 *   /price   CPU nóng: kiểm tra SKU bằng String.matches (biên dịch regex mỗi lần) + String.format
 *   /report  cấp phát nhiều + rò bộ nhớ: mỗi request giữ lại 20 KB trong một cache static không bao giờ xoá
 *   /stock   tranh chấp khoá: mọi request đi qua một synchronized giữ khoá ~2 ms
 */
public class Shop {
    static final List<byte[]> REPORT_CACHE = new ArrayList<>();         // rò rỉ
    static final Object INVENTORY_LOCK = new Object();
    static volatile long sink;

    static String reply(HttpExchange ex, String body) throws IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        ex.sendResponseHeaders(200, b.length);
        try (OutputStream o = ex.getResponseBody()) { o.write(b); }
        return body;
    }

    static boolean validSku(String sku) { return sku.matches("[A-Z]{3}-\\d{4}"); }

    static String price(int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) {
            String sku = String.format("ABC-%04d", i % 10000);
            if (validSku(sku)) sb.append(String.format("%s=%.2f;", sku, i * 1.07));
        }
        return sb.toString();
    }

    static String report() {
        List<Long> values = new ArrayList<>();
        for (long i = 0; i < 20_000; i++) values.add(i * 31);              // boxing
        long sum = 0; for (Long v : values) sum += v;
        synchronized (REPORT_CACHE) { REPORT_CACHE.add(new byte[20 * 1024]); }
        return "{\"sum\":" + sum + ",\"cached\":" + REPORT_CACHE.size() + "}";
    }

    static String stock() {
        synchronized (INVENTORY_LOCK) {                                     // khoá chung cho mọi request
            long t = System.nanoTime(), x = 0;
            while (System.nanoTime() - t < 2_000_000) x += t ^ x;           // ~2 ms giữ khoá
            sink = x;
        }
        return "{\"stock\":42}";
    }

    public static void main(String[] a) throws Exception {
        HttpServer s = HttpServer.create(new InetSocketAddress("127.0.0.1", 8080), 4096);
        s.setExecutor(Executors.newFixedThreadPool(50));
        s.createContext("/", h -> {
            try {
                switch (h.getRequestURI().getPath()) {
                    case "/price"  -> reply(h, price(200));
                    case "/report" -> reply(h, report());
                    case "/stock"  -> reply(h, stock());
                    default -> { h.sendResponseHeaders(404, -1); h.close(); }
                }
            } catch (Exception e) { try { h.sendResponseHeaders(500, -1); h.close(); } catch (IOException ignored) {} }
        });
        s.start();
        System.out.println("ready pid " + ProcessHandle.current().pid());
    }
}
