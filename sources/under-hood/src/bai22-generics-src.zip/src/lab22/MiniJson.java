package lab22;

import java.lang.reflect.*;
import java.util.*;

/**
 * Một "object mapper" tối giản (KHÔNG phải Jackson) để thấy cơ chế: mapper chỉ dựng được kiểu
 * mà nó được cho biết lúc chạy. Không biết kiểu phần tử -> đành tạo LinkedHashMap, như Jackson.
 */
public final class MiniJson {
    private final String s; private int i;
    private MiniJson(String s) { this.s = s; }

    public static Object read(String json, Type type) { return bind(new MiniJson(json).value(), type); }
    public static <T> T read(String json, TypeRef<T> ref) { @SuppressWarnings("unchecked") T t = (T) read(json, ref.type()); return t; }

    static Object bind(Object v, Type t) {
        if (t instanceof ParameterizedType p && p.getRawType() == List.class && v instanceof List<?> l) {
            Type el = p.getActualTypeArguments()[0];
            List<Object> out = new ArrayList<>();
            for (Object x : l) out.add(bind(x, el));
            return out;
        }
        if (t instanceof Class<?> c && c.isRecord() && v instanceof Map<?, ?> m) {
            try {
                RecordComponent[] rc = c.getRecordComponents();
                Object[] args = new Object[rc.length]; Class<?>[] types = new Class<?>[rc.length];
                for (int k = 0; k < rc.length; k++) {
                    types[k] = rc[k].getType();
                    Object raw = m.get(rc[k].getName());
                    args[k] = (types[k] == long.class) ? ((Number) raw).longValue() : (types[k] == int.class) ? ((Number) raw).intValue() : raw;
                }
                return c.getDeclaredConstructor(types).newInstance(args);
            } catch (ReflectiveOperationException e) { throw new RuntimeException(e); }
        }
        return v;   // List.class thô, Object, TypeVariable T…: giữ nguyên cấu trúc JSON (LinkedHashMap / ArrayList)
    }

    private Object value() {
        ws(); char c = s.charAt(i);
        if (c == '{') { i++; Map<String, Object> m = new LinkedHashMap<>(); ws();
            if (s.charAt(i) == '}') { i++; return m; }
            while (true) { ws(); String k = str(); ws(); i++; m.put(k, value()); ws(); if (s.charAt(i++) == '}') return m; } }
        if (c == '[') { i++; List<Object> l = new ArrayList<>(); ws();
            if (s.charAt(i) == ']') { i++; return l; }
            while (true) { l.add(value()); ws(); if (s.charAt(i++) == ']') return l; } }
        if (c == '"') return str();
        int st = i; while (i < s.length() && "-0123456789.".indexOf(s.charAt(i)) >= 0) i++;
        return Long.parseLong(s.substring(st, i));
    }
    private String str() { int st = ++i; while (s.charAt(i) != '"') i++; return s.substring(st, i++); }
    private void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }
}
