package lab22;

/** Record pattern gọi accessor; accessor ném lỗi thì switch bọc nó trong MatchException. */
public class AccessorThrows {
    record Money(long cents) {
        public long cents() { if (cents < 0) throw new IllegalStateException("âm: " + cents); return cents; }
    }
    static String show(Object o) {
        return switch (o) {
            case Money(long c) when c > 100_00 -> "lớn";
            case Money(long c) -> "nhỏ";
            default -> "khác";
        };
    }
    public static void main(String[] a) {
        System.out.println(show(new Money(5_00)));
        try { show(new Money(-1)); }
        catch (MatchException e) { System.out.println(e + "\n  cause: " + e.getCause()); }
    }
}
