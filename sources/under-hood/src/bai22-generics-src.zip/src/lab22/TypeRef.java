package lab22;

import java.lang.reflect.*;

/** Cùng ý tưởng với com.fasterxml.jackson.core.type.TypeReference (3 dòng cốt lõi viết lại). */
public abstract class TypeRef<T> {
    final Type type;
    protected TypeRef() {
        Type sup = getClass().getGenericSuperclass();          // đọc attribute Signature của class con
        if (sup instanceof Class<?>) throw new IllegalArgumentException("thiếu thông tin kiểu");
        type = ((ParameterizedType) sup).getActualTypeArguments()[0];
    }
    public Type type() { return type; }
}
