package lab22;

import java.lang.reflect.*;
import java.util.*;

/** Generic chỉ tồn tại lúc biên dịch? Đo xem cái gì còn lại lúc chạy. */
public class Erasure {
    static class Box<T extends Comparable<T>> {          // T bị xoá thành Comparable
        T value;
        T get() { return value; }
        void set(T v) { value = v; }
    }
    record Order(long id, String sku) {}

    List<Order> orders;                                  // khai báo field
    static void create(List<Order> body) {}              // khai báo tham số (như @RequestBody)
    static Map<String, List<Order>> byUser() { return null; }

    public static void main(String[] a) throws Exception {
        List<String> s = new ArrayList<>();
        List<Integer> n = new ArrayList<>();
        System.out.println("ArrayList<String>.class == ArrayList<Integer>.class ? " + (s.getClass() == n.getClass()));
        System.out.println("tham số kiểu của ArrayList: " + Arrays.toString(ArrayList.class.getTypeParameters()));

        // heap pollution: nhét Integer vào List<String> qua kiểu thô
        @SuppressWarnings({"rawtypes", "unchecked"}) List raw = s;
        raw.add(42);
        System.out.println("add(42) vào List<String>: không lỗi, size = " + s.size());
        Object o = s.get(0);                              // không có checkcast
        System.out.println("Object o = s.get(0): không lỗi, o = " + o);
        try { String x = s.get(0); System.out.println(x); }   // javac chèn checkcast String ở đây
        catch (ClassCastException e) { System.out.println("String x = s.get(0): " + e.getClass().getSimpleName() + ": " + e.getMessage()); }

        System.out.println();
        Field f = Erasure.class.getDeclaredField("orders");
        System.out.println("field orders:      getType() = " + f.getType().getName() + "   getGenericType() = " + f.getGenericType());
        Method m = Erasure.class.getDeclaredMethod("create", List.class);
        System.out.println("param của create:  " + m.getGenericParameterTypes()[0]);
        System.out.println("kiểu trả về byUser: " + Erasure.class.getDeclaredMethod("byUser").getGenericReturnType());
        var local = new ArrayList<Order>();
        System.out.println("biến cục bộ new ArrayList<Order>(): getClass() = " + local.getClass().getName()
                + ", getGenericSuperclass() = " + local.getClass().getGenericSuperclass());
        Field bf = Box.class.getDeclaredField("value");
        System.out.println("Box.value: getType() = " + bf.getType().getName() + "   getGenericType() = " + bf.getGenericType());
    }
}
