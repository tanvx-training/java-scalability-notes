package lab22;

import java.lang.reflect.*;
import java.util.*;

/** Vì sao Jackson cần TypeReference: thông tin kiểu chỉ còn trong KHAI BÁO, không còn trong object. */
public class TypeCapture {
    record Order(long id, String sku) {}
    static final String JSON = "[{\"id\":1,\"sku\":\"A-1\"},{\"id\":2,\"sku\":\"B-2\"}]";

    // 1) không có cách viết List<Order>.class — chỉ có List.class
    @SuppressWarnings("unchecked")
    static List<Order> withClass() { return (List<Order>) MiniJson.read(JSON, List.class); }

    // 2) TypeRef: lớp con vô danh mang Signature TypeRef<List<Order>>
    static List<Order> withTypeRef() { return MiniJson.read(JSON, new TypeRef<List<Order>>() {}); }

    // 3) cái bẫy: TypeRef bên trong method generic — T chưa được thay bằng gì cả
    static <T> List<T> readList(String json) { return MiniJson.read(json, new TypeRef<List<T>>() {}); }

    // 4) cách đúng cho method generic: truyền Class<T> và tự dựng ParameterizedType
    static <T> List<T> readList(String json, Class<T> el) {
        ParameterizedType p = new ParameterizedType() {
            public Type[] getActualTypeArguments() { return new Type[]{el}; }
            public Type getRawType() { return List.class; }
            public Type getOwnerType() { return null; }
            public String toString() { return "java.util.List<" + el.getName() + ">"; }
        };
        @SuppressWarnings("unchecked") List<T> l = (List<T>) MiniJson.read(json, p);
        return l;
    }

    // 5) như Spring MVC: kiểu nằm sẵn trong chữ ký method của controller
    static void create(List<Order> body) {}

    static void show(String label, List<Order> l) {
        Object first = ((List<?>) l).get(0);                 // đọc như Object: javac không chèn checkcast
        System.out.printf("%-42s phần tử[0] là %s%n", label, first.getClass().getName());
        try { long id = l.get(0).id(); System.out.printf("%-42s l.get(0).id() = %d%n", "", id); }
        catch (ClassCastException e) { System.out.printf("%-42s l.get(0).id() → ClassCastException: %s%n", "", e.getMessage()); }
    }

    public static void main(String[] a) throws Exception {
        show("read(json, List.class)", withClass());
        TypeRef<List<Order>> r = new TypeRef<List<Order>>() {};
        System.out.println("\nnew TypeRef<List<Order>>(){}: class " + r.getClass().getName()
                + "\n   getGenericSuperclass() = " + r.getClass().getGenericSuperclass() + "\n   type = " + r.type());
        show("read(json, new TypeRef<List<Order>>(){})", withTypeRef());
        List<Order> viaT = TypeCapture.<Order>readList(JSON);
        System.out.println("\nTypeRef<List<T>> trong method generic: type = " + new Object() {
            <T> Type t() { return new TypeRef<List<T>>() {}.type(); } }.<Order>t());
        show("readList<Order>(json)", viaT);
        show("readList(json, Order.class)", readList(JSON, Order.class));
        Method m = TypeCapture.class.getDeclaredMethod("create", List.class);
        Type pt = m.getGenericParameterTypes()[0];
        System.out.println("\ncreate(List<Order> body): getGenericParameterTypes()[0] = " + pt);
        @SuppressWarnings("unchecked") List<Order> body = (List<Order>) MiniJson.read(JSON, pt);
        show("read(json, <kiểu tham số của create>)", body);
    }
}
