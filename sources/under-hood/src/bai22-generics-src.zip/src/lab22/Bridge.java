package lab22;

import java.lang.annotation.*;
import java.lang.reflect.Method;
import java.util.*;
import java.util.function.Supplier;

/** Bridge method: javac sinh thêm method để generic + override vẫn đúng sau khi xoá kiểu. */
public class Bridge {
    @Retention(RetentionPolicy.RUNTIME) @interface Audit {}

    static final class Name implements Comparable<Name> {
        final String v; Name(String v) { this.v = v; }
        @Audit @Override public int compareTo(Name o) { return v.compareTo(o.v); }
    }
    static final class Repo implements Supplier<String> {
        @Override public String get() { return "covariant"; }          // Supplier.get() trả Object
    }

    public static void main(String[] a) {
        for (Class<?> c : List.of(Name.class, Repo.class)) {
            System.out.println(c.getSimpleName() + ":");
            Arrays.stream(c.getDeclaredMethods()).sorted(Comparator.comparing(Method::toString)).forEach(m ->
                System.out.printf("  %-58s bridge=%-5b synthetic=%-5b @Audit=%b%n", m.toGenericString().replace("lab22.Bridge$", ""),
                        m.isBridge(), m.isSynthetic(), m.isAnnotationPresent(Audit.class)));
        }
        System.out.println();
        @SuppressWarnings({"rawtypes", "unchecked"}) Comparable raw = new Name("an");
        try { raw.compareTo("không phải Name"); }
        catch (ClassCastException e) {
            System.out.println(e.getClass().getSimpleName() + ": " + e.getMessage());
            for (StackTraceElement el : e.getStackTrace()) System.out.println("  at " + el);
        }
    }
}
