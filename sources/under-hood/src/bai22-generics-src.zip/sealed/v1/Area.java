package geo;
/** switch không có default: javac chấp nhận vì Shape là sealed và đã đủ ba trường hợp. */
public final class Area {
    public static double of(Shape s) {
        return switch (s) {
            case Circle c          -> Math.PI * c.r() * c.r();
            case Square q          -> q.side() * q.side();
            case Rect(double w, double h) -> w * h;           // record pattern: tháo record
        };
    }
}
