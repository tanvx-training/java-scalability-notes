package geo;
public record Rect(double w, double h) implements Shape {}
