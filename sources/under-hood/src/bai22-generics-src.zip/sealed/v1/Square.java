package geo;
public record Square(double side) implements Shape {}
