package geo;
public record Hexagon(double a) implements Shape {}
