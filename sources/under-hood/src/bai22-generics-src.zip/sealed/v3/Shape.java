package geo;
public interface Shape {}
