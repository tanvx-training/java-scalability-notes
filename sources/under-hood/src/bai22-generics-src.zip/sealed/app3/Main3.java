package app;
public class Main3 {
    public static void main(String[] a) {
        Object h = new geo.Hexagon(1);
        System.out.println(h);
    }
}
