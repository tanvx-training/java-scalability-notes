package app;
import geo.*;
public class Main {
    public static void main(String[] a) {
        System.out.println("Rect(2,3)     → " + Area.of(new Rect(2, 3)));
        System.out.println("Triangle(2,3) → " + Area.of(new Triangle(2, 3)));
    }
}
