package geo;
public record Triangle(double b, double h) implements Shape {}
