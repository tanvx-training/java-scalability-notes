D='/home/claude/lab22/gensw/src/sw'
hdr='package sw;\n'
open(f'{D}/S.java','w').write(hdr+'public sealed interface S permits A, B, C, D {}\n')
for n in 'ABCD': open(f'{D}/{n}.java','w').write(hdr+f'public record {n}(double x) implements S {{}}\n')
for k in range(10):
    sw=[]; io=[]
    for j in range(20):
        sw.append(f'''    static double s{j}(S s) {{ return switch (s) {{ case A a -> a.x() + {j}; case B b -> b.x() * {j}; case C c -> c.x() - {j}; case D d -> d.x() / {j+1}; }}; }}''')
        io.append(f'''    static double i{j}(S s) {{ if (s instanceof A a) return a.x() + {j}; if (s instanceof B b) return b.x() * {j}; if (s instanceof C c) return c.x() - {j}; if (s instanceof D d) return d.x() / {j+1}; throw new IllegalStateException(); }}''')
    calls_s=' '.join(f's{j}(v) +' for j in range(20))
    calls_i=' '.join(f'i{j}(v) +' for j in range(20))
    open(f'{D}/W{k}.java','w').write(hdr+f'public class W{k} {{\n'+'\n'.join(sw)+'\n'+'\n'.join(io)+f'\n    public static double runS(S v) {{ return {calls_s} 0; }}\n    public static double runI(S v) {{ return {calls_i} 0; }}\n}}\n')
open(f'{D}/Main.java','w').write(hdr+'''public class Main {
    public static void main(String[] a) {
        S v = new D(2);
        long t0 = System.nanoTime(); double s = 0;
        if (a[0].equals("switch")) { s += W0.runS(v) + W1.runS(v) + W2.runS(v) + W3.runS(v) + W4.runS(v) + W5.runS(v) + W6.runS(v) + W7.runS(v) + W8.runS(v) + W9.runS(v); }
        else { s += W0.runI(v) + W1.runI(v) + W2.runI(v) + W3.runI(v) + W4.runI(v) + W5.runI(v) + W6.runI(v) + W7.runI(v) + W8.runI(v) + W9.runI(v); }
        System.out.printf("%s: first %.2f ms (s=%.1f)%n", a[0], (System.nanoTime() - t0) / 1e6, s);
    }
}
''')
