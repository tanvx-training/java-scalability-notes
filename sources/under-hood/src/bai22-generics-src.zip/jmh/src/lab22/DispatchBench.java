package lab22;

import java.util.*;
import java.util.concurrent.TimeUnit;
import org.openjdk.jmh.annotations.*;

@State(Scope.Thread)
@BenchmarkMode(Mode.AverageTime) @OutputTimeUnit(TimeUnit.NANOSECONDS)
@Warmup(iterations = 4, time = 1) @Measurement(iterations = 5, time = 1) @Fork(2)
public class DispatchBench {
    sealed interface S permits A, B, C, D { double area(); }
    record A(double x) implements S { public double area() { return x * x; } }
    record B(double x) implements S { public double area() { return 2 * x; } }
    record C(double x) implements S { public double area() { return x + 1; } }
    record D(double x) implements S { public double area() { return x * 3; } }

    @Param({"1", "4"}) int kinds;
    S[] shapes = new S[1024];

    @Setup public void setup() {
        Random r = new Random(22);
        for (int i = 0; i < shapes.length; i++) {
            int k = kinds == 1 ? 0 : r.nextInt(4); double x = r.nextDouble();
            shapes[i] = switch (k) { case 0 -> new A(x); case 1 -> new B(x); case 2 -> new C(x); default -> new D(x); };
        }
    }

    @Benchmark public double virtualCall() { double s = 0; for (S sh : shapes) s += sh.area(); return s; }

    @Benchmark public double patternSwitch() {
        double s = 0;
        for (S sh : shapes) s += switch (sh) {
            case A a -> a.x() * a.x();
            case B b -> 2 * b.x();
            case C c -> c.x() + 1;
            case D d -> d.x() * 3;
        };
        return s;
    }

    @Benchmark public double recordPattern() {
        double s = 0;
        for (S sh : shapes) s += switch (sh) {
            case A(double x) -> x * x;
            case B(double x) -> 2 * x;
            case C(double x) -> x + 1;
            case D(double x) -> x * 3;
        };
        return s;
    }

    @Benchmark public double instanceofChain() {
        double s = 0;
        for (S sh : shapes) {
            if (sh instanceof A a) s += a.x() * a.x();
            else if (sh instanceof B b) s += 2 * b.x();
            else if (sh instanceof C c) s += c.x() + 1;
            else if (sh instanceof D d) s += d.x() * 3;
        }
        return s;
    }
}
